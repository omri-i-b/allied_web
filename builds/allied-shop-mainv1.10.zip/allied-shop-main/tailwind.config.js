/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/**/*.{js,ts,jsx,tsx,mdx}',
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    container: {
      center: true,
      padding: {
        DEFAULT: '1.25rem',
        sm: '1.25rem',
        md: '4vw',
      },
    },
    fontSize: {
      xs: '0.75rem',
      sm: '0.875rem',
      base: '1rem',
      lg: '1.125rem',
      xl: '1.375rem',
      '2xl': '1.5rem',
      '3xl': '2.125rem',
      '4xl': '2.5rem',
    },
    extend: {
      colors: {
        red: {
          core: '#C4000E',
          lighter: '#F9E6E7',
          light: '#EDB0B4',
          DEFAULT: '#CF202F',
          dark: '#B2000D',
          darker: '#8B000A',
        },
        grey: {
          light: '#F8F8F8',
          DEFAULT: '#D8D8D8',
          dark: '#56595D',
          darker: '#1E1E1E',
          muted: '#72777D',
          chip: '#EEEEEE',
          border: '#ADB5BD',
        },
        green: '#347736',
      },
      fontFamily: {
        sans: ['var(--font-inter)'],
      },
    },
  },
  plugins: [],
}

