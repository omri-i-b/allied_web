export type FilterType = {
  id: number;
  name: string;
  count: number;
};

export type FilterGroupType = {
  title: string;
  slug: string;
  filters: Array<FilterType>;
  setFilters: (_filters:FilterType[]) => void;
};

export type FiltersType = {
  categories: number[];
  sizes?: number[];
  schedules?: number[];
  grades?: number[];
  pressures?: number[];
  shapes: number[];
};

export type Subcategory = {
  id: number;
  title: string;
  slug: string;
  count: number;
  image?: string;
};

export type Category = {
  id: number;
  title: string;
  slug: string;
  count: number;
  image?: string;
  subcategories: Array<Subcategory>;
};
