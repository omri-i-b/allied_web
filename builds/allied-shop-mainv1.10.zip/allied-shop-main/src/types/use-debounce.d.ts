// src/use-debounce.d.ts
declare module 'use-debounce' {
    export function useDebouncedValue<T>(value: T, delay: number): T;
    export function useDebouncedCallback<T extends (...args: any[]) => void>(
        callback: T,
        delay: number,
        options?: { leading?: boolean; trailing?: boolean }
    ): (...args: Parameters<T>) => void;
}
