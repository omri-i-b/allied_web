export type Cart = {
  id: number;
  count: number;
  items: CartItem[];
  notes?: string;
};

export type CartItem = {
  cartId: number; // Cart Item ID
  productId: number; // Product Id
  name: string; // Product Name
  price: number;
  quantity: number;
  weight: number;
  image: string;
  slug: string;
  categoryId: number;
  subcategoryId: number;
  manufacturerId: number;
  manufacturerCode: string;
  manufacturerName: string;
  warehouseId: number;
  warehouseCode: string;
  warehouseName: string;
  warehousePrice: number;
  warehouseMultiplier: number;
  shipTermId: number;
  oldPrice?: number;
};

export type LineItem = {
  basketLineId: number;
  shipToAddressId?: number;
  thirdPartyBillToAddressId?: number;
  shipTermId?: number;
  carrierId?: number;
  shipViaId?: number;
  customerFreightCollectAccountNumber?: string;
  customerPurchaseOrderNumber?: string;
  requiredShipDate?: string;
  estimatedShipPickUpDate?: string;
  taxCodeId?: number;
  taxAmount?: number;
  shipToCustomizedOrganizationName?: string;
  thirdPartyBillToCustomizedOrganizationName?: string;
};

export type TaxItem = {
  cartId: number;
  taxableAmount: number;
  taxAmount: number;
  taxCodeId: number;
};
