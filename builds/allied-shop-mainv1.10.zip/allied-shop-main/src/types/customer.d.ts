export type Address = {
  id: number;
  name: string;
  street1: string;
  street2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  isDefault?: boolean;
  isVerified: boolean;
};

export type ShippingTerm = {
  id: number;
  organizationId: number;
  code: string;
  description: string;
  useCustomerCarrierAccount: boolean;
  showThirdPartyBillToAddressField: boolean;
};

export type ShippingCombination = {
  organizationId: number;
  id: number;
  carrierId: number;
  carrierCode: string;
  carrierDescription: string;
  carrierIsPurchasable: boolean;
  carrierIsSaleable: boolean;
  shipViaId: number;
  shipViaCode: string;
  shipViaDescription: string;
  shipViaIsPurchasable: boolean;
  shipViaIsSaleable: boolean;
  shipViaIsSameDay: boolean;
  shipViaCutOffTime: string;
};

export type Order = {
  id: number;
  status: string;
  number: string;
  date: string;
  purchaseOrderNumber: string;
  salesOrderNumber: string;
  itemCount?: number;
  items?: OrderItem[];
  subtotal?: number;
  taxes?: number;
  total: number;
  weight?: number;
  shipTo?: Address;
  billTo?: Address;
  notes?: string;
  portalUrl?: string;
};

export type OrderLine = {
  id: number;
  webOrderId: number;
  lineNumber: string;
  partId: number;
  partNumber: string;
  partDescription: string;
  qtyToOrder: number;
  price: number;
  multiplier: number;
  ecommerceWarehouseId: number;
  ecommerceWarehouseCode: string;
  ecommerceWarehouseDescription: string;
  manufacturerTypeId: number;
  manufacturerTypeCode: string;
  manufacturerTypeDescription: string;
  estimatedShipPickUpDate: string;
  carierId: number;
  carrierCode: string;
  carrierDescription: string;
  shipViaId: number;
  shipViaCode: string;
  shipViaDescription: string;
  shipTermId: number;
  shipTermCode: string;
  shipTermDescription: string;
  requiredShipDate: string;
  customerFreightCollectAccountNumber: string;
  shipToAddressId: number;
  taxAmount: number;
  shipTo: {
    id: number;
    addressIdentification: string;
    address: string;
    address2: string;
    zipCode: string;
    contact: string;
    phoneNumber: string;
    faxNumber: string;
    email: string;
    notes: string;
    attention: string;
    countryId: number;
    countryCode: string;
    countryDescription: string;
    stateId: number;
    stateCode: string;
    stateDescription: string;
    cityId: number;
    cityCode: string;
    cityDescription: string;
    customizedOrganizationName: string;
    webOrderId: number;
    webOrderLineId: number;
  };
  manageOrganizationId: number;
  partCategoryId: number;
  partShapeId: number;
  fileName: string;
  customerPOLineNumber: number;
};

export type OrderItem = {
  id: number;
  productId: number;
  name: string;
  price: number;
  quantity: number;
  weight?: number;
  image: string;
  slug: string;
  categoryId: number;
  subcategoryId: number;
  manufacturer: string;
  carrier: string;
  warehouse: string;
  freightNumber: string;
  shipDate: string;
  shipTermCode: string;
};

export type SavedCart = {
  id: number;
  basketNumber: string;
  savedDate: string;
  notes: string;
  customerId: number;
  customerPortalUserId: number;
  countResults: number;
};
