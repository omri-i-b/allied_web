// src/swiper-react.d.ts
declare module 'swiper/react' {
    export const Swiper: any;
    export const SwiperSlide: any;
}
