export type  UserState = {
    id: number;
    customerId: number;
    customerName: string;
    customerCode: string;
    organizationId: number;
    warehouseId: number;
    allowChangeWarehouse: boolean;
    accessToken: string;
    email: string;
    firstName: string;
    lastName: string;
    resetPassword: boolean;
    status: string
  }