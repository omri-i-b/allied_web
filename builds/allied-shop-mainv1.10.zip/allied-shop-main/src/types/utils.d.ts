export type Configuration = {
  salesEmail: string;
  maximumThresholdByLine: number;
  maximumOrderAmount: number;
  smtpUser: string;
  smtpPassword: string;
  smtpHost: string;
  smtpPort: number;
  smtpSSL: boolean;
  eCommerceUserRequestEmail: string;
  willCallCarrierId: number;
  flatDiscount: number;
  carrierCode: string;
  carrierDescription: string;
  carrierIsPurchasable: boolean;
  carrierIsSaleable: boolean;
  willCallShipViaId: number;
  shipViaCode: string;
  shipViaDescription: string;
  shipViaIsPurchasable: boolean;
  shipViaIsSaleable: boolean;
  shipViaIsSameDay: boolean;
  shipViaCutOffTime: string;
};

export type State = {
  name: string;
  abbreviation: string;
};

export type Image = {
  bytes: string;
  fileName: string;
  partCategoryId: number;
  partShapeId: number;
};
