export type Product = {
  id: number;
  sku: string;
  title: string;
  slug: string;
  image?: string;
  categoryId: number;
  subcategoryId: number;
  size?: string;
  size1: string;
  size2: string;
  size3: string;
  size4: string;
  weight?: number;
  grade?: string;
  schedule?: string;
  material?: string;
  pressure?: string;
  shape?: string;
  endConnection?: string;
  group?: string;
  manageOrganizationId?: number,
  shapeId?: number,
};

export type Manufacturer = {
  id: number;
  name: string;
  code: string;
};

export type Warehouse = {
  id: number;
  name: string;
  code: string;
};

export type Facet = {
  title: string;
  type: string;
  items: {
    id: number;
    prefix?: string;
    title: string;
    slug: string;
    image?: string;
    count: number;
    facet?: any;
  }[];
};

export interface AvailableWarehouse extends Warehouse {
  price: number;
  multiplier: number;
  isPrimary: boolean;
}

export type PreSearchResults = {
  products?: Product[];
  categories?: any[];
  gradeProducts: any[]; 
  shapeProducts: anyp[];
  scheduleProducts: any[];
  pressureProducts: any[];
  size1Products: any[];
  size2Products: any[];
  size3Products: any[];
  size4Products: any[];
  suggestions?: any[];
};

export type searchResults = {
  count: number;
  products: Product[];
  facets: Facet[];
};
