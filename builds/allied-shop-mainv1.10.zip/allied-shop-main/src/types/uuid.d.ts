export type uuid = {
    uuid: string;
};