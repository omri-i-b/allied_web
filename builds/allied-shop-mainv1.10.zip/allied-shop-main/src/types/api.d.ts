import { OrderLine, SavedCart } from './customer';
import { Configuration } from './utils';

export type APIResponseAuthenticate = {
  token: string;
  resetPassword: boolean;
};

export type APIResponseChangePassword = {
  userId: number;
  email: string;
};

export type APIResponseAlgoliaPreSearch = {
  results: {
    hits: {
      id: number;
      number: string;
      description: string;
      countResults: number;
      manageOrganizationId: number;
      partCategoryId: number;
      partCategory: string;
      partShapeId: number;
      partShape: string;
      fileName: string;
      partGradeId: number;
      partGrade: string;
      partGroupId: number;
      partGroup: string;
      partScheduleId: number;
      partSchedule: string;
      partSizeId: number;
      partSize1: string;
      partSize2Id: number;
      partSize2: string;
      partSize3Id: number;
      partSize3: string;
      partSize4Id: number;
      partSize4: string;
      partMaterialId: number;
      partMaterial: string;
      partPressureClassId: number;
      partPressureClass: string;
      indexByQuantity: number;
      indexByAmount: number;
      objectID: string;
      _highlightResult: {};
    }[];
    nbHits: number;
    page: number;
    nbPages: number;
    hitsPerPage: number;
    facets?: {
      partCategory?: any;
      partCategoryId_PartShapeId?: any;
      partGrade: any;
      partShape: any;
      partSize1: any;
      partSize2: any;
      partSize3: any;
      partSize4: any;
      partSchedule: any;
      partPressureClass: any;
    };
  }[];
};

export type APIResponseAlgoliaSearch = {
  hits: {
    id: number;
    number: string;
    description: string;
    countResults: number;
    manageOrganizationId: number;
    partCategoryId: number;
    partCategory: string;
    partShapeId: number;
    partShape: string;
    fileName: string;
    partGradeId: number;
    partGrade: string;
    partGroupId: number;
    partGroup: string;
    partScheduleId: number;
    partSchedule: string;
    partSizeId: number;
    partSize1: string;
    partSize2Id: number;
    partSize2: string;
    partSize3Id: number;
    partSize3: string;
    partSize4Id: number;
    partSize4: string;
    partMaterialId: number;
    partMaterial: string;
    partPressureClassId: number;
    partPressureClass: string;
    indexByQuantity: number;
    indexByAmount: number;
    objectID: string;
    _highlightResult: {};
  }[];
  nbHits: number;
  page: number;
  nbPages: number;
  hitsPerPage: number;
  facets?: {
    partCategory?: any;
    partCategoryId_PartShapeId?: any;
  };
};

export type APIResponseSearchParts = {
  categories: {
    id: number;
    code: string;
    description: string;
    isSelected: boolean;
    qty: number;
  }[];
  sizes: {
    id: number;
    code: string;
    description: string;
    isSelected: boolean;
    qty: number;
  }[];
  sizes2: {
    id: number;
    code: string;
    description: string;
    isSelected: boolean;
    qty: number;
  }[];
  schedules: {
    id: number;
    code: string;
    description: string;
    isSelected: boolean;
    qty: number;
  }[];
  grades: {
    id: number;
    code: string;
    description: string;
    isSelected: boolean;
    qty: number;
  }[];
  pressures: {
    id: number;
    code: string;
    description: string;
    isSelected: boolean;
    qty: number;
  }[];
  shapes: {
    id: number;
    code: string;
    description: string;
    isSelected: boolean;
    qty: number;
  }[];
  parts: {
    currentPage: number;
    pageSizes: number;
    results: {
      id: number;
      number: string;
      description: string;
      countResults: number;
      manageOrganizationId: number;
      partCategoryId: number;
      partShapeId: number;
      fileName: string;
      partGradeId: number;
      partGrade: string;
      partGroupId: number;
      partGroup: string;
      partScheduleID: number;
      partSchedule: string;
      partSizeId: number;
      partSize1: string;
      partSize2Id: number;
      partSize2: string;
      partSize3Id: number;
      partSize3: string;
      partSize4Id: number;
      partSize4: string;
      partMaterialId: number;
      partMaterial: string;
      partPressureClassId: number;
      partPressureClass: string;
      partCategory: string;
      partShape: string;
      indexByQuantity: number;
      indexByAmount: number;
      partCategory_PartShape: string;
      partCategoryId_PartShapeId: string;
    }[];
    total: number;
  };
  partCategroy_PartShape: number;
};

export type APIResponseProduct = {
  part: {
    id: number;
    number: string;
    description: string;
    weight: number;
    allowFractions: boolean;
    partCategoryId: number;
    partCategoryCode: string;
    partCategoryDescription: string;
    partGradeId: number;
    partGradeCode: string;
    partGradeDescription: string;
    partGroupId: number;
    partGroupIdCode: string;
    partGroupDescription: string;
    partStateId: number;
    partStateCode: string;
    partStateDescription: string;
    partTypeId: number;
    partTypeCode: string;
    partTypeDescription: string;
    organizationId: number;
    manageOrganizationId: number;
    manageOrganizationName: string;
    partShapeId: number;
    fileName: string;

    // NOT ACTUALLY PRESENT
    partSize: string;
    partWeight: number;
    partSchedule: string;
    partMaterial: string;
    partPressureClass: string;
    partShape: string;
    partEndConnection: string;
    partGroup: string;
  };
};

export type APIResponeFrequentlyBoughtTogether = {
  parts: {
    id: number;
    number: string;
    description: string;
    timesSold: number;
    partCategoryId: number;
    partShapeId: number;
  }[];
};

export type APIResponseGetAddressByCustomerAndType = {
  addresses: {
    address: string;
    address2: string;
    countryId: number;
    countryCode: string;
    countryDescription: string;
    stateId: number;
    stateCode: string;
    stateDescription: string;
    cityId: number;
    cityCode: string;
    cityName: string;
    zipCode: string;
    email: string;
    phone: string;
    isDefault: boolean;
    isJobSide: boolean;
    verified: boolean;
    id: number;
    customizedOrganizationName: string;
  }[];
};

export type APIResponseGetCandidates = {
  candidates: {
    address: string;
    countryCode: string;
    stateCode: string;
    cityName: string;
    zipCode: string;
    region: string;
    zipCodeSecundary: string;
    uniqueCode: string;
  }[];
};

export type APIResponseGetCountries = {
  countries: {
    id: number;
    code: string;
    description: string;
  }[];
};

export type APIResponseGetStates = {
  states: {
    id: number;
    code: string;
    description: string;
    countryId: number;
  }[];
};

export type APIResponseGetCities = {
  cities: {
    id: number;
    code: string;
    description: string;
    stateId: number;
  }[];
};

export type APIResponseGetShipTerms = {
  shipTerms: {
    id: number;
    organizationId: number;
    code: string;
    description: string;
    useCustomerCarrierAccount: boolean;
    showThirdPartyBillToAddressField: boolean;
  }[];
};

export type APIResponseGetCarrierShipViaCombinations = {
  combinations: {
    organizationId: number;
    id: number;
    carrierId: number;
    carrierCode: string;
    carrierDescription: string;
    carrierIsPurchasable: boolean;
    carrierIsSaleable: boolean;
    shipViaId: number;
    shipViaCode: string;
    shipViaDescription: string;
    shipViaIsPurchasable: boolean;
    shipViaIsSaleable: boolean;
    shipViaIsSameDay: boolean;
    shipViaCutOffTime: string;
  }[];
};

export type APIResponseSearchWebOrders = {
  webOrderStateList: {
    id: number;
    code: string;
    description: string;
  }[];
  webOrdersPaginable: {
    currentPage: number;
    pageSizes: number;
    results: {
      id: number;
      number: string;
      date: string;
      requiredShipDate: string;
      currencyId: number;
      currencyCode: string;
      currencyDescription: string;
      total: number;
      customerId: number;
      customerPortalUserId: number;
      salesOrderMasterId: number;
      salesOrderMasterNumber: string;
      stateId: number;
      stateCode: string;
      stateDescription: string;
      customerPurchaseOrderNumber: string;
      countResults: number;
    }[];
    total: number;
  };
};

export type APIResponseSearchWebOrderDetail = {
  order: {
    id: number;
    number: string;
    date: string;
    stateId: number;
    stateCode: string;
    stateDescription: string;
    customerId: number;
    customerCode: string;
    customerName: string;
    customerPortalUserId: number;
    customerPortalUserName: string;
    customerPortalUserLastName: string;
    customerPortalUserEmail: string;
    email: string;
    salesOrderMasterId: number;
    salesOrderMasterNumber: string;
    salesOrderMasterDate: string;
    cancelUserId: number;
    cancelUserCode: string;
    cancelUserName: string;
    cancelUserLastName: string;
    cancelUserEmail: string;
    cancelDate: string;
    cancelReason: string;
    createdDate: string;
    currencyId: number;
    currencyCode: string;
    currencyDescription: string;
    total: number;
    carierId: number;
    carrierCode: string;
    carrierDescription: string;
    shipTermId: number;
    shipToAddressId: number;
    shipTermCode: string;
    shipTermDescription: string;
    shipViaId: number;
    shipViaCode: string;
    shipViaDescription: string;
    customerFreightCollectAccountNumber: string;
    requiredShipDate: string;
    customerPurchaseOrderNumber: string;
    organizationId: number;
    shipTo: {
      id: number;
      addressIdentification: string;
      address: string;
      address2: string;
      zipCode: string;
      contact: string;
      phoneNumber: string;
      faxNumber: string;
      email: string;
      notes: string;
      attention: string;
      countryId: number;
      countryCode: string;
      countryDescription: string;
      stateId: number;
      stateCode: string;
      stateDescription: string;
      cityId: number;
      cityCode: string;
      cityDescription: string;
      customizedOrganizationName: string;
      webOrderId: number;
      webOrderLineId: number;
    };
    billTo: {
      id: number;
      addressIdentification: string;
      address: string;
      address2: string;
      zipCode: string;
      contact: string;
      phoneNumber: string;
      faxNumber: string;
      email: string;
      notes: string;
      attention: string;
      countryId: number;
      countryCode: string;
      countryDescription: string;
      stateId: number;
      stateCode: string;
      stateDescription: string;
      cityId: number;
      cityCode: string;
      cityDescription: string;
      customizedOrganizationName: string;
      webOrderId: number;
      webOrderLineId: number;
    };
    lines: OrderLine[];
    notes: string;
    somUrlPortal: string;
  };
};

export type APIResponseSearchBaskets = {
  basketsPaginable: {
    currentPage: number;
    pageSizes: number;
    results: SavedCart[];
    total: number;
  };
};

export type APIResponseCheckout = {
  webOrderId: number;
  webOrderNumber: string;
};

export type APIResponseSearchBasketDetails = {
  basket: {
    customerId: number;
    customerPortalUserId: number;
    creationDate: string;
    lastUpdatedDate: string;
    statusId: number;
    id: number;
    basketNumber: string;
    savedDate: string;
    notes: string;
    items: {
      id: number;
      basketId: number;
      partId: number;
      partNumber: string;
      partDescription: string;
      qty: number;
      weight: number;
      price: number;
      newPrice: number;
      multiplier: number;
      newMultiplier: number;
      manufacturerTypeId: number;
      manufacturerTypeCode: string;
      manufacturerTypeDescription: string;
      ecommerceWarehouseId: number;
      ecommerceWarehouseCode: string;
      ecommerceWarehouseDescription: string;
      manageOrganizationId: number;
      partCategoryId: number;
      partShapeId: number;
      fileName: string;
      customerPOLineNumber: number;
      shipTermId: number;
      creationDate: string;
      lastUpdatedDate: string;
    }[];
  };
};

export type APIResponseGetActiveBasketToShow = {
  basket: {
    customerId: number;
    customerPortalUserId: number;
    creationDate: string;
    lastUpdatedDate: string;
    statusId: number;
    id: number;
    basketNumber: string;
    savedDate: string;
    notes: string;
    items: [
      {
        id: number;
        basketId: number;
        partId: number;
        partNumber: string;
        partDescription: string;
        qty: number;
        weight: number;
        price: number;
        newPrice: number;
        multiplier: number;
        newMultiplier: number;
        manufacturerTypeId: number;
        manufacturerTypeCode: string;
        manufacturerTypeDescription: string;
        ecommerceWarehouseId: number;
        ecommerceWarehouseCode: string;
        ecommerceWarehouseDescription: string;
        manageOrganizationId: number;
        partCategoryId: number;
        partShapeId: number;
        fileName: string;
        customerPOLineNumber: number;
        shipTermId: number;
        creationDate: string;
        lastUpdatedDate: string;
      },
    ];
  };
};

export type APIResponseCountBasketItems = {
  qty: number;
};

export type APIResponseGetBasketItemTax = {
  taxes: {
    basketItemId: number;
    taxableAmount: number;
    shipToAddressId: number;
    taxCodeId: number;
    taxCodeDetailId: number;
    taxAmount: number;
  }[];
};

export type APIResponseValidateQuantities = {
  errors?: {
    error: string;
    basketItemId: number;
  }[];
  isValid: boolean;
};

export type APIResponseIsOverThresholdByLineAndTotal = boolean;

export type APIResponseValidateBasket = {
  errors?: {
    error: string;
    basketItemId: number;
  }[];
  isValid: boolean;
};

export type APIResponseCalculateEstimatedShipPickUpDate = {
  estimatedShipPickUpDate: string;
};

export type APIResponseConfiguration = {
  configurationData: Configuration;
};

export type APIResponseImages = {
  images: Image[];
};
