import {
  createContext,
  useState,
  ReactNode,
  useContext,
  useCallback,
  useMemo,
  useEffect,
} from 'react';
import {
  emptyCart,
  getCart,
  getCartTotals,
  getProductAvailability,
  removeItemFromCart,
  updateItemInCart,
  validateCart,
} from '../actions';
import { CartItem, TaxItem } from '../types/cart';
import { Address, ShippingCombination, ShippingTerm } from '../types/customer';
import { Configuration } from '../types/utils';
import { SESSION_CART_ADDDRESS } from '../constants';

const initialCart = {
  id: 0,
  count: 0,
  items: [] as CartItem[],
  totals: {
    subtotal: 0,
    tax: 0,
    discount: 0,
    total: 0,
    weight: 0,
    taxes: [] as TaxItem[],
  },
};

interface CartContextProps {
  id: number;
  count: number;
  items: CartItem[];
  totals: {
    subtotal: number;
    tax: number;
    discount: number;
    total: number;
    weight: number;
    taxes: TaxItem[];
  };
  configuration?: Configuration;
  cartAddress?: Address;
  billingAddress?: Address;
  thirdPartyAddress?: Address;
  shippingTerm?: ShippingTerm;
  willCallTerm?: ShippingTerm;
  thirdPartyTerm?: ShippingTerm;
  prepaidTerm?: ShippingTerm;
  hasShipping: boolean;
  hasWillCall: boolean;
  hasThirdParty: boolean;
  allowThirdParty: boolean;
  setAllowThirdParty: (_allow: boolean) => void;
  hasPrepaid: boolean;
  shippingCombinations?: ShippingCombination[];
  prepaidCombinations: ShippingCombination[];
  isItemInCart: (_id: number, _manufacturerId: number) => boolean;
  getItemInCart: (_cartId: number) => CartItem | false;
  getItemByProductId: (
    _id: number,
    _manufacturerId: number,
  ) => CartItem | false;
  increaseCount: () => void;
  refreshCart: () => any;
  resetCart: () => void;
  clearCart: () => void;
  isValid: boolean;
  setCartAddress: (_address: Address) => void;
  setThirdPartyAddress: (_address: Address) => void;
  willCallCombination?: ShippingCombination;
  shippingCombination?: ShippingCombination;
}

export const CartContext = createContext<CartContextProps>(
  Object.assign({}, initialCart, {
    hasShipping: false,
    hasWillCall: false,
    hasThirdParty: false,
    hasPrepaid: false,
    allowThirdParty: false,
    setAllowThirdParty: () => { },
    prepaidCombinations: [],
    isItemInCart: () => false,
    getItemInCart: () => false,
    getItemByProductId: () => false,
    increaseCount: () => { },
    isValid: false,
    refreshCart: () => { },
    resetCart: () => { },
    clearCart: () => { },
    setCartAddress: () => { },
    setThirdPartyAddress: () => { },
  }),
);

export function CartProvider({
  configuration,
  serverCart,
  serverAddress,
  billingAddress,
  thirdPartyAddress,
  shippingTerm,
  willCallTerm,
  thirdPartyTerm,
  prepaidTerm,
  shippingCombinations,
  prepaidCombinations,
  children,
}: Readonly<{
  configuration?: Configuration;
  serverCart: {};
  serverAddress?: Address;
  billingAddress?: Address;
  thirdPartyAddress?: Address;
  shippingTerm?: ShippingTerm;
  willCallTerm?: ShippingTerm;
  thirdPartyTerm?: ShippingTerm;
  prepaidTerm?: ShippingTerm;
  shippingCombinations: ShippingCombination[];
  prepaidCombinations: ShippingCombination[];
  children: ReactNode;
}>) {

  const hasShipping = !!shippingTerm;
  const hasWillCall = !!willCallTerm;
  const hasThirdParty = !!thirdPartyTerm;
  const hasPrepaid = !!prepaidTerm;

  const [allowThirdParty, setAllowThirdParty] = useState(hasThirdParty);
  const [isValid, setIsValid] = useState(false);
  const [cartState, setCartState] = useState(Object.assign({}, initialCart, serverCart));
  const [serverThirdPartyAddress, setThirdPartyAddress] = useState<Address | undefined>(thirdPartyAddress);

  const sessionCartAddress = localStorage.getItem(SESSION_CART_ADDDRESS);
  const [cartAddress, setCartAddress] = useState<Address | undefined>(sessionCartAddress ? JSON.parse(sessionCartAddress) : serverAddress);

  /**
   * save cart address in local storage if changed
   */
  useEffect(() => {
    if (cartAddress) {
      localStorage.setItem(SESSION_CART_ADDDRESS, JSON.stringify(cartAddress));
    }
  }, [cartAddress]);

  /**
   * refresh the cart and totals
   */
  const refreshCart = async (
    oldPrices?: { cartId: number; price: number }[],
  ) => {
    const cartPromise = getCart();
    const totalsPromise = getCartTotals();

    const [cart, totals] = await Promise.all([cartPromise, totalsPromise]);

    if (!cart || !totals) {
      return;
    }

    const newCartState = {
      id: cart.id,
      count: cart.items.length,
      items: cart.items,
      totals: totals,
    };

    if (oldPrices) {
      oldPrices.forEach((oldPrice) => {
        const idx = newCartState.items.findIndex(
          (item) => item.cartId === oldPrice.cartId,
        );
        newCartState.items[idx].oldPrice = oldPrice.price;
      });
    }


    setCartState(newCartState);

    return newCartState;
  };

  /**
   * reset the cart to initial
   */
  const resetCart = async () => {
    setCartState(initialCart);
  };

  /**
   * Empty the cart
   */
  const clearCart = async () => {
    // Empty the cart
    await emptyCart(cartState.id);

    // Refresh 
    await refreshCart();
  };

  /**
   * Get a cart item by the cart ID
   */
  const getItemInCart = useCallback(
    (cartId: number) => {
      return (
        cartState.items.find((item: CartItem) => item.cartId === cartId) ??
        false
      );
    },
    [cartState],
  );

  /**
   * Get a specific product from the cart
   */
  const getItemByProductId = useCallback(
    (productId: number, manufacturerId: number) => {
      return (
        cartState.items.find(
          (item: CartItem) =>
            item.productId === productId &&
            item.manufacturerId === manufacturerId,
        ) ?? false
      );
    },
    [cartState],
  );

  /**
   * Checks if a product is already in the cart.
   */
  const isItemInCart = useCallback(
    (productId: number, manufacturerId: number) => {
      return !!getItemByProductId(productId, manufacturerId);
    },
    [getItemByProductId],
  );

  /**
   * Increases the cart count state
   */
  const increaseCount = useCallback(() => {
    setCartState((previousCartState) =>
      Object.assign({}, previousCartState, {
        count: previousCartState.count + 1,
      }),
    );
  }, []);

  /**
   * Gets the Will Call Carrier/Shipping Combination (cut off times, etc...)
   */
  const willCallCombination = useMemo(() => {
    return shippingCombinations.find(
      (carrier) => 'WILL' === carrier.carrierCode,
    );
  }, [shippingCombinations]);

  /**
   * Gets the first Carrier/Shipping Combination, used for time estimation (cut off times, etc...)
   */
  const shippingCombination = useMemo(() => {
    return shippingCombinations.filter(
      (carrier) => 'WC' !== carrier.shipViaCode,
    )[0];
  }, [shippingCombinations]);

  // To fix the cart errors, we need to get the new cart pricing
  const fixCartErrors = useCallback(
    async (errors: { error: string; basketItemId: number }[]) => {
      if (!errors || !errors.length) {
        return;
      }

      const oldPrices: { cartId: number; price: number }[] = [];

      errors.forEach(async ({ basketItemId }) => {
        const errorItem = getItemInCart(basketItemId);

        if (!errorItem) {
          return;
        }

        oldPrices.push({
          cartId: basketItemId,
          price: errorItem.price,
        });

        const { primary, alternates } = await getProductAvailability(
          errorItem.productId,
          errorItem.manufacturerId,
          errorItem.quantity,
          cartState.id,
        );

        const matchedWarehouse = [primary, ...alternates].find(
          (w) => w && w.id === errorItem.warehouseId,
        );

        if (!matchedWarehouse) {
          await removeItemFromCart(errorItem.cartId, cartState.id);
        }

        await updateItemInCart(
          errorItem.cartId,
          cartState.id,
          errorItem.productId,
          errorItem.manufacturerId,
          matchedWarehouse.id,
          matchedWarehouse.price,
          matchedWarehouse.multiplier,
          errorItem.quantity,
          errorItem.shipTermId,
        );
      });

      await refreshCart(oldPrices);
    },
    [cartState, getItemInCart],
  );

  useEffect(() => {
    if (!cartState.id || !cartState.count) {
      setIsValid(false);
      return;
    }

    const abortController = new AbortController();
    const signal = abortController.signal;

    (async () => {
      const validation = await validateCart(cartState.id);
      if (!signal.aborted) {
        setIsValid(validation.isValid);

        if (validation.errors) {
          fixCartErrors(validation.errors);
        }
      }
    })();

    return () => {
      abortController.abort();
    };
  }, [cartState, fixCartErrors]);

  const data = {
    ...cartState,
    configuration,
    cartAddress,
    billingAddress,
    thirdPartyAddress: serverThirdPartyAddress,
    hasShipping,
    shippingTerm,
    hasWillCall,
    willCallTerm,
    hasThirdParty,
    thirdPartyTerm,
    hasPrepaid,
    prepaidTerm,
    shippingCombinations,
    prepaidCombinations,
    isItemInCart,
    getItemInCart,
    getItemByProductId,
    increaseCount,
    refreshCart,
    resetCart,
    clearCart,
    isValid,
    setCartAddress,
    setThirdPartyAddress,
    allowThirdParty,
    setAllowThirdParty,
    willCallCombination,
    shippingCombination,
  };

  // return <CartContext.Provider value={data}>{children}</CartContext.Provider>;
  return (
    <CartContext.Provider value={{ ...data }}>
        {children}
    </CartContext.Provider>
);
}

export function useCart() {
  return useContext(CartContext);
}
