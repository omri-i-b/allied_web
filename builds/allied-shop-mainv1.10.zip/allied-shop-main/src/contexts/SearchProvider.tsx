
import {
  createContext,
  ReactNode,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { Facet, Product } from '../types/products';
import { getSearchResults } from '../actions';

const initialFilters = {
  partCategory: [],
  partCategoryId_PartShapeId: [],
};

interface SearchContextProps {
  query: string;
  count: number;
  results: Product[];
  facets: Facet[];
  filters: {
    partCategory: string[];
    partCategoryId_PartShapeId: string[];
  };
  setFilters: (_filters: any) => void;
}

export const SearchContext = createContext<SearchContextProps>(
  Object.assign({}),
);

export function SearchProvider({
  serverQuery,
  serverResults,
  children,
}: Readonly<{
  serverQuery: string;
  serverResults: {
    count: number;
    products: Product[];
    facets: Facet[];
  };
  children: ReactNode;
}>) {
  const { facets } = serverResults;

  const [filters, setFilters] = useState(initialFilters);
  const [count, setCount] = useState(serverResults.count);
  const [results, setResults] = useState(serverResults.products);

  const previousFilters = useRef(filters);

  const formattedFilters = useMemo(() => {
    const newFilters = Object.keys(filters)
      .map((key) => {
        return (filters as { [key: string]: string[] })[key].map(
          (val) => `${key}:${val}`,
        );
      })
      .flat(1);

    return [newFilters];
  }, [filters]);

  const getResults = useCallback(async () => {
    const data = await getSearchResults(serverQuery, formattedFilters);

    setCount(data.count);
    setResults(data.products);
  }, [formattedFilters, serverQuery]);

  useEffect(() => {
    if (filters !== previousFilters.current) {
      previousFilters.current = filters;
      getResults();
    }
  }, [filters, getResults]);

  const data = {
    query: serverQuery,
    count,
    results,
    facets,
    filters,
    setFilters,
  };

  return (
    <SearchContext.Provider value={data}>{children}</SearchContext.Provider>
  );
}

export function useSearch() {
  return useContext(SearchContext);
}
