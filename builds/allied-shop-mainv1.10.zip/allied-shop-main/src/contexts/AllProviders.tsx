import { ReactNode, useEffect, useState } from 'react';
import DevExpressProvider from '../contexts/DevExpressProvider';
import ToastProvider from '../contexts/ToastProvider';
import ModalProvider from '../contexts/ModalProvider';
// import SessionProvider from '../contexts/SessionProvider';
import { CartProvider } from './CartProvider';
import {
  getBillingAddress,
  getCart,
  getCartTotals,
  getConfiguration,
  getDefaultAddress,
  getShippingData,
  getShippingDataByTerm,
  getShippingTerms,
  getThirdPartyAddress,
} from '../actions';
import { Address, ShippingCombination, ShippingTerm } from '../types/customer';
import {
  SHIPPING_TERM_COLLECT,
  SHIPPING_TERM_WILL_CALL,
  SHIPPING_TERM_THIRD_PARTY,
  SHIPPING_TERM_PREPAID,
} from '../constants';
import { Configuration } from '../types/utils';
import Loading from '../components/Loading/Loading';

interface ContextType {
  configuration?: Configuration;
  serverCart: {};
  serverAddress?: Address;
  billingAddress?: Address;
  thirdPartyAddress?: Address;
  shippingTerm?: ShippingTerm;
  willCallTerm?: ShippingTerm;
  thirdPartyTerm?: ShippingTerm;
  prepaidTerm?: ShippingTerm;
  shippingCombinations: ShippingCombination[];
  prepaidCombinations: ShippingCombination[];
}

export default function AllProviders({
  isAuthenticated,
  children,
}: {
  isAuthenticated: boolean;
  children: ReactNode;
}) {
  // const [cartContextValues, setCartContextValues] = useState<ContextType>({
  //   serverCart: {},
  //   shippingCombinations: [],
  //   prepaidCombinations: []
  // })
  const [cartContextValues, setCartContextValues] = useState<ContextType | null>(null)


  // Adjust the cart data for the Context
  let serverCart = {};
  // filter the shipping terms
  let shippingTerm: ShippingTerm | undefined, willCallTerm: ShippingTerm | undefined, thirdPartyTerm: ShippingTerm | undefined, prepaidTerm: ShippingTerm | undefined;


  useEffect(() => {

    const fetchAllResponses = async () => {
      const configResponse = await getConfiguration();
      const cartResponse = await getCart();
      const cartTotalsResponse = await getCartTotals();
      const cartDefaultAddressResponse = await getDefaultAddress();
      const billingAddressResponse = await getBillingAddress();
      const thirdPartyAddressResponse = await getThirdPartyAddress();
      const userShippingTermsResponse = await getShippingTerms();
      const shippingDataResponse = await getShippingData();

      if (cartResponse) {
        serverCart = {
          id: cartResponse.id,
          count: cartResponse.items.length,
          items: cartResponse.items,
          totals: cartTotalsResponse,
        };
      }

      if (userShippingTermsResponse) {
        shippingTerm = userShippingTermsResponse.find(
          (term: any) => SHIPPING_TERM_COLLECT === term.code,
        );
        willCallTerm = userShippingTermsResponse.find(
          (term: any) => SHIPPING_TERM_WILL_CALL === term.code,
        );
        thirdPartyTerm = userShippingTermsResponse.find(
          (term: any) => SHIPPING_TERM_THIRD_PARTY === term.code,
        );
        prepaidTerm = (userShippingTermsResponse.find(
          (term: any) => SHIPPING_TERM_PREPAID === term.code,
        ));
      }

      let prepaidCombinations = [] as ShippingCombination[];

      if (prepaidTerm) {
        prepaidCombinations = (await getShippingDataByTerm(prepaidTerm.id)) ?? [];
      }


      setCartContextValues({
        configuration: configResponse,
        serverCart: serverCart,
        serverAddress: cartDefaultAddressResponse,
        billingAddress: billingAddressResponse,
        thirdPartyAddress: thirdPartyAddressResponse,
        shippingCombinations: shippingDataResponse ?? [],
        shippingTerm,
        willCallTerm,
        thirdPartyTerm,
        prepaidTerm,
        prepaidCombinations,
      });

    }
    
    // if (isAuthenticated) fetchAllResponses();
    fetchAllResponses();

  }, [])

  return (
    cartContextValues ?
      <DevExpressProvider>
        <ToastProvider>
          <CartProvider {...cartContextValues}>
            <ModalProvider>{children}</ModalProvider>
          </CartProvider>
        </ToastProvider>
      </DevExpressProvider>
      : <Loading />
  );
}
