

import {
  createContext,
  ReactNode,
  useContext,
  useState,
  useCallback,
  useEffect,
} from 'react';
import Modal from '../components/Modal/Modal';

interface ModalContextProps {
  openModal: (
    _component: ReactNode,
    _title: string,
    _extraClasses?: string[],
    _useDrawer?: boolean,
  ) => void;
  closeModal: () => void;
}

export const ModalContext = createContext<ModalContextProps>({
  openModal: () => {},
  closeModal: () => {},
});

export default function ModalProvider({
  children,
}: Readonly<{
  children: ReactNode;
}>) {
  const [showModal, setShowModal] = useState(false);
  const [modalTitle, setModalTitle] = useState('');
  const [modalComponent, setModalComponent] = useState<ReactNode>();
  const [modalExtraClasses, setModalExtraClasses] = useState<string[]>([]);
  const [isDrawer, setIsDrawer] = useState(false);

  const openModal = useCallback(
    (
      modalContent: ReactNode,
      title: string = '',
      extraClasses: string[] = [],
      useDrawer: boolean = false,
    ) => {
      if (modalContent) {
        setModalComponent(modalContent);
        setModalTitle(title);
        setModalExtraClasses(extraClasses);
        setIsDrawer(useDrawer);
        setShowModal(true);
      }
    },
    [],
  );

  const closeModal = useCallback(() => {
    setShowModal(false);
    setModalComponent(undefined);
    setModalTitle('');
    setModalExtraClasses([]);
    setIsDrawer(false);
  }, []);

  const handleCancel = useCallback(() => {
    closeModal();
  }, [closeModal]);

  const handleEsc = useCallback(
    (event: any) => {
      if (event.key === 'Escape') {
        closeModal();
      }
    },
    [closeModal],
  );

  useEffect(() => {
    document.addEventListener('keydown', handleEsc, false);

    return () => {
      document.removeEventListener('keydown', handleEsc, false);
    };
  }, [handleEsc]);

  const store = {
    openModal,
    closeModal,
  };

  return (
    <ModalContext.Provider value={store}>
      {children}
      <Modal
        showModal={showModal}
        title={modalTitle}
        component={modalComponent}
        extraClasses={modalExtraClasses}
        onCancel={handleCancel}
        isDrawer={isDrawer}
      />
    </ModalContext.Provider>
  );
}

export function useModal() {
  return useContext(ModalContext);
}
