

import {
  createContext,
  ReactNode,
  useContext,
  useState,
  useCallback,
} from 'react';
import { v4 as uuidv4 } from 'uuid';
import { ToastType } from '../components/Toast/Toast';
import ToastContainer from '../components/Toast/ToastContainer';

interface ToastContextProps {
  messages: ToastType[];
  createToast: (
    _message: ReactNode,
    _type: 'info' | 'error' | 'success',
  ) => void;
  removeToast: (_id: string) => void;
}

export const ToastContext = createContext<ToastContextProps>({
  messages: [],
  createToast: () => {},
  removeToast: () => {},
});

export default function ToastProvider({
  children,
}: Readonly<{
  children: ReactNode;
}>) {
  const [messages, setMessages] = useState<ToastType[]>([]);

  const createToast = useCallback(
    (
      message: ReactNode,
      type: 'info' | 'error' | 'success' = 'info',
      id: string = uuidv4(),
    ) => {
      setMessages((currentMessages) => {
        const newMessages = [...currentMessages];
        newMessages.push({ id, message, type });
        return newMessages;
      });
    },
    [],
  );

  const removeToast = useCallback((id: string) => {
    // Do something
    setTimeout(() => {
      setMessages((currentMessages) => {
        const newMessages = [...currentMessages];

        const toastIndex = newMessages.findIndex(
          (message) => id === message.id,
        );

        newMessages.splice(toastIndex, 1);

        return newMessages;
      });
    }, 2000);
  }, []);

  const store = {
    messages,
    createToast,
    removeToast,
  };

  return (
    <ToastContext.Provider value={store}>
      {children}
      <ToastContainer />
    </ToastContext.Provider>
  );
}

export function useToast() {
  return useContext(ToastContext);
}
