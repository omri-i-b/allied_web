

/**
 * This sets the license key for DevExpress
 */

import { createContext, ReactNode } from 'react';
import config from 'devextreme/core/config';
import { licenseKey } from '../devextreme-license';
config({ licenseKey });

export const DevExpressContext = createContext({});

export default function DevExpressProvider({
  children,
}: Readonly<{
  children: ReactNode;
}>) {
  return (
    <DevExpressContext.Provider value={{}}>
      {children}
    </DevExpressContext.Provider>
  );
}
