import {
  ADDRESS_TYPE_SHIPPING,
  BASKET_STATUS_ACTIVE,
  BASKET_STATUS_DRAFT,
  PARTS_IMAGE_BASE,
} from '../constants';
import { fetchCategories } from './categories';
import slugify from 'slugify';
import {
  APIResponseGetAddressByCustomerAndType,
  APIResponseCalculateEstimatedShipPickUpDate,
  APIResponseSearchWebOrderDetail,
  APIResponseSearchWebOrders,
  APIResponseSearchBasketDetails,
  APIResponseSearchBaskets,
  APIResponseGetShipTerms,
  APIResponseGetCarrierShipViaCombinations,
  APIResponseGetCandidates,
} from '../types/api';
import { Address, Order, OrderItem } from '../types/customer';
import { getStore } from '../utils/getStore';

/**
 * Fetch Customer Addresses
 */
export async function fetchAddresses(type = ADDRESS_TYPE_SHIPPING) {
  const store = await getStore();
  const { accessToken, customerId } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Address/GetAddressByCustomerAndType?customerId=${customerId}&addressTypeId=${type}`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const response: APIResponseGetAddressByCustomerAndType = await request.json();

  const addresses: Address[] = response.addresses.map(
    ({
      id,
      customizedOrganizationName,
      address,
      address2,
      cityName,
      stateCode,
      zipCode,
      isDefault,
    }) => {
      return {
        id,
        name: customizedOrganizationName,
        street1: address,
        street2: address2,
        city: cityName,
        state: stateCode,
        postalCode: zipCode,
        isDefault,
      } as Address;
    },
  );

  return {
    success: true,
    addresses,
  };
}

/**
 *
 * @returns Create a customer address
 */
export async function fetchCreateAddress(
  customizedOrganizationName: string,
  address: string,
  address2: string,
  city: number,
  state: number,
  zipCode: string,
  country: number,
  isVerified: boolean = false,
  addressTypeId: number = ADDRESS_TYPE_SHIPPING,
) {
  const store = await getStore();
  const { accessToken, customerId, organizationId } = store?.getState();


  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Address/CreateCustomerAddress`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        customizedOrganizationName,
        address,
        address2,
        city,
        state,
        zipCode,
        country,
        addressTypeId,
        organizationId: organizationId,
        customerId: customerId,
        verify: isVerified,
        // default: isDefault,
        isJobSide: false,
      }),
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const { addressId } = await request.json();

  return {
    success: true,
    addressId,
  };
}

/**
 * Validate UPS Address
 */
export async function fetchUPSAddress(
  address: string,
  cityName: string,
  stateCode: string,
  zipCode: string,
  countryCode: string,
) {
  const store = await getStore();
  const { accessToken } = store?.getState();


  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Address/GetCandidates`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        address,
        countryCode,
        stateCode,
        cityName,
        zipCode,
      }),
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const { candidates }: APIResponseGetCandidates = await request.json();

  return {
    success: true,
    addresses: candidates,
  };
}

/**
 * Get the customers shipping terms
 */
export async function fetchShippingTerms() {
  const store = await getStore();
  const { accessToken, customerId, organizationId } = store?.getState();


  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Address/GetShipTerms?organizationId=${organizationId}&customerId=${customerId}`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const response: APIResponseGetShipTerms = await request.json();

  return {
    success: true,
    shipTerms: response.shipTerms,
  };
}

/**
 * Get the shipping combinations
 */
export async function fetchShippingData() {
  const store = await getStore();
  const { accessToken, customerId, organizationId } = store?.getState();


  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Address/GetCarrierShipViaCombinations?organizationId=${organizationId}&customerId=${customerId}&isSaleable=true`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const response: APIResponseGetCarrierShipViaCombinations =
    await request.json();

  return {
    success: true,
    combinations: response.combinations,
  };
}

/**
 * Get the prepaid combinations
 */
export async function fetchShippingDataByTerm(shipTermId: number) {
  const store = await getStore();
  const { accessToken, customerId, organizationId } = store?.getState();


  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Address/GetCarrierShipViaCombinations?organizationId=${organizationId}&customerId=${customerId}&shipTermId=${shipTermId}&isSaleable=true`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const response: APIResponseGetCarrierShipViaCombinations =
    await request.json();

  return {
    success: true,
    combinations: response.combinations,
  };
}

/**
 * Get the estimated ship date
 */
export async function fetchEstimatedShipPickupDate(
  shipViaId: number,
  ecommerceWarehouseId: number,
) {
  const store = await getStore();
  const { accessToken } = store?.getState();


  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Address/CalculateEstimatedShipPickUpDate?shipViaId=${shipViaId}`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify([ecommerceWarehouseId]),
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const response: APIResponseCalculateEstimatedShipPickUpDate =
    await request.json();

  return {
    success: true,
    estimatedShipPickUpDate: response.estimatedShipPickUpDate,
  };
}

export async function fetchOrders(statusId?: number, date?: string) {
  const store = await getStore();
  const { accessToken, customerId, id } = store?.getState();


  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const params: {
    pageIndex: number;
    pageSize: number;
    customerId: number;
    customerPortalUserId: string;
    statusId?: number;
    dateFrom?: string;
    dateTo?: string;
  } = {
    pageIndex: 1,
    pageSize: 100,
    customerId: customerId,
    customerPortalUserId: id,
    // number: "",
    // dateFrom: "2024-07-09T23:09:01.015Z",
    // dateTo: "2024-07-09T23:09:01.015Z",
    // statusId: 0
  };

  if (statusId) {
    params.statusId = statusId;
  }

  if (date) {
    const startDate = new Date(date);
    const endDate = new Date(startDate);

    params.dateFrom = startDate.toISOString();
    params.dateTo = endDate.toISOString();
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/WebOrder/SearchWebOrders`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(params),
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const response: APIResponseSearchWebOrders = await request.json();

  const orders = response.webOrdersPaginable.results.map((result) => {
    return {
      id: result.id,
      status: result.stateDescription,
      number: result.number,
      date: result.date,
      purchaseOrderNumber: result.customerPurchaseOrderNumber,
      salesOrderNumber: result.salesOrderMasterNumber,
      total: result.total,
    } as Order;
  });

  return {
    success: true,
    statusList: response.webOrderStateList,
    orders,
  };
}

export async function fetchOrderById(webOrderId: number) {
  const store = await getStore();
  const { accessToken } = store?.getState();


  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const orderPromise = fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/WebOrder/SearchWebOrderDetail`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        webOrderId,
      }),
    },
  );

  // Get the categories
  const categoriesPromise = fetchCategories();

  const [orderResponse, categoriesResponse] = await Promise.all([
    orderPromise,
    categoriesPromise,
  ]);

  if (!orderResponse.ok) {
    return {
      success: false,
      error: orderResponse.status,
    };
  }

  const { order }: APIResponseSearchWebOrderDetail = await orderResponse.json();
  const { categories } = categoriesResponse;

  if (!categories) {
    return {
      success: false,
    };
  }

  const subtotal = order.lines.reduce(
    (total, item) => total + item.price * item.multiplier,
    0,
  );

  const taxes = order.lines.reduce((total, item) => total + item.taxAmount, 0);

  return {
    success: true,
    order: {
      id: order.id,
      date: order.date,
      number: order.number,
      status: order.stateDescription,
      purchaseOrderNumber: order.customerPurchaseOrderNumber,
      salesOrderNumber: order.salesOrderMasterNumber,
      itemCount: order.lines.length || 0,
      items: order.lines.map((line) => {
        const category = categories?.find((c) => c.id === line.partCategoryId);

        const subcategory = category?.subcategories?.find(
          (s) => s.id === line.partShapeId,
        );

        return {
          id: line.id,
          productId: line.partId,
          name: line.partDescription,
          price: line.price * line.multiplier,
          quantity: line.qtyToOrder,
          weight: 0, // TODO: Need Weight
          //image: `${process.env.REACT_APP_ALLIED_ECOM_API}/${PARTS_IMAGE_BASE}/${line.fileName}`,
          image: `${process.env.REACT_APP_ALLIED_ECOM_API}/${PARTS_IMAGE_BASE}organizationId=${line.manageOrganizationId}&categoryId=${line.partCategoryId}&shapeId=${line.partShapeId}`,
          categoryId: line.partCategoryId,
          subcategoryId: line.partShapeId,
          manufacturer: line.manufacturerTypeDescription,
          warehouse: line.ecommerceWarehouseDescription,
          carrier: line.carrierDescription,
          freightNumber: line.customerFreightCollectAccountNumber,
          shipTermCode: line.shipTermCode,
          shipDate: line.requiredShipDate,
          slug: `/products/${category?.slug}/${subcategory?.slug}/${line.partId}/${slugify(
            line.partDescription,
            {
              lower: true,
              strict: true,
            },
          )}`,
        } as OrderItem;
      }),
      shipTo: order.shipTo
        ? ({
          name: order.shipTo.customizedOrganizationName,
          street1: order.shipTo.address,
          street2: order.shipTo.address2,
          city: order.shipTo.cityDescription,
          state: order.shipTo.stateCode,
          postalCode: order.shipTo.zipCode,
        } as Address)
        : null,
      billTo: order.billTo
        ? ({
          name: order.billTo.customizedOrganizationName,
          street1: order.billTo.address,
          street2: order.billTo.address2,
          city: order.billTo.cityDescription,
          state: order.billTo.stateCode,
          postalCode: order.billTo.zipCode,
        } as Address)
        : null,
      subtotal,
      taxes,
      total: order.total,
      notes: order.notes,
      portalUrl: order.somUrlPortal,
    } as Order,
  };
}

export async function fetchSavedCarts() {
  const store = await getStore();
  const { accessToken, customerId, id } = store?.getState();


  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/SearchBaskets`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        pageIndex: 1,
        pageSize: 25,
        customerId: customerId,
        customerPortalUserId: id,
      }),
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const response: APIResponseSearchBaskets = await request.json();

  return {
    success: true,
    total: response.basketsPaginable.total,
    savedCarts: response.basketsPaginable.results ?? [],
  };
}

export async function fetchSavedCart(basketId: number) {
  const store = await getStore();
  const { accessToken, customerId, id } = store?.getState();


  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const cartPromise = fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/SearchBasketDetail`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        basketId,
        customerId: customerId,
        customerPortalUserId: id,
      }),
    },
  );

  // Get the categories
  const categoriesPromise = fetchCategories();

  const [cartResponse, categoriesResponse] = await Promise.all([
    cartPromise,
    categoriesPromise,
  ]);

  if (!cartResponse.ok) {
    return {
      success: false,
      error: cartResponse.status,
    };
  }

  const { basket }: APIResponseSearchBasketDetails = await cartResponse.json();
  const { categories } = categoriesResponse;

  if (!categories) {
    return {
      success: false,
    };
  }

  return {
    success: true,
    savedCart: {
      id: basket.id,
      notes: basket.notes.trim(),
      count: basket.items.length,
      items: basket.items.map((item) => {
        const category = categories?.find((c) => c.id === item.partCategoryId);

        const subcategory = category?.subcategories?.find(
          (s) => s.id === item.partShapeId,
        );

        return {
          cartId: item.id,
          productId: item.partId,
          name: item.partDescription,
          price: item.price * item.multiplier,
          quantity: item.qty,
          weight: item.weight,
          categoryId: item.partCategoryId,
          subcategoryId: item.partShapeId,
          //image: `${process.env.REACT_APP_ALLIED_ECOM_API}/${PARTS_IMAGE_BASE}/${item.fileName}`,
          image: `${process.env.REACT_APP_ALLIED_ECOM_API}/${PARTS_IMAGE_BASE}organizationId=${item.manageOrganizationId}&categoryId=${item.partCategoryId}&shapeId=${item.partShapeId}`,
          manufacturerId: item.manufacturerTypeId,
          manufacturerCode: item.manufacturerTypeCode,
          manufacturerName: item.manufacturerTypeDescription,
          warehouseId: item.ecommerceWarehouseId,
          warehouseCode: item.ecommerceWarehouseCode,
          warehouseName: item.ecommerceWarehouseDescription,
          warehousePrice: item.price,
          warehouseMultiplier: item.multiplier,
          shipTermId: item.shipTermId,
          slug: `/products/${category?.slug}/${subcategory?.slug}/${item.partId}/${slugify(
            item.partDescription,
            {
              lower: true,
              strict: true,
            },
          )}`,
        };
      }),
    },
  };
}

export async function fetchSaveCart(basketId: number, notes: string = ' ') {
  const store = await getStore();
  const { accessToken, customerId, id } = store?.getState();


  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/ChangeBasketStatus`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        basketId,
        customerId: customerId,
        customerPortalUserId: id,
        statusId: BASKET_STATUS_DRAFT,
        forceChange: 0,
        notes,
      }),
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  return {
    success: true,
  };
}

export async function fetchReplaceCart(basketId: number, notes?: string) {
  const store = await getStore();
  const { accessToken, customerId, id } = store?.getState();


  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/ChangeBasketStatus`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        basketId,
        customerId: customerId,
        customerPortalUserId: id,
        statusId: BASKET_STATUS_ACTIVE,
        forceChange: 1,
        notes,
      }),
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  return {
    success: true,
  };
}

export async function fetchDeleteCart(basketId: number) {
  const store = await getStore();
  const { accessToken } = store?.getState();


  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/DeleteBasketById?basketId=${basketId}`,
    {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  return {
    success: true,
  };
}
