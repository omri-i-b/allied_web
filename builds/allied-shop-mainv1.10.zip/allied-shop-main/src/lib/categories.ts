import { APIResponseSearchParts } from "../types/api";
import { Category, Subcategory } from '../types/categories';
import slugify from 'slugify';
import { getStore } from "../utils/getStore";
import { imageLookup } from ".././image-lookup";


export async function fetchCategories() {
    
    // Cache the categories for the session
    const cache = sessionStorage.getItem('CATEGORIES')
    if (cache) {
        return JSON.parse(cache);
    }

    
    const store = await getStore();
    const { accessToken } = store?.getState();

    if (!accessToken) {
        return {
            success: false,
            error: 401,
        };
    }
    
    
    const request = await fetch(
        `${process.env.REACT_APP_ALLIED_ECOM_API}/Part/SearchPartsV2`,
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${accessToken}`,
            },
            body: JSON.stringify({
                pageIndex: 1,
                pageSize: 100,
                partDescription: '',
                categories: [],
            }),
            // next: {
            //     revalidate: 3600,
            // },
        },
    );

    
    if (!request.ok) {
        return {
            success: false,
            error: request.status,
        };
    }

    const data: APIResponseSearchParts = await request.json();

    const categories =
        (await Promise.all(
            data.categories.map(
                async (category: { id: number; description: string; qty: number }) => {
                    const response = await fetchSubcategories(category.id);

                    const { subcategories } = response || [];
                    
                    let categoryImages: any;

                    for (let key in imageLookup) {
                      if (+key === category.id) {
                        categoryImages = imageLookup[key as keyof typeof imageLookup];
                        break;
                      }
                    }

                    return {
                        id: category.id,
                        title: category.description,
                        slug: slugify(category.description, { lower: true, strict: true }),
                        // image: `${process.env.REACT_APP_ALLIED_ECOM_API}/${PARTS_IMAGE_BASE}/category_${category.id}.png`,
                        image: categoryImages?.[0],
                        count: category.qty,
                        subcategories,
                    } as Category;
                },
            ),
        )) ?? ([] as Category[]);

    
    const res = {
        success: true,
        categories,
    };

    sessionStorage.setItem('CATEGORIES', JSON.stringify(res));

    return res;
}

export async function fetchSubcategories(categoryId: number) {
    const store = await getStore();
    const { accessToken } = store?.getState();

    if (!accessToken) {
        throw Error('Request was not completed successfully');
    }

    const request = await fetch(
        `${process.env.REACT_APP_ALLIED_ECOM_API}/Part/SearchPartsV2`,
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${accessToken}`,
            },
            body: JSON.stringify({
                pageIndex: 1,
                pageSize: 100,
                partDescription: '',
                categories: [categoryId],
            }),
            // next: {
            //     revalidate: 3600,
            // },
        },
    );

    if (!request.ok) {
        return {
            success: false,
            error: request.status,
        };
    }

    const data: APIResponseSearchParts = await request.json();

    return {
        success: true,
        subcategories:
            data.shapes.map(
                (shape: { id: number; description: string; qty: number }) => {

                    let subcategoryImages: any;

                    for (let key in imageLookup) {
                      if (shape && +key === categoryId) {
                        subcategoryImages = imageLookup[key as keyof typeof imageLookup];

                        break;
                      }
                    }

                    return {
                        id: shape.id,
                        title: shape.description,
                        slug: slugify(shape.description, { lower: true, strict: true }),
                        //image: `${process.env.REACT_APP_ALLIED_ECOM_API}/${PARTS_IMAGE_BASE}/subcategory_${shape.id}.png`,
                        image: subcategoryImages?.[shape.id],
                        count: shape.qty,
                    } as Subcategory;
                },
            ) ?? [],
    };
}

export async function fetchFilterGroups(
    categoryId: number,
    subcategoryId: number,
) {
    const store = await getStore();
    const { accessToken } = store?.getState();

    if (!accessToken) {
        throw Error('Request was not completed successfully');
    }

    // Cache the categories for the session
    const cache = sessionStorage.getItem('FILTER_GROUPS')
    if (cache) {
        return JSON.parse(cache);
    }

    const request = await fetch(
        `${process.env.REACT_APP_ALLIED_ECOM_API}/Part/SearchPartsV2`,
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${accessToken}`,
            },
            body: JSON.stringify({
                pageIndex: 1,
                pageSize: 1,
                partDescription: '',
                categories: [categoryId],
                shapes: [subcategoryId],
            }),
            // next: {
            //     revalidate: 3600,
            // },
        },
    );

    if (!request.ok) {
        throw Error('Request was not completed successfully');
    }

    const data: APIResponseSearchParts = await request.json();

    const res = [
        {
            title: 'Size (Inch)',
            slug: 'sizes',
            filters: data.sizes.map(
                (filter: { id: number; description: string; qty: number }) => {
                    return {
                        id: filter.id,
                        name: `${filter.description}"`,
                        count: filter.qty,
                    };
                },
            ),
        },
        {
            title: 'Schedule',
            slug: 'schedules',
            filters: data.schedules.map(
                (filter: { id: number; description: string; qty: number }) => {
                    return { id: filter.id, name: filter.description, count: filter.qty };
                },
            ),
        },
        {
            title: 'Grade',
            slug: 'grades',
            filters: data.grades.map(
                (filter: { id: number; description: string; qty: number }) => {
                    return { id: filter.id, name: filter.description, count: filter.qty };
                },
            ),
        },
        {
            title: 'Pressure',
            slug: 'pressures',
            filters: data.pressures.map(
                (filter: { id: number; description: string; qty: number }) => {
                    return { id: filter.id, name: filter.description, count: filter.qty };
                },
            ),
        },
    ];

    sessionStorage.setItem('FILTER_GROUPS', JSON.stringify(res))

    return res;
}
