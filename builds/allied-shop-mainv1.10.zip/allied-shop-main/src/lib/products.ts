import slugify from 'slugify';
import { convertSizesToString } from '../utils/sizesToString';
import {
  FACET_CATEGORY,
  FACET_GRADE,
  FACET_PRESSURE,
  FACET_SCHEDULE,
  FACET_SHAPE,
  FACET_SIZE1,
  FACET_SIZE2,
  FACET_SIZE3,
  FACET_SIZE4,
  FACET_SUBCATEGORY,
  PARTS_IMAGE_BASE,
} from '../constants';
import { fetchCategories } from './categories';
import {
  APIResponeFrequentlyBoughtTogether,
  APIResponseAlgoliaPreSearch,
  APIResponseAlgoliaSearch,
  APIResponseProduct,
  APIResponseSearchParts,
} from '../types/api';
import { Product } from '../types/products';
import { getStore } from '../utils/getStore';
import { Category, Subcategory } from '../types/categories';

export async function fetchAllManufacturers() {
  const store = await getStore();
  const { accessToken, organizationId } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  // Cache the categories for the session
  const cache = sessionStorage.getItem('MANUFACTURERS')
  if (cache) {
    return JSON.parse(cache);
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Manufacturer/GetAvailableManufacturerTypes?organizationId=${organizationId}`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const data = await request.json();

  const manufacturers =
    data.manufacturerTypes.map(
      (manufacturer: { id: number; code: string; description: string }) => {
        return {
          id: manufacturer.id,
          code: manufacturer.code,
          name: manufacturer.description,
        };
      },
    ) ?? [];

  const res = {
    success: true,
    manufacturers,
  };

  sessionStorage.setItem('MANUFACTURERS', JSON.stringify(res));

  return res;
}

export async function fetchAllWarehouses() {
  const store = await getStore();
  const { accessToken, organizationId } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  // Cache the categories for the session
  const cache = sessionStorage.getItem('WAREHOUSES')
  if (cache) {
    return JSON.parse(cache);
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Warehouse/GetEcommerceWarehouses?organizationId=${organizationId}`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const data = await request.json();

  const warehouses =
    data.warehouses.map(
      (warehouse: { id: number; code: string; description: string }) => {
        return {
          id: warehouse.id,
          code: warehouse.code,
          name: warehouse.description,
        };
      },
    ) ?? [];

  const res = {
    success: true,
    warehouses,
  };

  sessionStorage.setItem('WAREHOUSES', JSON.stringify(res));

  return res;
}

export async function fetchWarehousesWithAvailability(basketId: number) {
  const store = await getStore();
  const { accessToken } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Warehouse/GetWarehouseWithAvailabilityForAllBasketItems?basketId=${basketId}`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const data = await request.json();

  const warehouses =
    data.warehouses.map(
      (warehouse: {
        ecommerceWarehouseId: number;
        ecommerceWarehouseCode: string;
        ecommerceWarehouseDescription: string;
      }) => {
        return {
          id: warehouse.ecommerceWarehouseId,
          code: warehouse.ecommerceWarehouseCode,
          name: warehouse.ecommerceWarehouseDescription,
        };
      },
    ) ?? [];

  return {
    success: true,
    warehouses,
  };
}

export async function fetchFilteredProducts(filters: any, page: number = 1) {
  const store = await getStore();
  const { accessToken } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Part/SearchPartsV2`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        pageIndex: page,
        pageSize: 250,
        ...filters,
      }),
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const data: APIResponseSearchParts = await request.json();

  const products =
    data.parts.results.map((part) => {
      let size = convertSizesToString(
        ' in',
        parseFloat(part.partSize1),
        parseFloat(part.partSize2),
        parseFloat(part.partSize3),
        parseFloat(part.partSize4),
      );

      let pressure = part.partPressureClass
        ? `${part.partPressureClass} lb`
        : null;

      return {
        id: part.id,
        sku: part.number,
        size,
        title: part.description,
        grade: part.partGrade,
        schedule: part.partSchedule,
        group: part.partGroup,
        material: part.partMaterial,
        pressure,
        slug: slugify(part.number, { lower: true, strict: true }),
      } as Product;
    }) ?? ([] as Product[]);

  return {
    success: true,
    total: data.parts.total,
    products,
  };
}

export async function fetchBestSellers(categoryId?: number) {
  const store = await getStore();
  const { accessToken } = store?.getState();

  // TODO: Best Sellers by Category?

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  // Cache the categories for the session
  const cache = sessionStorage.getItem('BEST_SELLERS')
  if (cache) {
    return JSON.parse(cache);
  }

  // Fetch the best sellers
  const bestSellersPromise = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Part/MostFrequentlyPurchasedParts`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        limit: 8,
      }),
    },
  );

  // Get the categories
  const categoriesPromise = await fetchCategories();

  const [bestSellersResponse, categoriesResponse] = await Promise.all([
    bestSellersPromise,
    categoriesPromise,
  ]);

  if (!bestSellersResponse.ok) {
    return {
      success: false,
      error: bestSellersResponse.status,
    };
  }

  const data = await bestSellersResponse.json();
  const { categories } = categoriesResponse;

  const products =
    data.parts.map(
      (part: {
        id: number;
        number: string;
        description: string;
        partCategoryId: number;
        partShapeId: number;
        fileName: string;
        manageOrganizationId: number;
      }) => {
        const category = categories?.find((c: Category) => c.id === part.partCategoryId);

        if (!category) {
          return false;
        }

        const subcategory = category.subcategories?.find(
          (s: Subcategory) => s.id === part.partShapeId,
        );

        return {
          id: part.id,
          sku: part.number,
          title: part.description,
          image: `${process.env.REACT_APP_ALLIED_ECOM_API}/${PARTS_IMAGE_BASE}organizationId=${part.manageOrganizationId}&categoryId=${category.id}&shapeId=${part.partShapeId}`,
          categoryId: part.partCategoryId,
          subcategoryId: part.partShapeId,
          slug: `/products/${category.slug}/${subcategory?.slug}/${part.id}/${slugify(
            part.description,
            {
              lower: true,
              strict: true,
            },
          )}`,
        };
      },
    ) ?? ([] as Product[]);

  const res = {
    success: true,
    products,
  };

  sessionStorage.setItem('BEST_SELLERS', JSON.stringify(res));

  return res;
}

export async function fetchPreSearch(text: string) {
  const request = await fetch(
    `https://${process.env.REACT_APP_PUBLIC_ALGOLIA_APP_ID}-dsn.algolia.net/1/indexes/*/queries`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Algolia-API-Key': `${process.env.REACT_APP_PUBLIC_ALGOLIA_KEY}`,
        'X-Algolia-Application-Id': `${process.env.REACT_APP_PUBLIC_ALGOLIA_APP_ID}`,
      },
      body: JSON.stringify({
        requests: [
          {
            indexName: 'qa_alliedStore',
            query: text,
            hitsPerPage: 8,
            facets: [FACET_CATEGORY,
              FACET_SUBCATEGORY,
              FACET_GRADE,
              FACET_SHAPE,
              FACET_SIZE1,
              FACET_SIZE2,
              FACET_SIZE3,
              FACET_SIZE4,
              FACET_SCHEDULE,
              FACET_PRESSURE
            ],
          },
          {
            indexName: 'qa_alliedStore_query_suggestions',
            query: text,
            hitsPerPage: 3,
          },
        ],
      }),
      // next: {
      //   revalidate: 3600,
      // },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const { categories } = await fetchCategories();

  const { results }: APIResponseAlgoliaPreSearch = await request.json();

  const [queryResponse, suggestionResponse] = results;

  const products =
    queryResponse.hits.map((part) => {
      const category = categories?.find((c) => c.id === part.partCategoryId);

      if (!category) {
        return false;
      }

      const subcategory = category.subcategories?.find(
        (s) => s.id === part.partShapeId,
      );

      return {
        id: part.id,
        sku: part.number,
        title: part.description,
        image: `${process.env.REACT_APP_ALLIED_ECOM_API}/${PARTS_IMAGE_BASE}organizationId=${part.manageOrganizationId}&categoryId=${category.id}&shapeId=${part.partShapeId}`,
        categoryId: part.partCategoryId,
        subcategoryId: part.partShapeId,
        grade: part.partGrade,
        group: part.partGroup,
        material: part.partMaterial,
        shape: part.partShape,
        size1: part.partSize1,
        size2: part.partSize2,
        size3: part.partSize3,
        size4: part.partSize4,
        schedule: part.partSchedule,
        pressure: part.partPressureClass,
        slug: `/products/${category.slug}/${subcategory?.slug}/${part.id}/${slugify(
          part.description,
          {
            lower: true,
            strict: true,
          },
        )}`,
      } as Product;
    }) ?? undefined;

  const SLICE_LIMIT = 10;

  const categoryFacets =
    Object.keys(queryResponse?.facets?.partCategory ?? {})
      .map((item) => {
        const category = categories?.find((c) => item === c.title);

        if (!category) {
          return false;
        }

        return {
          id: category.id,
          title: category?.title,
          slug: `/products/${category?.slug}`,
          image: category?.image,
          facet: item,
        };
      })
      .filter((i) => i !== undefined)
      .slice(0, SLICE_LIMIT) ?? undefined;


  const gradeNames = Object.keys(queryResponse?.facets?.partGrade ?? {});
  const gradeFacets = !gradeNames ? [] : products.filter((p: any) => gradeNames.includes(p.grade)).filter((i) => i !== undefined).slice(0, SLICE_LIMIT) ?? undefined;

  const shapeNames = Object.keys(queryResponse?.facets?.partShape ?? {});
  const shapeFacets = !shapeNames ? [] : products.filter((p: any) => shapeNames.includes(p.shape)).filter((i) => i !== undefined).slice(0, SLICE_LIMIT) ?? undefined;

  const scheduleNames = Object.keys(queryResponse?.facets?.partSchedule ?? {});
  const scheduleFacets = !scheduleNames ? [] : products.filter((p: any) => scheduleNames.includes(p.schedule)).filter((i) => i !== undefined).slice(0, SLICE_LIMIT) ?? undefined;
  
  const pressureNames = Object.keys(queryResponse?.facets?.partPressureClass ?? {});
  const pressureFacets = !pressureNames ? [] : products.filter((p: any) => pressureNames.includes(p.pressure)).filter((i) => i !== undefined).slice(0, SLICE_LIMIT) ?? undefined;

  const size1Names = Object.keys(queryResponse?.facets?.partSize1 ?? {});
  const size1Facets = !size1Names ? [] : products.filter((p: any) => size1Names.includes(p.size1)).filter((i) => i !== undefined).slice(0, SLICE_LIMIT) ?? undefined;

  const size2Names = Object.keys(queryResponse?.facets?.partSize2 ?? {});
  const size2Facets = !size2Names ? [] : products.filter((p: any) => size2Names.includes(p.size2)).filter((i) => i !== undefined).slice(0, SLICE_LIMIT) ?? undefined;
  
  const size3Names = Object.keys(queryResponse?.facets?.partSize3 ?? {});
  const size3Facets = !size3Names ? [] : products.filter((p: any) => size3Names.includes(p.size3)).filter((i) => i !== undefined).slice(0, SLICE_LIMIT) ?? undefined;

  const size4Names = Object.keys(queryResponse?.facets?.partSize4 ?? {});
  const size4Facets = !size4Names ? [] : products.filter((p: any) => size4Names.includes(p.size4)).filter((i) => i !== undefined).slice(0, SLICE_LIMIT) ?? undefined;
  const suggestions = suggestionResponse.hits ?? undefined;

  return {
    success: true,
    products,
    categories: categoryFacets,
    gradeProducts: gradeFacets,
    shapeProducts: shapeFacets,
    scheduleProducts: scheduleFacets,
    pressureProducts: pressureFacets,
    size1Products: size1Facets,
    size2Products: size2Facets,
    size3Products: size3Facets,
    size4Products: size4Facets,
    suggestions,
  };
}

export async function fetchSearch(query: string, facetFilters?: string[][]) {
  const request = await fetch(
    `https://${process.env.REACT_APP_PUBLIC_ALGOLIA_APP_ID}-dsn.algolia.net/1/indexes/qa_alliedStore/query`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Algolia-API-Key': `${process.env.REACT_APP_PUBLIC_ALGOLIA_KEY}`,
        'X-Algolia-Application-Id': `${process.env.REACT_APP_PUBLIC_ALGOLIA_APP_ID}`,
      },
      body: JSON.stringify({
        query,
        facets: [FACET_CATEGORY,
          FACET_SUBCATEGORY,
          FACET_GRADE,
          FACET_SHAPE,
          FACET_SIZE1,
          FACET_SIZE2,
          FACET_SIZE3,
          FACET_SIZE4,
          FACET_SCHEDULE,
          FACET_PRESSURE
        ],
        facetFilters,
        hitsPerPage: 50,
      }),
      // next: {
      //   revalidate: 3600,
      // },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const { categories } = await fetchCategories();

  const data: APIResponseAlgoliaSearch = await request.json();

  const products =
    (data.hits
      .map((part) => {
        const category = categories?.find((c) => c.id === part.partCategoryId);

        if (!category) {
          return false;
        }

        const subcategory = category.subcategories?.find(
          (s) => s.id === part.partShapeId,
        );

        return {
          id: part.id,
          sku: part.number,
          title: part.description,
          image: `${process.env.REACT_APP_ALLIED_ECOM_API}/${PARTS_IMAGE_BASE}organizationId=${part.manageOrganizationId}&categoryId=${category.id}&shapeId=${part.partShapeId}`,
          categoryId: part.partCategoryId,
          subcategoryId: part.partShapeId,
          grade: part.partGrade,
          group: part.partGroup,
          schedule: part.partSchedule,
          material: part.partMaterial,
          slug: `/products/${category.slug}/${subcategory?.slug}/${part.id}/${slugify(
            part.description,
            {
              lower: true,
              strict: true,
            },
          )}`,
        };
      })
      .filter((i) => i !== undefined) as Product[]) ?? ([] as Product[]);

  var facets = [];

  const categoryFacets = Object.keys(data.facets?.partCategory ?? {})
    .map((item) => {
      const category = categories?.find((c) => item === c.title);

      if (!category) {
        return false;
      }

      return {
        id: category.id,
        title: category?.title,
        slug: `/products/${category?.slug}`,
        image: category?.image,
        count: data.facets?.partCategory[item],
        facet: item,
      };
    })
    .filter((i) => i !== undefined);

  if (categoryFacets) {
    facets.push({
      title: 'Category',
      type: FACET_CATEGORY,
      items: categoryFacets,
    });
  }

  // const subcategoryFacets = Object.keys(
  //   data.facets?.partCategoryId_PartShapeId ?? {},
  // )
  //   .map((item) => {
  //     const split = item.split('|');

  //     const category = categories?.find((c) => parseInt(split[0], 10) === c.id);

  //     if (!category) {
  //       return false;
  //     }

  //     const subcategory = category.subcategories?.find(
  //       (s) => parseInt(split[1], 10) === s.id,
  //     );

  //     if (!subcategory) {
  //       return false;
  //     }

  //     return {
  //       id: subcategory?.id,
  //       prefix: category?.title,
  //       title: subcategory?.title,
  //       slug: `/products/${category?.slug}/${subcategory?.slug}`,
  //       image: subcategory?.image,
  //       count: data.facets?.partCategoryId_PartShapeId[item],
  //       facet: item,
  //     };
  //   })
  //   .filter((i) => i !== undefined);

  // if (subcategoryFacets) {
  //   facets.push({
  //     title: 'Subcategory',
  //     type: FACET_SUBCATEGORY,
  //     items: subcategoryFacets,
  //   });
  // }

  return {
    success: true,
    count: data.nbHits,
    products,
    facets,
  };
}

export async function fetchProduct(partId: number) {
  const store = await getStore();
  const { accessToken } = store?.getState();

  if (!accessToken) {
    throw Error('Request was not completed successfully');
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Part/SearchPartDetail`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        partId,
        pageIndex: 1,
        pageSize: 1,
      }),
      // next: {
      //   revalidate: 3600,
      // },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const { categories } = await fetchCategories();

  const data: APIResponseProduct = await request.json();

  if (!data.part) {
    return {
      success: false,
      error: 404,
    };
  }

  const category = categories?.find((c) => c.id === data.part.partCategoryId);

  const subcategory = category?.subcategories?.find(
    (s) => s.id === data.part.partShapeId,
  );

  const product: Product = {
    id: data.part.id,
    slug: `/products/${category?.slug}/${subcategory?.slug}/${data.part.id}/${slugify(
      data.part.description,
      {
        lower: true,
        strict: true,
      },
    )}`,
    sku: data.part.number,
    title: data.part.description,
    image: `${process.env.REACT_APP_ALLIED_ECOM_API}/${PARTS_IMAGE_BASE}organizationId=${data.part.manageOrganizationId}&categoryId=${category.id}&shapeId=${data.part.partShapeId}`,
    // image: `${process.env.REACT_APP_PUBLIC_ASSET_URL}/${PARTS_IMAGE_BASE}/${data.part.fileName}`,
    categoryId: data.part.partCategoryId,
    subcategoryId: data.part.partShapeId,
    size: data.part.partSize,
    weight: data.part.partWeight,
    grade: data.part.partGradeDescription,
    schedule: data.part.partSchedule,
    material: data.part.partMaterial,
    pressure: data.part.partPressureClass,
    shape: data.part.partShape,
    endConnection: data.part.partEndConnection,
    group: data.part.partGroup,
  };

  return {
    success: true,
    product,
  };
}

export async function fetchProductAvailability(
  partId: number,
  manufacturerTypeId: number,
  qty: number = 1,
  basketId: number,
) {
  const store = await getStore();
  const { accessToken, warehouseId, customerId, id } = store?.getState();


  if (!accessToken) {
    throw Error('Request was not completed successfully');
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Warehouse/GetEcommerceWarehouseWithAvailability`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        partId,
        manufacturerTypeId,
        qty,
        ecommerceWarehouseId: warehouseId,
        customerId: customerId,
        customerPortalUserId: id,
        basketId,
      }),
      cache: 'no-store',
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const data = await request.json();

  const primaryWarehouse = data.mainEcommerceWarehouse
    ? {
      id: data.mainEcommerceWarehouse.ecommerceWarehouseId,
      name: data.mainEcommerceWarehouse.ecommerceWarehouseDescription,
      code: data.mainEcommerceWarehouse.ecommerceWarehouseCode,
      price: data.mainEcommerceWarehouse.price,
      multiplier: data.mainEcommerceWarehouse.multiplier,
      isPrimary: true,
    }
    : null;

  const alternateWarehouses =
    data.alternativeEcommerceWarehouses?.map(
      (alternate: {
        ecommerceWarehouseId: number;
        ecommerceWarehouseDescription: string;
        ecommerceWarehouseCode: string;
        price: number;
        multiplier: number;
      }) => {
        return {
          id: alternate.ecommerceWarehouseId,
          name: alternate.ecommerceWarehouseDescription,
          code: alternate.ecommerceWarehouseCode,
          price: alternate.price,
          multiplier: alternate.multiplier,
          isPrimary: false,
        };
      },
    ) ?? [];

  return {
    success: true,
    primaryWarehouse,
    alternateWarehouses,
  };
}

export async function fetchRelatedProducts(partId: number, limit: number = 3) {
  const store = await getStore();
  const { accessToken } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Part/PartsFrequentlyBoughtTogether`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        partId,
        limit,
      }),
      // next: {
      //   revalidate: 3600,
      // },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const { categories } = await fetchCategories();

  const data: APIResponeFrequentlyBoughtTogether = await request.json();

  if (!categories) {
    return {
      success: false,
    };
  }

  const products =
    data.parts.map((part) => {
      const category = categories?.find((c) => c.id === part.partCategoryId);

      const subcategory = category?.subcategories?.find(
        (s) => s.id === part.partShapeId,
      );

      return {
        id: part.id,
        sku: part.number,
        title: part.description,
        categoryId: part.partCategoryId,
        subcategoryId: part.partShapeId,
        slug: `/products/${category?.slug}/${subcategory?.slug}/${part.id}/${slugify(
          part.description,
          {
            lower: true,
            strict: true,
          },
        )}`,
      } as Product;
    }) ?? ([] as Product[]);

  return {
    success: true,
    products,
  };
}
