import CryptoJS from 'crypto-js';
import {
  APIResponseAuthenticate,
  APIResponseChangePassword,
} from '../types/api';
import { getStore } from '../utils/getStore';
import { logoutUser, setUser, updateUser } from '../redux/slice';
import { jwtDecode } from 'jwt-decode';
import { UserState } from '../types/user';
import { AUTH_STATUS_AUTHENTICATED } from '../constants';

export async function login(email: string, password: string) {
  const store = await getStore();
  const md5Password = CryptoJS.MD5(password).toString();

  // TODO: Change to MD5 Version After we know the new password  
  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/User/Authenticate`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email,
        password: md5Password,
        // password: password,
      }),
      cache: 'no-store',

    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const data: APIResponseAuthenticate = await request.json();
  
  const tokenData: any = jwtDecode(data.token);



  if (!tokenData) {
    return null;
  }


  const dataToSet: UserState = {
    id: tokenData.UserId,
    customerId: tokenData.CustomerId,
    customerName: tokenData.CustomerName,
    customerCode: tokenData.CustomerCode,
    organizationId: tokenData.OrganizationId,
    warehouseId: tokenData.WarehouseId,
    allowChangeWarehouse: tokenData.AllowChangeWarehouse,
    accessToken: data.token,
    email: email,
    firstName: tokenData.UserName,
    lastName: tokenData.UserLastName,
    resetPassword: data.resetPassword,
    status: AUTH_STATUS_AUTHENTICATED  //authenticated, loading, unauthenticated
  }

  store.dispatch(setUser(dataToSet))

  return {
    success: true,
    data,
  };
}

export async function logout() {
  const store = await getStore();
  store.dispatch(logoutUser())
  return {
    success: true,
  };
}

export async function register(
  name: string,
  lastName: string,
  company: string,
  title: string,
  address: string,
  city: string,
  state: string,
  zipCode: string,
  email: string,
  officePhone: string,
  mobilePhone: string,
) {
  const request = await fetch(`${process.env.REACT_APP_ALLIED_ECOM_API}/User/SignUp`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      name,
      lastName,
      company,
      title,
      address,
      city,
      state,
      zipCode,
      email,
      officePhone,
      mobilePhone,
      organizationId: 1,
    }),
    cache: 'no-store',
  });

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  return {
    success: true,
  };
}

export async function changePassword(newPassword: string, oldPassword: string) {
  const store = await getStore();
  const userData = store?.getState();
  const { accessToken, email, id, organizationId } = userData;

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const md5OldPassword = CryptoJS.MD5(oldPassword).toString();
  const md5NewPassword = CryptoJS.MD5(newPassword).toString();

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/User/ChangeUserPassword`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        organizationId: organizationId,
        userId: id,
        email: email,
        newPassword: md5NewPassword,
        oldPassword: md5OldPassword,
        resetPassword: true
      }),
      cache: 'no-store',
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const data: APIResponseChangePassword = await request.json();

  store.dispatch(updateUser({resetPassword: false }))

  return {
    success: true,
    data,
  };
}


