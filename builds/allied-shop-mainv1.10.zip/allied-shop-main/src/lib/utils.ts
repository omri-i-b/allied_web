import { put } from '@vercel/blob';
import { PARTS_IMAGE_BASE } from '..//constants';
import {
  APIResponseConfiguration,
  APIResponseGetCities,
  APIResponseGetCountries,
  APIResponseGetStates,
  APIResponseImages,
} from '../types/api';
import { getStore } from '../utils/getStore';

export async function fetchConfiguration() {
  // Cache the categories for the session
  const cache = sessionStorage.getItem('CONFIGURATION')
  if (cache) {
      return JSON.parse(cache);
  }

  const store = await getStore();
  const { accessToken, organizationId } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Configuration/GetConfigurationData?organizationId=${organizationId}`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const response: APIResponseConfiguration = await request.json();

  const res = {
    success: true,
    configuration: response.configurationData,
  };

  sessionStorage.setItem('CONFIGURATION', JSON.stringify(res));

  return res;
}

export async function fetchCountries() {
  // Cache the categories for the session
  const cache = sessionStorage.getItem('COUNTRIES')
  if (cache) {
      return JSON.parse(cache);
  }

  const store = await getStore();
  const { accessToken } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Address/GetCountries`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const { countries }: APIResponseGetCountries = await request.json();

  const res = {
    success: true,
    countries,
  };

  sessionStorage.setItem('COUNTRIES', JSON.stringify(res));

  return res;
}

export async function fetchStates() {
  // Cache the categories for the session
  const cache = sessionStorage.getItem('STATES')
  if (cache) {
      return JSON.parse(cache);
  }

  const store = await getStore();
  const { accessToken } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }


  const { countries } = await fetchCountries();
  const unitedStates = countries.find((country:{ id: number; code: string; description: string;}) => 'US' === country.code );

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Address/GetStates?countryId=${unitedStates.id}`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const { states }: APIResponseGetStates = await request.json();

  const res = {
    success: true,
    states,
  };

  sessionStorage.setItem('STATES', JSON.stringify(res));

  return res;
}

export async function fetchCities() {
  const store = await getStore();
  const { accessToken } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Address/GetCities`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const { cities }: APIResponseGetCities = await request.json();

  return {
    success: true,
    cities,
  };
}

export async function fetchImages() {
  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Part/GetPartImages`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
      cache: 'force-cache',
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const { images }: APIResponseImages = await request.json();

  return {
    success: true,
    images,
  };
}

export async function saveImage({
  bytes,
  fileName,
}: {
  bytes: string;
  fileName: string;
}) {
  var buffer = Buffer.from(bytes, 'base64');

  const { url } = await put(`${PARTS_IMAGE_BASE}/${fileName}`, buffer, {
    access: 'public',
    addRandomSuffix: false,
  });

  return url;
}

export async function validateAuth() {
  const store = await getStore();
  const { accessToken, organizationId } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Configuration/GetConfigurationData?organizationId=${organizationId}`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  return {
    success: true,
  };
}
