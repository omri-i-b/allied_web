import { PARTS_IMAGE_BASE } from '../constants';
import { fetchCategories } from './categories';
import slugify from 'slugify';
import {
  APIResponseCheckout,
  APIResponseCountBasketItems,
  APIResponseGetActiveBasketToShow,
  APIResponseGetBasketItemTax,
  APIResponseIsOverThresholdByLineAndTotal,
  APIResponseValidateBasket,
  APIResponseValidateQuantities,
} from '../types/api';
import { Cart, CartItem } from '../types/cart';
import { getStore } from '../utils/getStore';

export async function fetchCart() {
  const store = await getStore();
  const { accessToken, id, customerId } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const cartPromise = await fetch(
    
    
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/GetActiveBasketToShow?userId=${id}&customerId=${customerId}`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      cache: 'no-store',
    },
  );

  // Get the categories
  const categoriesPromise = await fetchCategories();

  const [cartResponse, categoriesResponse] = await Promise.all([
    cartPromise,
    categoriesPromise,
  ]);

  if (!cartResponse.ok) {
    return {
      success: false,
      error: cartResponse.status,
    };
  }

  const { basket }: APIResponseGetActiveBasketToShow =
    await cartResponse.json();
  const { categories } = categoriesResponse;

  if (!basket) {
    return {
      success: true,
      cart: null,
    };
  }

  return {
    success: true,
    cart: {
      id: basket.id,
      count: basket.items.length,
      items: basket.items.map((item) => {
        const category = categories?.find((c) => c.id === item.partCategoryId);

        const subcategory = category?.subcategories?.find(
          (s) => s.id === item.partShapeId,
        );

        return {
          cartId: item.id,
          productId: item.partId,
          name: item.partDescription,
          price: item.price * item.multiplier,
          quantity: item.qty,
          weight: item.weight,
          categoryId: item.partCategoryId,
          subcategoryId: item.partShapeId,
          //image: `${process.env.REACT_APP_ALLIED_ECOM_API}/${PARTS_IMAGE_BASE}/${item.fileName}`,
          image: `${process.env.REACT_APP_ALLIED_ECOM_API}/${PARTS_IMAGE_BASE}organizationId=${item.manageOrganizationId}&categoryId=${item.partCategoryId}&shapeId=${item.partShapeId}`,
          manufacturerId: item.manufacturerTypeId,
          manufacturerCode: item.manufacturerTypeCode,
          manufacturerName: item.manufacturerTypeDescription,
          warehouseId: item.ecommerceWarehouseId,
          warehouseCode: item.ecommerceWarehouseCode,
          warehouseName: item.ecommerceWarehouseDescription,
          warehousePrice: item.price,
          warehouseMultiplier: item.multiplier,
          shipTermId: item.shipTermId,
          slug: `/products/${category?.slug}/${subcategory?.slug}/${item.partId}/${slugify(
            item.partDescription,
            {
              lower: true,
              strict: true,
            },
          )}`,
        } as CartItem;
      }),
    } as Cart,
  };
}

export async function fetchCartItemCount() {
  const store = await getStore();
  const { accessToken, id, customerId } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/CountBasketItems?userId=${id}&customerId=${customerId}`,
    {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      cache: 'no-store',
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const { qty }: APIResponseCountBasketItems = await request.json();

  return {
    success: true,
    count: qty,
  };
}

export async function fetchAddCartItem(
  partId: number,
  manufacturerTypeId: number,
  ecommerceWarehouseId: number,
  price: number,
  multiplier: number,
  qty: number,
  shipTermId: number,
) {
  const store = await getStore();
  const { accessToken, id, customerId } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/AddBasketItem`,
    {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        qty,
        partId,
        userId: id,
        customerId: customerId,
        manufacturerTypeId,
        ecommerceWarehouseId,
        price,
        multiplier,
        // partDescription: "1 150# RF WN XH xxA105",
        // manufacturerTypeDescription: "Generic",
        // isCustomerPOLineNumberRequiredOnEcommerce: true,
        // customerPOLineNumber: 0,
        shipTermId,
      }),
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  return {
    success: true,
  };
}

export async function fetchUpdateCartItem(
  basketItemId: number,
  basketId: number,
  qty: number,
  price: number,
  multiplier: number,
  manufacturerTypeId: number,
  ecommerceWarehouseId: number,
  partId: number,
  shipTermId: number,
) {
  const store = await getStore();
  const { accessToken } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/UpdateBasketItem`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        basketItemId,
        basketId,
        qty,
        price,
        multiplier,
        manufacturerTypeId,
        ecommerceWarehouseId,
        // "partDescription": "string",
        // "manufacturerTypeDescription": "string",
        partId,
        // "isCustomerPOLineNumberRequiredOnEcommerce": true,
        // "customerPOLineNumber": 0,
        shipTermId,
      }),
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  return {
    success: true,
  };
}

export async function fetchDeleteCartItem(
  basketItemId: number,
  basketId: number,
) {
  const store = await getStore();
  const { accessToken } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/RemoveBasketItem`,
    {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        basketItemId,
        basketId,
      }),
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  return {
    success: true,
  };
}

export async function fetchDeleteAllCartItems(
  basketId: number,
) {
  const store = await getStore();
  const { accessToken } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/RemoveAllBasketItems`,
    {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        basketId,
      }),
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  return {
    success: true,
  };
}

export async function fetchCartTaxes() {
  const store = await getStore();
  const { accessToken, customerId, organizationId } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/GetBasketItemTax`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        customerId: customerId,
        organizationId: organizationId,
      }),
      cache: 'no-store',
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const { taxes }: APIResponseGetBasketItemTax = await request.json();

  if (!taxes) {
    return {
      success: false,
    };
  }

  return {
    success: true,
    taxes: taxes.map(
      ({ basketItemId, taxableAmount, taxAmount, taxCodeId }) => {
        return {
          cartId: basketItemId,
          taxableAmount,
          taxAmount,
          taxCodeId,
        };
      },
    ),
  };
}

export async function fetchValidateQuantity(partId: number, qty: number = 1) {
  const store = await getStore();
  const { accessToken } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/ValidateQuantities`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        partId,
        qty,
      }),
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const { isValid, errors }: APIResponseValidateQuantities =
    await request.json();

  return {
    success: true,
    errors,
    isValid,
  };
}

export async function fetchValidateThreshold(
  basketId: number,
  partId: number,
  qty: number = 1,
  manufacturerTypeId: number,
  ecommerceWarehouseId: number,
  shipTermId: number,
) {
  const store = await getStore();
  const { accessToken, customerId, organizationId } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/IsOverTresholdByLineAndTotal`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        organizationId: organizationId,
        customerId: customerId,
        qty,
        manufacturerTypeId,
        partId,
        ecommerceWarehouseId,
        basketId,
        isAddItem: true,
        shipTermId,
      }),
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const isOverThreshold: APIResponseIsOverThresholdByLineAndTotal =
    await request.json();

  return {
    success: true,
    isOverThreshold,
  };
}

export async function fetchValidateCart(basketId: number) {
  const store = await getStore();  
  const { accessToken } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/ValidateBasket`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: `${basketId}`,
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const { errors, isValid }: APIResponseValidateBasket = await request.json();

  return {
    success: true,
    errors,
    isValid,
  };
}

export async function fetchCheckout(checkoutValues: any) {
  const store = await getStore();
  const { accessToken } = store?.getState();

  if (!accessToken) {
    return {
      success: false,
      error: 401,
    };
  }

  const request = await fetch(
    `${process.env.REACT_APP_ALLIED_ECOM_API}/Basket/Checkout`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(checkoutValues),
    },
  );

  if (!request.ok) {
    return {
      success: false,
      error: request.status,
    };
  }

  const { webOrderId }: APIResponseCheckout = await request.json();

  return {
    success: true,
    orderId: webOrderId,
  };
}
