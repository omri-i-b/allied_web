import * as Utils from './utils';
import * as Authentication from './authentication';
import * as Categories from './categories';
import * as Products from './products';
import * as Cart from './cart';
import * as Customer from './customer';

export const Allied = {
  Utils,
  Authentication,
  Categories,
  Products,
  Cart,
  Customer,
};

export default Allied;
