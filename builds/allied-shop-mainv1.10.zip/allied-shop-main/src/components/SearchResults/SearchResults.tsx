
import { useSearch } from '../../contexts/SearchProvider';
import { Product } from '../../types/products';
import CardSearchResult from '../Card/CardSearchResult';

export default function SearchResults() {
  const { query, count, results } = useSearch();

  return (
    <>
      <div>
        <h1 className="page__search_title">Search results for “{query}”</h1>
        <p className="page__search_product-total">
          {new Intl.NumberFormat().format(count)} results
        </p>
      </div>
      <section className="search-results">
        {results && (
          <ul className="search-results_list">
            {results.map((product: Product) => {
              return (
                <li
                  key={`product-${product.id}`}
                  className="search-results_item"
                >
                  <CardSearchResult {...product} />
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </>
  );
}
