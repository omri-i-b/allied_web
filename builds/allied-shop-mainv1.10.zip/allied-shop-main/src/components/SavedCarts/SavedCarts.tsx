
import { useCallback, useState } from 'react';
import DataGrid, {
  Column,
  Item,
  Pager,
  Paging,
  SearchPanel,
  Toolbar,
} from 'devextreme-react/data-grid';
import { SavedCart } from '../../types/customer';
import { useNavigate } from 'react-router-dom';
import './SavedCarts.scss';

interface SavedCartsProps {
  serverSavedCarts: SavedCart[];
}

export default function SavedCarts({ serverSavedCarts }: SavedCartsProps) {
  const navigate = useNavigate();

  const [savedCarts] = useState<SavedCart[] | undefined>(serverSavedCarts);

  const handleRowClick = useCallback(
    ({ data }: { data: { id: number } }) => {
      navigate(`/account/saved-carts/${data.id}`);
    },
    [navigate],
  );

  return (
    <div className="saved-carts">
      <DataGrid
        showBorders={true}
        dataSource={savedCarts}
        onRowClick={handleRowClick}
        showColumnLines={false}
      >
        <SearchPanel
          width={400}
          visible={true}
          highlightSearchText={false}
          searchVisibleColumnsOnly={false}
        />
        <Column dataField="notes" caption="Note" dataType="string" />
        <Column
          dataField="savedDate"
          caption="Saved Date"
          dataType="date"
          format="shortDate"
          alignment="right"
        />
        <Toolbar>
          <Item location="before" name="searchPanel" />
        </Toolbar>
        <Paging defaultPageSize={12} />
        <Pager
          visible={true}
          allowedPageSizes={[12, 24, 50, 100]}
          displayMode="compact"
          showPageSizeSelector={true}
          showInfo={true}
        />
      </DataGrid>
    </div>
  );
}
