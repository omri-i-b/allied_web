import { Link } from "react-router-dom";
import GridCategory from "../Grid/GridCategory";
import './NotFound.scss';

export default function NotFound() {
  return (
    <main className="page page__not-found">
      <div className="container">
        <article>
          <section className="page__not-found_section">
            <h2 className="page__not-found_title">
              Something went wrong
            </h2>
            <p className="page__not-found_description">
              Sorry, the page you are looking for doesn’t exist or has been moved. Please try again or contact Allied.
            </p>

            <p className="page__not-found_cta"><Link to="/" className="btn btn-primary"><span className="dx-button-content">Back to homepage</span></Link></p>

            <GridCategory />
          </section>
        </article>
      </div>
    </main>
  );
}
