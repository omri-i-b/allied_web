
import './Header.scss';
import {
  memo,
  useState,
  useEffect,
  useCallback,
  useRef,
  useMemo,
  Suspense,
} from 'react';
import Search from '../../components/Search/Search';
import { Category } from '../../types/categories';
import { ReactComponent as Logo} from '../../assets/icons/allied-group.svg';
import {ReactComponent as IconCart} from '../../assets/icons/cart.svg';
import {ReactComponent as IconChevronRight} from '../../assets/icons/chevron-right.svg';
import { getAllCategories } from '../../actions';
import { useCart } from '../../contexts/CartProvider';
import { useModal } from '../../contexts/ModalProvider';
import ModalDeliveryAddress from '../Modal/ModalDeliveryAddress';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { RootState } from '../../redux/store';
import { logout } from '../../lib/authentication';
import { AUTH_STATUS_AUTHENTICATED } from '../../constants';

function ProductMenu({ onClose }: { onClose: () => void }) {
  const [categories, setCategories] = useState<Category[]>([]);

  // Fetch the categories
  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getAllCategories();

        if (data) {
          setCategories(data);
        }
      } catch (error) {
        throw new Error('Unable to fetch categories');
      }
      
    };
    fetchData();
  }, []);



  
  return (
    <div className="child-menu product-menu">
      <div className="container">
        {categories.map((category) => {
          const { subcategories } = category;
          return (
            <dl key={`submenu-${category.slug}`} className="submenu">
              <dt>
                <Link
                  to={`/products/${category.slug}`}
                  onClick={() => onClose()}
                >
                  {category.title}
                </Link>
              </dt>
              <dd>
                {subcategories && (
                  <ul>
                    {subcategories.map((subcategory) => {
                      return (
                        <li
                          key={`submenu-${category.slug}-${subcategory.slug}`}
                        >
                          <Link
                            to={`/products/${category.slug}/${subcategory.slug}`}
                            onClick={() => onClose()}
                          >
                            {subcategory.title}
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </dd>
            </dl>
          );
        })}
      </div>
    </div>
  );
}

function AccountMenu({ onClose }: { onClose: () => void }) {
  const navigate = useNavigate();
  const handleSignout = async () => { 
    const res = await logout()
    if(res.success) {
      navigate('/login')
    }
  }

  return (
    <div className="child-menu account-menu">
      <ul>
        <li>
          <Link to="/account" onClick={onClose}>
            My Account
          </Link>
        </li>
        <li>
          <Link to="/account/order-history" onClick={onClose}>
            Order History
          </Link>
        </li>
        <li>
          <Link to="/account/saved-carts" onClick={onClose}>
            Saved Carts
          </Link>
        </li>
        <li>
          <Link to="/account/addresses" onClick={onClose}>
            Addresses
          </Link>
        </li>
      </ul>
      <button
        type="button"
        className="btn btn-primary-outline"
        onClick={handleSignout}
      >
        <span className="dx-button-content">Log out</span>
      </button>
    </div>
  );
}

function LocationMenu({ onClose }: { onClose: () => void }) {
  const { openModal } = useModal();
  const { cartAddress } = useCart();    

  // Open the location drawer.
  const handleShowLocationDrawer = useCallback(() => {
    onClose();
    openModal(
      <ModalDeliveryAddress />,
      'Select Delivery Address',
      ['modal__delivery-address'],
      true,
    );
  }, [openModal, onClose]);

  return (
    <div className="child-menu location-menu">
      <Suspense>
        {cartAddress && (
          <address>
            <strong>Ship to</strong>
            <br />
            {cartAddress.street1}
            <br />
            {cartAddress.street2 && (
              <>
                {cartAddress.street2}
                <br />
              </>
            )}
            {cartAddress.city}, {cartAddress.state} {cartAddress.postalCode}
            <button type="button" onClick={handleShowLocationDrawer}>
              <IconChevronRight />
            </button>
          </address>
        )}
      </Suspense>
    </div>
  );
}

function AuthorizedHeader() {
  const cart = useCart();
  const userFirstName = useSelector((state: RootState) => state.firstName);


  const [isProductMenu, setIsProductMenu] = useState(false);
  const [isLocationMenu, setIsLocationMenu] = useState(false);
  const [isAccountMenu, setIsAccountMenu] = useState(false);

  const productMenu = useRef<HTMLLIElement>(null);
  const locationMenu = useRef<HTMLLIElement>(null);
  const accountMenu = useRef<HTMLLIElement>(null);

  /**
   * Toggle the child menu display
   * @param name
   */
  const handleToggleMenu = useCallback(
    (name: String | null) => {
      setIsProductMenu('product' === name ? !isProductMenu : false);
      setIsLocationMenu('location' === name ? !isLocationMenu : false);
      setIsAccountMenu('account' === name ? !isAccountMenu : false);
    },
    [isProductMenu, isLocationMenu, isAccountMenu],
  );

  /**
   * Handle Body Clicks to close menus
   */
  useEffect(() => {
    function handleBodyClick({ target }: MouseEvent) {
      if (isProductMenu || isLocationMenu || isAccountMenu) {
        if (
          (isProductMenu && !productMenu.current?.contains(target as Node)) ||
          (isLocationMenu && !locationMenu.current?.contains(target as Node)) ||
          (isAccountMenu && !accountMenu.current?.contains(target as Node))
        ) {
          handleToggleMenu(null);
        }
      }
    }

    document.addEventListener('click', handleBodyClick);

    document.body.classList.remove('is-frozen');
    if (isProductMenu) {
      document.body.classList.add('is-frozen');
    }

    return () => document.removeEventListener('click', handleBodyClick);
  }, [
    handleToggleMenu,
    isProductMenu,
    isLocationMenu,
    isAccountMenu,
    productMenu,
    locationMenu,
    accountMenu,
  ]);

  useEffect(() => {
    const body = document.body;

    if (isProductMenu) {
      body.style.overflowY = 'hidden';
    } else {
      body.style.overflowY = '';
    }

    return () => {
      body.style.overflowY = '';
    };
  }, [isProductMenu]);

  const postalCode = useMemo(() => {
    return cart.cartAddress?.postalCode.substring(0, 5) ?? null;
  }, [cart.cartAddress]);

  const cityState = useMemo(() => {
    const { city, state } = cart.cartAddress || {};
    const fullCityState = city && state ? `${city}, ${state}` : null;

    if (fullCityState && fullCityState.length > 15) {
      return `${fullCityState.substring(0, 12)}...`; // Truncate to 12 characters and add "..."
    }

    return fullCityState;
  }, [cart.cartAddress]);

  const firstName = useMemo(() => {
    const name = userFirstName || 'Guest'; // Access firstName from session or default to 'Guest'
    return name.length > 9 ? `${name.substring(0, 6)}...` : name;
  }, [userFirstName]);

  return (
    <>
      <div className="container">
        <div className="header__brand">
          <Link to="/">
            <Logo title="Allied Group" />
          </Link>
        </div>
        <nav className="header__product-navigation">
          <ul className="menu">
            <li className="menu-item has-children" ref={productMenu}>
              <button
                type="button"
                onClick={() => handleToggleMenu('product')}
                aria-expanded={isProductMenu}
              >
                <span>Products</span>
              </button>

              <ProductMenu onClose={() => handleToggleMenu(null)} />
            </li>
          </ul>
        </nav>
        <div className="header__search">
          <Search />
        </div>
        <nav className="header__user-navigation">
          <ul className="menu">
            <li className="menu-item has-children" ref={locationMenu}>
              <button
                type="button"
                onClick={() => handleToggleMenu('location')}
                aria-expanded={isLocationMenu}
              >
                <div>
                  <span>Ship to {postalCode}</span>
                </div>
                <div className="sub-header">{cityState}</div>
              </button>

              <LocationMenu onClose={() => handleToggleMenu(null)} />
            </li>
            <li className="menu-item has-children" ref={accountMenu}>
              <button
                type="button"
                onClick={() => handleToggleMenu('account')}
                aria-expanded={isAccountMenu}
              >
                <div>
                  <span>Account</span>
                </div>
                <div className="sub-header">{firstName}</div>
              </button>

              <AccountMenu onClose={() => handleToggleMenu(null)} />
            </li>
            <li className="menu-item">
              <Link to="/cart" data-item-count={cart.count}>
                <i className="icon icon-cart">
                  <IconCart />
                </i>
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </>
  );
}

function CheckoutHeader() {
  const cart = useCart();

  const [isProductMenu, setIsProductMenu] = useState(false);
  const [isLocationMenu, setIsLocationMenu] = useState(false);
  const [isAccountMenu, setIsAccountMenu] = useState(false);

  const productMenu = useRef<HTMLLIElement>(null);
  const locationMenu = useRef<HTMLLIElement>(null);
  const accountMenu = useRef<HTMLLIElement>(null);

  /**
   * Toggle the child menu display
   * @param name
   */
  const handleToggleMenu = useCallback(
    (name: String | null) => {
      setIsProductMenu('product' === name ? !isProductMenu : false);
      setIsLocationMenu('location' === name ? !isLocationMenu : false);
      setIsAccountMenu('account' === name ? !isAccountMenu : false);
    },
    [isProductMenu, isLocationMenu, isAccountMenu],
  );

  /**
   * Handle Body Clicks to close menus
   */
  useEffect(() => {
    function handleBodyClick({ target }: MouseEvent) {
      if (isProductMenu || isLocationMenu || isAccountMenu) {
        if (
          (isProductMenu && !productMenu.current?.contains(target as Node)) ||
          (isLocationMenu && !locationMenu.current?.contains(target as Node)) ||
          (isAccountMenu && !accountMenu.current?.contains(target as Node))
        ) {
          handleToggleMenu(null);
        }
      }
    }

    document.addEventListener('click', handleBodyClick);

    document.body.classList.remove('is-frozen');
    if (isProductMenu) {
      document.body.classList.add('is-frozen');
    }

    return () => document.removeEventListener('click', handleBodyClick);
  }, [
    handleToggleMenu,
    isProductMenu,
    isLocationMenu,
    isAccountMenu,
    productMenu,
    locationMenu,
    accountMenu,
  ]);

  return (
    <>
      <div className="container">
        <div className="w-1/2 flex justify-between ml-auto items-center">
          <div className="header__brand">
            <Link to="/">
              <Logo title="Allied Group" />
            </Link>
          </div>
          <nav className="header__user-navigation">
            <ul className="menu">
              <li className="menu-item items-center flex">
                <Link to="/cart" className="checkout-cart">
                  Edit Cart ({cart.count})
                  <i className="icon icon-cart">
                    <IconCart />
                  </i>
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </>
  );
}

function AnonymousHeader() {
  return (
    <>
      <div className="container">
        <div className="header__brand">
          <Link to="/">
            <Logo title="Allied Group" />
          </Link>
        </div>
      </div>
    </>
  );
}

export default memo(function Header() {
  const location = useLocation();
  const status = useSelector((state: RootState) => state.status);
  
  const isAuthenticated = AUTH_STATUS_AUTHENTICATED === status;
  const isCheckout = location.pathname === '/checkout';
  
  return (
    <header
      id="head"
      className={`header ${isCheckout ? 'header__checkout' : ''}`}
      data-authenticated={isAuthenticated}
    >
      {isAuthenticated && !isCheckout && <AuthorizedHeader />}
      {!isAuthenticated && !isCheckout && <AnonymousHeader />}
      {isCheckout && <CheckoutHeader />}
    </header>
  );
});
