import { ChangeEvent, useCallback, useEffect, useState } from 'react';
import { Warehouse } from '../../types/products';
import { Button } from 'devextreme-react/button';
import { useCart } from '../../contexts/CartProvider';
import { getWarehousesWithAvailability, updateItemInCart } from '../../actions';
import './CartItemsConsolidation.scss';

export default function CartItemsConsolidation() {
  const { id, items, refreshCart } = useCart();

  const [showConsolidation, setShowConsolidation] = useState<boolean>(false);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [selectedWarehouse, setSelectedWarehouse] = useState<
    Warehouse | undefined
  >();
  const [isReady, setIsReady] = useState(false);

  const handleSelectWarehouse = useCallback(
    (e: ChangeEvent<HTMLInputElement>) => {
      const target = e.target;
      const newWarehouse = warehouses.find(
        (w) => w.id === parseInt(target.value, 10),
      );

      if (newWarehouse) {
        setSelectedWarehouse(newWarehouse);
      }
    },
    [warehouses],
  );

  const handleDismiss = useCallback(() => {
    setShowConsolidation(false);
  }, []);

  const handleSave = useCallback(async () => {
    setShowConsolidation(false);

    if (selectedWarehouse) {
      var promises:any[] = [];

      items.forEach(async (item) => {
        if (item.warehouseId === selectedWarehouse.id) {
          return;
        }

        promises.push(updateItemInCart(
          item.cartId,
          id,
          item.productId,
          item.manufacturerId,
          selectedWarehouse.id,
          item.warehousePrice,
          item.warehouseMultiplier,
          item.quantity,
          item.shipTermId,
        ));
      });

      // Wait until all promises are kept
      await Promise.all(promises);

      // Refresh the cart
      await refreshCart();
    }
  }, [selectedWarehouse, items, id, refreshCart]);

  useEffect(() => {
    setIsReady(!!selectedWarehouse);
  }, [selectedWarehouse]);

  useEffect(() => {
    if (!id || !items || 2 > items.length) {
      setShowConsolidation(false);
      return;
    }

    (async () => {
      const data = await getWarehousesWithAvailability(id);
      if (data && data.length > 0) {
        setWarehouses(data);
        setShowConsolidation(true);
      }
    })();
  }, [id, items]);
// 
  return (
    <>
      {showConsolidation && (
        <div className="cart-items-consolidation">
          <div className="cart-items-consolidation_description">
            <p>
              Your order is set to ship from multiple warehouses, but all items
              are currently in stock at the same warehouse. Would you like to
              consolidate shipments for faster processing and delivery?
            </p>

            <p>Select your preferred warehouse:</p>
          </div>

          <ul className="cart-items-consolidation_selector">
            {warehouses.map(({ id, name }) => (
              <li key={id} className="cart-items-consolidation_selector_option">
                <input
                  type="radio"
                  id={`warehouse[${id}]`}
                  name="consolidated_warehouse"
                  value={id}
                  onChange={handleSelectWarehouse}
                  defaultChecked={id === selectedWarehouse?.id}
                />
                <label htmlFor={`warehouse[${id}]`}>{name}</label>
              </li>
            ))}
          </ul>

          <div className="cart-items-consolidation_actions">
            <Button className="btn btn-outline-primary" onClick={handleDismiss}>
              Dismiss
            </Button>
            <Button
              className="btn btn-primary"
              onClick={handleSave}
              disabled={!isReady}
            >
              Consolidate
            </Button>
          </div>
        </div>
      )}
    </>
  );
}