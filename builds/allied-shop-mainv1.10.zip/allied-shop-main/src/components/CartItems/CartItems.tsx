
import {
  useMemo,
  useState,
  useEffect,
  useCallback,
  Dispatch,
  SetStateAction,
} from 'react';
import { useCart } from '../../contexts/CartProvider';
import CardCartItem from '../../components/Card/CardCartItem';
import { CartItem } from '../../types/cart';
import {ReactComponent as IconTruck} from '../../assets/icons/truck.svg';
import {ReactComponent as IconWillCall} from '../../assets/icons/willcall.svg';
import {ReactComponent as IconInfo} from '../../assets/icons/info-fill.svg';
import CartItemsConsolidation from './CartItemsConsolidation';
import './CartItems.scss';
import { Link, useNavigate } from 'react-router-dom';

type ItemsGroupedByWarehouseType = false | Partial<Record<string, CartItem[]>>;

type LastDeletedItemType = {
  item: CartItem;
  index: number;
};

function isCartIdInWarehouse(
  items: any,
  warehouseName: string,
  cartId: number,
) {
  const warehouseItems = items[warehouseName];
  if (!warehouseItems) {
    return false;
  }
  return warehouseItems.some((item: CartItem) => item.cartId === cartId);
}

function removeDuplicatesByCartId(items: any) {
  const seenCartIds = new Set();
  return items.filter((item: CartItem) => {
    if (seenCartIds.has(item.cartId)) {
      return false;
    }
    seenCartIds.add(item.cartId);
    return true;
  });
}

export default function CartItems({
  setHasRemovedItems,
}: {
  setHasRemovedItems: Dispatch<SetStateAction<boolean>>;
}) {
  const { items, shippingTerm, willCallTerm } = useCart();
  const navigate = useNavigate();
  const [lastDeletedItem, setLastDeletedItem] =
    useState<LastDeletedItemType | null>(null);
  const [lastDeletedWillCallItem, setLastDeletedWillCallItem] =
    useState<LastDeletedItemType | null>(null);
  const [renderedShippingItems, setRenderedShippingItems] =
    useState<ItemsGroupedByWarehouseType>(false);
  const [renderedWillCallItems, setRenderedWillCallItems] =
    useState<ItemsGroupedByWarehouseType>(false);

  const shippingItems = useMemo(() => {
    if (!shippingTerm) {
      return false;
    }

    const filteredItems = items.filter(
      (item) => item.shipTermId === shippingTerm.id,
    );

    if (!filteredItems.length) {
      return false;
    }

    return Object.groupBy(
      filteredItems,
      ({ warehouseName }: { warehouseName: string }) => warehouseName,
    );
  }, [items, shippingTerm]);

  const willCallItems = useMemo(() => {
    if (!willCallTerm) {
      return false;
    }

    var filteredItems = items.filter(
      (item) => item.shipTermId === willCallTerm.id,
    );

    if (!filteredItems.length) {
      return false;
    }

    return Object.groupBy(
      filteredItems,
      ({ warehouseName }: { warehouseName: string }) => warehouseName,
    );
  }, [items, willCallTerm]);

  const handleLastDeletedItem = useCallback(
    (
      lastDeletedItem: any,
      items: any,
      renderedItems: any,
      setRenderedItems: (_items: any) => void,
    ) => {
      if (lastDeletedItem) {
        const { item, index } = lastDeletedItem;
        const itemWithUndo = { ...item, undo: true };
        const existsInWarehouse = isCartIdInWarehouse(
          items,
          item.warehouseName,
          item.cartId,
        );
        if (existsInWarehouse) {
          return;
        }

        const updated = JSON.parse(JSON.stringify(renderedItems));
        // Inserting removed items in the same place they were originally
        updated[item.warehouseName] = [
          ...updated[item.warehouseName].slice(0, index),
          itemWithUndo,
          ...updated[item.warehouseName].slice(index),
        ];
        updated[item.warehouseName] = removeDuplicatesByCartId(
          updated[item.warehouseName],
        );
        setRenderedItems(updated);
      } else {
        setRenderedItems(items);
      }
    },
    [],
  );

  useEffect(() => {
    handleLastDeletedItem(
      lastDeletedItem,
      shippingItems,
      renderedShippingItems,
      setRenderedShippingItems,
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shippingItems, lastDeletedItem, handleLastDeletedItem]);

  useEffect(() => {
    handleLastDeletedItem(
      lastDeletedWillCallItem,
      willCallItems,
      renderedWillCallItems,
      setRenderedWillCallItems,
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [willCallItems, lastDeletedWillCallItem, handleLastDeletedItem]);

  useEffect(() => {
    setHasRemovedItems(
      (renderedShippingItems && typeof renderedShippingItems === 'object') ||
        (renderedWillCallItems && typeof renderedWillCallItems === 'object'),
    );
  }, [renderedShippingItems, renderedWillCallItems, setHasRemovedItems]);

  const deleteItemHandler = (item: CartItem, index: number) => {
    if (item.shipTermId === 3) {
      setLastDeletedItem({
        item,
        index,
      });
    } else if (item.shipTermId === 2) {
      setLastDeletedWillCallItem({
        item,
        index,
      });
    }
  };

  const undoItemHandler = useCallback(
    (item: CartItem) => {
      navigate(item.slug);
    },
    [navigate],
  );

  const showMultipleNotice = renderedShippingItems && renderedWillCallItems;

  return (
    <>
      {showMultipleNotice && (
        <div className="notice notice-info">
          <i className="icon icon-info">
            <IconInfo />
          </i>
          <p>Your order is set to use multiple delivery methods.</p>
        </div>
      )}

      {renderedShippingItems && (
        <div className="cart__shipping-groups">
          { Object.keys(renderedShippingItems).length > 1 && 
            <CartItemsConsolidation />
          }
          <div className="flex flex-row justify-between items-center">
            <div className="cart__shipping-groups_header">
              <h2 className="cart__shipping-groups_title">
                <i className="icon icon-truck">
                  <IconTruck />
                </i>{' '}
                Shipping
              </h2>
              <p className="cart__shipping-groups_count">
                out of {Object.keys(renderedShippingItems).length} warehouses
              </p>
            </div>
            <div>
              <Link to="/" className="btn btn-primary-outline">
                <span className="dx-button-content">Continue Shopping</span>
              </Link>
            </div>
          </div>

          {Object.keys(renderedShippingItems).map((warehouse) => {
            const shippingItemsByWarehouse = renderedShippingItems[warehouse];

            if (!shippingItemsByWarehouse) {
              return [];
            }

            return (
              <div
                key={`shipping-group-${warehouse}`}
                className="cart__shipping-group"
              >
                <p className="cart__shipping-group_warehouse">
                  at <em>{warehouse}</em>
                </p>

                <ul className="cart__item-list">
                  {shippingItemsByWarehouse.map(
                    (item: CartItem, index: number) => {
                      return (
                        <li key={`item-${item.cartId}`}>
                          <CardCartItem
                            item={item}
                            deleteItemHandler={deleteItemHandler}
                            undoItemHandler={undoItemHandler}
                            index={index}
                          />
                        </li>
                      );
                    },
                  )}
                </ul>
              </div>
            );
          })}
        </div>
      )}

      {renderedWillCallItems && (
        <div className="cart__shipping-groups">
          <div className="flex flex-row justify-between items-center">
            <div className="cart__shipping-groups_header">
              <h2 className="cart__shipping-groups_title">
                <i className="icon icon-truck">
                  <IconWillCall />
                </i>{' '}
                Will Call
              </h2>
              <p className="cart__shipping-groups_count">
                at {Object.keys(renderedWillCallItems).length} warehouses
              </p>
            </div>
            <div>
              { !renderedShippingItems && <Link to="/" className="btn btn-primary-outline">
                <span className="dx-button-content">Continue Shopping</span>
              </Link> }
            </div>
          </div>

          {Object.keys(renderedWillCallItems).map((warehouse) => {
            const willCallItemsByWarehouse = renderedWillCallItems[warehouse];

            if (!willCallItemsByWarehouse) {
              return [];
            }

            return (
              <div
                key={`willcall-group-${warehouse}`}
                className="cart__shipping-group"
              >
                <p className="cart__shipping-group_warehouse">
                  at <em>{warehouse}</em>
                </p>

                <ul className="cart__item-list">
                  {willCallItemsByWarehouse.map(
                    (item: CartItem, index: number) => {
                      return (
                        <li key={`item-${item.cartId}`}>
                          <CardCartItem
                            item={item}
                            deleteItemHandler={deleteItemHandler}
                            undoItemHandler={undoItemHandler}
                            index={index}
                          />
                        </li>
                      );
                    },
                  )}
                </ul>
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}
