
import { useCallback, useEffect, useState } from 'react';
import { Order } from '../../types/customer';
import DataGrid, {
  Column,
  Item,
  Pager,
  Paging,
  SearchPanel,
  Toolbar,
  DataGridTypes,
} from 'devextreme-react/data-grid';
import { SelectBox, SelectBoxTypes } from 'devextreme-react/select-box';
import { DateBox, DateBoxTypes } from 'devextreme-react/date-box';
import './Orders.scss';
import { getAllOrders } from '../../actions';
import { useNavigate } from 'react-router-dom';

const currencyFormat = {
  type: 'currency',
  precision: 2,
};

interface OrdersProps {
  serverOrders: Order[];
  serverOrderStatusList: {
    id: number;
    code: string;
    description: string;
  }[];
}

export default function Orders({
  serverOrders,
  serverOrderStatusList,
}: OrdersProps) {
  const navigate = useNavigate();

  const [orderList, setOrderList] = useState<Order[] | undefined>(serverOrders);
  const [filterDate, setFilterDate] = useState();
  const [filterStatus, setFilterStatus] = useState();

  /**
   * Run search with filters
   */
  useEffect(() => {
    (async () => {
      const data = await getAllOrders(filterStatus, filterDate);

      setOrderList(data);
    })();
  }, [filterDate, filterStatus]);

  /**
   * Click on a row
   */
  const handleRowClick = useCallback(
    ({ data }: { data: { id: number } }) => {
      navigate(`/account/order-history/${data.id}`);
    },
    [navigate],
  );

  const handleFilterDateChange = useCallback(
    (e: DateBoxTypes.ValueChangedEvent) => {
      setFilterDate(e.value.toISOString());
    },
    [],
  );

  const handleFilterStatusChange = useCallback(
    (e: SelectBoxTypes.ValueChangedEvent) => {
      setFilterStatus(e.value);
    },
    [],
  );

  /**
   * Customize the status cell
   */
  const StatusCell = ({ value }: DataGridTypes.ColumnCellTemplateData) => {
    return (
      <span className="tag status" data-status={value}>
        {value}
      </span>
    );
  };

  return (
    <div className="orders">
      <DataGrid
        showBorders={true}
        dataSource={orderList}
        onRowClick={handleRowClick}
        showColumnLines={false}
      >
        <SearchPanel
          width={400}
          visible={true}
          highlightSearchText={false}
          searchVisibleColumnsOnly={false}
        />
        <Column
          dataField="status"
          caption="Status"
          dataType="string"
          cellRender={StatusCell}
          allowSearch={false}
        />
        <Column
          dataField="purchaseOrderNumber"
          caption="Customer PO Number"
          dataType="string"
          alignment="right"
        />
        <Column
          dataField="number"
          caption="Order Number"
          dataType="string"
          alignment="right"
        />
        <Column
          dataField="date"
          caption="Order Date"
          dataType="date"
          format="shortDate"
          alignment="right"
          selectedFilterOperation="contains"
        />
        <Column dataField="total" dataType="number" format={currencyFormat} />
        <Toolbar>
          <Item location="before" name="searchPanel" />
          <Item location="before">
            <DateBox
              width={200}
              placeholder="Order Date"
              onValueChanged={handleFilterDateChange}
            />
          </Item>
          <Item location="before">
            <SelectBox
              width={168}
              placeholder="Status"
              name="filter-status"
              valueExpr="id"
              displayExpr="description"
              dataSource={serverOrderStatusList}
              onValueChanged={handleFilterStatusChange}
            />
          </Item>
        </Toolbar>
        <Paging defaultPageSize={12} />
        <Pager
          visible={true}
          allowedPageSizes={[12, 24, 50, 100]}
          displayMode="compact"
          showPageSizeSelector={true}
          showInfo={true}
        />
      </DataGrid>
    </div>
  );
}
