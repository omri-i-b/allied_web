import './Footer.scss';
import {ReactComponent as Logo} from '../../assets/icons/allied-group.svg';
import {ReactComponent as IconLinkedIn} from '../../assets/icons/linkedin.svg';
import {ReactComponent as IconFacebook} from '../../assets/icons/facebook.svg';
import {ReactComponent as IconExternal} from '../../assets/icons/external.svg';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer id="foot" className="footer">
      <div className="container">
        <div className="footer__column">
          <div className="footer__brand">
            <Logo title="Allied Group" />
          </div>
        </div>

        <div className="footer__column">
          <h1 className="footer__title">LINKS</h1>
          <nav className="footer__navigation">
            <ul className="menu">
              <li className="menu-item">
                <Link to="/">Home</Link>
              </li>
              <li className="menu-item">
                <Link to="https://portal.alliedfit.com/Account/SignIn">
                  Customer Portal
                  <i className="icon icon-external">
                    <IconExternal />
                  </i>
                </Link>
              </li>
            </ul>
          </nav>
        </div>

        <div className="footer__column">
          <h1 className="footer__title">CONTACT</h1>
          <p>
            Call us at <a href="tel:+18009695565">800.969.5565</a>
          </p>
        </div>

        <div className="footer__column">
          <h1 className="footer__title">FOLLOW US</h1>
          <dl className="footer__social-links">
            <dd>
              <ul>
                <li>
                  <Link
                    to="https://www.linkedin.com/company/alliedusa/"
                    target="_blank"
                    rel="nofollow"
                  >
                    <IconLinkedIn title="LinkedIn" width="22" height="22" />
                  </Link>
                </li>
                <li>
                  <Link
                    to="https://www.facebook.com/people/Allied-Group/61555783610372/"
                    target="_blank"
                    rel="nofollow"
                  >
                    <IconFacebook width="22" height="22" />
                  </Link>
                </li>
              </ul>
            </dd>
          </dl>
        </div>
      </div>
    </footer>
  );
}
