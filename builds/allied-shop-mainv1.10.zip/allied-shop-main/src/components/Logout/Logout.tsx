

// import { signOut } from 'next-auth/react';
import { useEffect } from 'react';

export default function Logout() {
  useEffect(() => {
    const callSignOut = async () => {
      // await signOut({
      //   redirect: true,
      //   callbackUrl: '/login',
      // });
    };
    callSignOut();
  }, []);

  return (
    <>
      <p>Logging out...</p>
    </>
  );
}
