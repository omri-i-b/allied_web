

import { memo, ReactNode, useCallback, useEffect, useState } from 'react';
import { useToast } from '../../contexts/ToastProvider';
import {ReactComponent as IconClose} from '../../assets/icons/close.svg';
import {ReactComponent as IconAlert} from '../../assets/icons/alert.svg';

import './Toast.scss';

export type ToastType = {
  id: string;
  message: ReactNode;
  type: 'info' | 'error' | 'success';
};

export const Toast = memo(function Toast({ id, message, type }: ToastType) {
  const { removeToast } = useToast();
  const [animateClass, setAnimateClass] = useState<string>('');

  useEffect(() => {
    // Animate in
    setAnimateClass('animate-in');

    const timer = setTimeout(() => {
      // Animate out
      setAnimateClass('animate-out');

      removeToast(id);
    }, 8000);

    return () => {
      clearTimeout(timer);
    };
  }, [id, removeToast]);

  const handleClose = useCallback(() => {
    setAnimateClass('animate-out');

    removeToast(id);
  }, [id, removeToast]);

  return (
    <div className={`toast ${type} ${animateClass}`}>
      <i className="icon icon-type">
        <IconAlert />
      </i>
      <span>{message}</span>
      <button type="button" onClick={handleClose} title="cancel">
        <i className="icon icon-close">
          <IconClose />
        </i>
      </button>
    </div>
  );
});

export default Toast;
