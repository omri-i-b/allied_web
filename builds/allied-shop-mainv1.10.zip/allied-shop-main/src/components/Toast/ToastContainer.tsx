

import { useToast } from '../../contexts/ToastProvider';
import { Toast } from '../../components/Toast/Toast';

import './ToastContainer.scss';

export default function ToastContainer() {
  const { messages } = useToast();

  return (
    <div className="toast-container">
      {messages && (
        <>
          {messages.map((message) => {
            return <Toast key={`toast-${message.id}`} {...message} />;
          })}
        </>
      )}
    </div>
  );
}
