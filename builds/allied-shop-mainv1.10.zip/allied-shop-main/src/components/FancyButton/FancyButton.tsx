
import { memo } from 'react';
import { Button } from 'devextreme-react/button';
import {ReactComponent as IconComplete} from '../../assets/icons/complete.svg';

import './FancyButton.scss';

export default memo(function FancyButton({
  text,
  status,
  className,
  disabled = false,
  useSubmitBehavior = false,
  onClick,
}: {
  text: string;
  status: 'pending' | 'complete' | '';
  className?: string;
  disabled: boolean;
  useSubmitBehavior?: boolean;
  onClick?: () => void;
}) {
  const isPending = !!('pending' === status);
  const isComplete = !!('complete' === status);

  return (
    <Button
      className={`btn ${className} ${status}`}
      onClick={onClick}
      disabled={disabled}
      useSubmitBehavior={useSubmitBehavior}
    >
      <span>
        {isComplete && (
          <i className="icon icon-complete">
            <IconComplete />
          </i>
        )}
        {isPending && <i className="spinner"></i>}
      </span>
      <span>{text}</span>
    </Button>
  );
});
