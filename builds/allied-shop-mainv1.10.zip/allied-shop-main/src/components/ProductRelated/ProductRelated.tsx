

import { memo, useEffect, useState } from 'react';
import { getRelatedProductsById } from '../../actions';
import { Product } from '../../types/products';
import ProductCarousel from '../../components/ProductCarousel/ProductCarousel';

export default memo(function ProductRelated({
  productId,
}: {
  productId: number;
}) {
  const [related, setRelated] = useState<Product[]>([]);

  useEffect(() => {
    if (!productId) {
      return;
    }

    const fetchData = async () => {
      const data = await getRelatedProductsById(productId);

      if (data) {
        setRelated(data);
      }
    };
    fetchData();
  }, [productId]);

  return (
    <>
      {related?.length > 0 && (
        <section className="product__related-products">
          <div className="container">
            <h2 className="product__related-products_title">
              Related Products
            </h2>

            <ProductCarousel products={related} />
          </div>
        </section>
      )}
    </>
  );
});
