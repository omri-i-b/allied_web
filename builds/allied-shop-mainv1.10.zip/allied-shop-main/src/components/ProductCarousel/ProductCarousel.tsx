
import './ProductCarousel.scss';
import 'swiper/css';
import { Product } from '../../types/products';
import { Swiper, SwiperSlide } from 'swiper/react';
import CardProduct from '../../components/Card/CardProduct';

interface ProductCarouselProps {
  products: Product[];
}

export default function ProductCarousel({ products }: ProductCarouselProps) {
  return (
    <Swiper
      className="product-carousel"
      slidesPerView={'auto'}
      spaceBetween={20}
      centeredSlides={false}
    >
      {products.length > 0 && 
      products.map((product: Product) => {
        return (
          <SwiperSlide
            key={`slide-product=${product.slug}`}
            className="product-carousel_slide"
          >
            <CardProduct {...product} />
          </SwiperSlide>
        );
      })}
    </Swiper>
  );
}
