

import { memo, useEffect, useState } from 'react';
import placeholderImage from '../../assets/images/placeholder.png';

export default memo(function Image(props: {
  src: string;
  alt: string;
  width: number;
  height: number;
  loading: 'eager' | 'lazy' | undefined;
}) {
  const [src, setSrc] = useState(props.src);

  useEffect(() => {
    setSrc(props.src);
  }, [props.src]);

  return (
    <img
      onError={() => {
        setSrc(placeholderImage);
      }}
      src={src}
      alt={props.alt}
      width={props.width}
      height={props.height}
      loading={props.loading}
    />
  );
});
