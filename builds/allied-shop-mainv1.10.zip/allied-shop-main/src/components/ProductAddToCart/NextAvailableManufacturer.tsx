
import { getAllManufacturers, getProductAvailability } from '../../actions';
import { useCart } from '../../contexts/CartProvider';
import { Manufacturer } from '../../types/products';
import { memo, useCallback, useEffect, useMemo, useState } from 'react';

interface NextAvailableManufacturerProps {
  id: number;
  quantity: number;
  manufacturer?: Manufacturer,
  onSelect: (_manufacturer: Manufacturer) => void;
}

export default memo(function NextAvailableManufacturer({
  id,
  quantity,
  manufacturer,
  onSelect,
}: NextAvailableManufacturerProps) {
  const { id:cartId } = useCart();
  const [manufacturers, setManufacturers] = useState<Manufacturer[]>([]);
  const [available, setAvailable] = useState<Manufacturer | undefined>();
  const [isLoaded, setIsLoaded] = useState(false);

  const preferredOrder = useMemo(
    () => {
      let order;

      switch(manufacturer?.code) { 
        case 'Generic':
          order = ['generic', 'approved', 'domestic', 'chinese'];
          break;
        case 'Approved':
          order = ['approved', 'domestic', 'generic', 'chinese'];
          break;
        case 'Domestic':
          order = ['domestic', 'approved', 'generic', 'chinese'];
          break;
        default:
          order = ['chinese', 'generic', 'approved', 'domestic'];
          break;
      }
      return order;
    }, [manufacturer]);

  const handleSelectAvailable = useCallback(() => {
    if (onSelect && available) {
      onSelect(available);
    }
  }, [available, onSelect]);

  /**
   * Check the manufacturers
   */
  useEffect(() => {
    if (!id || !quantity || !manufacturers.length || isLoaded) {
      return;
    }

    const abortController = new AbortController();

    (async () => {
      for (let i = 0; i < preferredOrder.length; i++) {
        const key = preferredOrder[i];
        const manufacturer = manufacturers.find(
          (m) => m.code.toLowerCase() === key.toLowerCase(),
        );

        if (!manufacturer) {
          continue;
        }

        const { primary, alternates } = await getProductAvailability(
          id,
          manufacturer.id,
          quantity,
          cartId,
        );

        if ((primary || alternates.length)) {
          setAvailable(manufacturer);
          break;
        }
      }

      setIsLoaded(true);
    })();

    return () => {
      abortController.abort();
    };
  }, [manufacturers, id, cartId, quantity, preferredOrder, isLoaded]);

  /**
   * Initially fetch all of the manufacturers
   */
  useEffect(() => {
    (async () => {
      const data = (await getAllManufacturers()) || [];

      if (data) {
        setManufacturers(data);
      }
    })();
  }, []);

  return (
    <>
      {isLoaded && (
        <>
          {available ? (
            <p className="product-add-to-cart_next-available">
              The item is available in{' '}
              <button
                className="btn btn-secondary-link"
                onClick={handleSelectAvailable}
              >
                {available?.name}
              </button>
            </p>
          ) : (
            <div className="notice notice-info">
              This item is currently unavailable from all manufacturer types.
            </div>
          )}
        </>
      )}
    </>
  );
});
