

import { memo, useCallback, useEffect, useState } from 'react';
import { Manufacturer } from '../../types/products';
import { getAllManufacturers } from '../../actions';
import { SelectBox, SelectBoxTypes } from 'devextreme-react/select-box';
import { MANUFACTURER_GENERIC } from '../../constants';

export default memo(function ManufacturerSelect({
  defaultValue,
  onChange,
}: {
  defaultValue?: Manufacturer;
  onChange: (_manufacturer: Manufacturer) => void;
}) {
  const [manufacturers, setManufacturers] = useState<Manufacturer[]>([]);
  const [selected, setSelected] = useState<Manufacturer | undefined>(
    defaultValue,
  );

  /**
   * Initially fetch all of the manufacturers
   */
  useEffect(() => {
    if (manufacturers.length) {
      return;
    }

    (async () => {
      const data = (await getAllManufacturers()) || [];

      if (data) {
        setManufacturers(data);
      }
    })();
  }, [manufacturers]);

  // Once the manufacturers are loaded or the default value is changed
  useEffect(() => {
    // Make 'Generic' the default if one isn't already passed
    const generic = manufacturers.find(
      (m: Manufacturer) => MANUFACTURER_GENERIC === m.code,
    );

    if (generic && !defaultValue) {
      setSelected(generic);
    } else {
      setSelected(defaultValue);
    }
  }, [manufacturers, defaultValue]);

  /**
   * Trigger onChange if selected is changed
   */
  useEffect(() => {
    if (selected && onChange) {
      onChange(selected);
    }
  }, [selected, onChange]);

  const handleManufacturerChange = useCallback(
    (e: SelectBoxTypes.ValueChangedEvent) => {
      const selected = manufacturers.find(
        (manufacturer) => manufacturer.code === e.value,
      );

      if (selected) {
        setSelected(selected);
      }
    },
    [manufacturers],
  );

  return (
    <div className="product-add-to-cart_manufacturer">
      <p>
        Manufacturer <span>{selected?.name}</span>
      </p>

      <SelectBox
        placeholder="Select manufacturer"
        dataSource={manufacturers}
        valueExpr="code"
        displayExpr="name"
        value={defaultValue?.code}
        onValueChanged={handleManufacturerChange}
      />
    </div>
  );
});
