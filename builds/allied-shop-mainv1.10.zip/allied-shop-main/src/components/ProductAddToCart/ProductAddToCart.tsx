import { memo, useCallback, useState, useMemo, useEffect, useRef } from 'react';
import {
  addItemToCart,
  getProductAvailability,
  updateItemInCart,
  validateQuantity,
  validateThreshold,
} from '../../actions';
import { Manufacturer, Product, AvailableWarehouse } from '../../types/products';
import { ShippingTerm } from '../../types/customer';
// import { useSession } from 'next-auth/react';
import { useCart } from '../../contexts/CartProvider';
import { useModal } from '../../contexts/ModalProvider';
import { useToast } from '../../contexts/ToastProvider';
import ModalAddedToCart from '../../components/Modal/ModalAddedToCart';
import { NumberBox } from 'devextreme-react/number-box';
import FancyButton from '../../components/FancyButton/FancyButton';
import ManufacturerSelect from '../../components/ProductAddToCart/ManufacturerSelect';
import DeliverySelect from '../../components/ProductAddToCart/DeliverySelect';
import DeliveryMessage from '../../components/ProductAddToCart/DeliveryMessage';
import ModalSelectWarehouse from '../../components/Modal/ModalSelectWarehouse';
import {
  ERROR_CART_NOT_ADDED,
  ERROR_CART_QUANTITY,
  ERROR_CART_THRESHOLD,
} from '../../constants';
import './ProductAddToCart.scss';
import { useSearchParams } from 'react-router-dom';
import { CartItem } from '../../types/cart';
import NextAvailableManufacturer from './NextAvailableManufacturer';
import { useDebouncedCallback } from 'use-debounce';
import { useSelector } from 'react-redux';
import { RootState } from '../../redux/store';

interface ProductAddToCart {
  product: Product;
  onError?: (_error: string) => void;
}

export default memo(function ProductAddToCart({
  product,
  onError,
}: ProductAddToCart) {
  const [searchParams] = useSearchParams();
  const { id, title, image } = product;
  const allowChangeWarehouse = useSelector((state: RootState) => state.allowChangeWarehouse);

  const cart = useCart();
  const {
    totals,
    getItemByProductId,
    getItemInCart,
    refreshCart,
    shippingTerm,
    willCallTerm,
    configuration,
  } = cart;

  const { openModal } = useModal();
  const { createToast } = useToast();

  // If there is a cartID, then fetch the item from the cart
  const cartItemId = searchParams.get('cartId');
  const [cartItem, setCartItem] = useState<CartItem | false>(
    cartItemId ? getItemInCart(parseInt(cartItemId, 10)) : false,
  );

  const [selectedManufacturer, setSelectedManufacturer] = useState<
    Manufacturer | undefined
  >();

  const [maxQuantity, setMaxQuantity] = useState<number | undefined>();
  const [quantity, setQuantity] = useState(1);
  const previousQuantity = useRef(quantity);
  const quantityInputRef = useRef<NumberBox>(null);

  const [warehouses, setWarehouses] = useState<AvailableWarehouse[]>([]);
  const [selectedWarehouse, setSelectedWarehouse] = useState<
    AvailableWarehouse | undefined
  >();

  const [selectedDelivery, setSelectedDelivery] = useState<
    ShippingTerm | undefined
  >();

  const [canSelectWarehouse, setCanSelectWarehouse] = useState(false);

  const [buttonStatus, setButtonStatus] = useState<'' | 'pending' | 'complete'>(
    '',
  );

  useEffect(() => {
    if (!cartItem) {
      return;
    }

    if (quantityInputRef.current) {
      quantityInputRef.current.instance.reset(cartItem.quantity);
    }

    setSelectedManufacturer({
      id: cartItem.manufacturerId,
      name: cartItem.manufacturerName,
      code: cartItem.manufacturerCode,
    });
    setSelectedWarehouse({
      id: cartItem.warehouseId,
      name: cartItem.warehouseName,
      code: cartItem.warehouseCode,
      price: cartItem.warehousePrice,
      multiplier: cartItem.warehouseMultiplier,
    } as AvailableWarehouse);
    setSelectedDelivery(
      cartItem.shipTermId === willCallTerm?.id ? willCallTerm : shippingTerm,
    );
  }, [cartItem, willCallTerm, shippingTerm]);

  const hasItemInCart = useMemo(() => {
    if (!id || !selectedManufacturer) {
      return false;
    }

    const item = getItemByProductId(id, selectedManufacturer.id);

    if (!item) {
      setCartItem(false);
      return false;
    }

    if (!cartItem) {
      setCartItem(item);
    }

    return item;
  }, [id, selectedManufacturer, getItemByProductId, cartItem]);

  // Update the add to cart text
  const addToCartText = useMemo(() => {
    var text = hasItemInCart ? 'Update in cart' : 'Add to cart';

    if ('pending' === buttonStatus) {
      text = hasItemInCart ? 'Updating in cart' : 'Adding to cart';
    }

    if ('complete' === buttonStatus) {
      text = hasItemInCart ? 'Updated in cart' : 'Added to cart';
    }

    return text;
  }, [buttonStatus, hasItemInCart]);

  // Update the add to cart button
  const canAddToCart = useMemo(() => {

    return (
      !!selectedManufacturer &&
      !!selectedWarehouse &&
      maxQuantity &&
      maxQuantity >= quantity &&
      'pending' !== buttonStatus
    );
  }, [
    selectedManufacturer,
    selectedWarehouse,
    buttonStatus,
    maxQuantity,
    quantity,
  ]);

  // Calculate the max number of items a customer can purchase
  const calculateMaxQuantity = useCallback(
    (price: number) => {

      // If we dont have any maximums then leave
      if (
        !configuration?.maximumOrderAmount &&
        !configuration?.maximumThresholdByLine
      ) {
        return;
      }

      let currentMax;

      // If the user has a maximum order amount then set the max as that minus the current cart subtotal
      if (configuration.maximumOrderAmount > 0) {
        currentMax = configuration.maximumOrderAmount - totals.subtotal;
      }

      // If the user has a line threshold amount and it is less than is currently available in the cart max, then set that as the max
      if (configuration.maximumThresholdByLine > 0) {
        if (!currentMax || currentMax > configuration.maximumThresholdByLine) {
          currentMax = configuration.maximumThresholdByLine;
        }
      }



      // There are no limits, then continue on
      if (!currentMax) {
        return;
      }

      const newMaxQuantity = Math.floor(currentMax / price);

      setMaxQuantity(Math.max(0, newMaxQuantity));
    },
    [configuration, totals.subtotal],
  );

  // Get the Warehouse availability when the manufacturer changes
  const getWarehouseAvailability = useCallback(async () => {
    if (!selectedManufacturer) {
      return;
    }

    // Fetch the product availability
    const { primary, alternates } = await getProductAvailability(
      id,
      selectedManufacturer.id,
      quantity,
      cart.id,
    );

    // Set if the user is allowed to change the warehouse
    setCanSelectWarehouse(!primary || allowChangeWarehouse);

    var selected;

    // If there is a primary, then select it. Otherwise get the first alternative and allow user to change
    if (
      !selectedWarehouse ||
      (primary?.id !== selectedWarehouse?.id &&
        !alternates.find(
          (w: AvailableWarehouse) => w.id === selectedWarehouse?.id,
        ))
    ) {
      selected = primary ?? (alternates ? alternates[0] : null);
      setSelectedWarehouse(selected);
    } else {
      selected = selectedWarehouse;
    }

    if (primary) {
      alternates.unshift(primary);
    }

    // Save the alternates for possible selection
    setWarehouses(alternates);

    // Calculate the maximum a user can order
    if (selected && !maxQuantity) {
      calculateMaxQuantity(selected.price * selected.multiplier);
    }
  }, [
    selectedManufacturer,
    id,
    quantity,
    cart.id,
    allowChangeWarehouse,
    selectedWarehouse,
    calculateMaxQuantity,
    maxQuantity,
  ]);

  // handle Manufacturer Change
  const handleManufacturerChange = useCallback((selected: Manufacturer) => {
    setSelectedManufacturer(( previousManufacturer ) => previousManufacturer?.id !== selected.id ? selected : previousManufacturer);
  }, []);

  // handle Delivery Change
  const handleDeliveryChange = useCallback((selected: ShippingTerm) => {
    setSelectedDelivery(( previousDelivery ) => previousDelivery?.id !== selected.id ? selected : previousDelivery);
  }, []);

  // Handle Quantity Change
  const handleUpdateQuantity = useDebouncedCallback((value: number) => {
    const roundedValue = Math.round(value);
    if (maxQuantity && roundedValue > maxQuantity) {
      if (quantityInputRef.current) {
        quantityInputRef.current.instance.reset(previousQuantity.current);
      }

      createToast(
        <>
          <strong>Inventory Query Limit Exceeded:</strong> You have exceeded the
          limit for querying inventory availability. Please contact your Allied
          representative for assistance with this order.
        </>,
        'error',
      );
      return;
    }

    if (roundedValue > 0) {
      previousQuantity.current = roundedValue;
      setQuantity(roundedValue);
      getWarehouseAvailability();
    }
  }, 250);

  // Handle Warehouse Change
  const handleChangeWarehouse = useCallback(
    async (newWarehouse: AvailableWarehouse) => {
      if (newWarehouse) {
        setSelectedWarehouse((previousWarehouse) => previousWarehouse?.id !== newWarehouse.id ? newWarehouse : previousWarehouse);
      }
    },
    [],
  );

  // Show the Change Warehouse modal
  const handleShowSelectWarehouseModal = useCallback(() => {
    openModal(
      <ModalSelectWarehouse
        product={product}
        warehouses={warehouses}
        selectedWarehouse={selectedWarehouse}
        onChange={handleChangeWarehouse}
      />,
      'Available Warehouses',
      ['modal__select-warehouse'],
      true,
    );
  }, [
    product,
    warehouses,
    selectedWarehouse,
    handleChangeWarehouse,
    openModal,
  ]);

  // Added to cart Modal
  const handleShowAddedToCartModal = useCallback(() => {
    if (!selectedWarehouse) {
      return;
    }

    const productCartData = {
      id,
      title,
      image,
      quantity,
      price: selectedWarehouse.price * selectedWarehouse.multiplier,
    };

    setTimeout(() => {
      openModal(
        <ModalAddedToCart product={productCartData} />,
        '1 Product Added to Cart',
        ['modal__added-to-cart'],
      );
    }, 1000);
  }, [openModal, id, title, image, quantity, selectedWarehouse]);

  // Add to cart handler
  const handleUpdateInCart = useCallback(async () => {
    if (
      !id ||
      !selectedManufacturer ||
      !selectedWarehouse ||
      !quantity ||
      !selectedDelivery
    ) {
      return;
    }

    let existingItem = getItemByProductId(id, selectedManufacturer.id);

    if (!existingItem) {
      return;
    }

    const isUpdatedInCart = await updateItemInCart(
      existingItem.cartId,
      cart.id,
      id,
      selectedManufacturer.id,
      selectedWarehouse.id,
      selectedWarehouse.price,
      selectedWarehouse.multiplier,
      quantity,
      selectedDelivery.id,
    );

    if (!isUpdatedInCart) {
      setButtonStatus('');
      createToast(<>Unable to update item in cart.</>, 'error');

      if (onError) {
        onError(ERROR_CART_NOT_ADDED);
      }
      return;
    }

    setButtonStatus('complete');
    await refreshCart();

    handleShowAddedToCartModal();

    setTimeout(() => {
      setButtonStatus(''); // Reset the button after modal is shown.
    }, 1000);
  }, [
    cart,
    id,
    selectedManufacturer,
    selectedWarehouse,
    selectedDelivery,
    quantity,
    refreshCart,
    getItemByProductId,
    handleShowAddedToCartModal,
    createToast,
    onError,
  ]);

  // Add to cart handler
  const handleAddToCart = useCallback(async () => {
    if (
      !id ||
      !selectedManufacturer ||
      !selectedWarehouse ||
      !quantity ||
      !selectedDelivery
    ) {
      return;
    }

    const isAddedToCart = await addItemToCart(
      id,
      selectedManufacturer.id,
      selectedWarehouse.id,
      selectedWarehouse.price,
      selectedWarehouse.multiplier,
      quantity,
      selectedDelivery.id,
    );

    if (!isAddedToCart) {
      setButtonStatus('');
      createToast(<>Unable to add item to cart.</>, 'error');

      if (onError) {
        onError(ERROR_CART_NOT_ADDED);
        console.error(ERROR_CART_NOT_ADDED);
      }
      return;
    }

    setButtonStatus('complete');
    await refreshCart();
    handleShowAddedToCartModal();

    setTimeout(() => {
      setButtonStatus(''); // Reset the button after modal is shown.
    }, 1000);
  }, [
    id,
    selectedManufacturer,
    selectedWarehouse,
    selectedDelivery,
    quantity,
    refreshCart,
    handleShowAddedToCartModal,
    createToast,
    onError,
  ]);

  // Validate the item
  const handleValidate = useCallback(async () => {
    setButtonStatus('pending');

    if (
      !selectedManufacturer ||
      !selectedWarehouse ||
      !selectedDelivery ||
      !configuration
    ) {
      setButtonStatus('');
      return;
    }

    // Refresh the cart before adding to get the latest
    const updatedCart = await refreshCart();

    // First, do a simple validation of the quantity * price to ensure we are not over the maximums
    const estimatedCost =
      selectedWarehouse.price * selectedWarehouse.multiplier * quantity;

    // estimated cost exceeds the cart threshold
    if (
      configuration.maximumOrderAmount &&
      estimatedCost + (updatedCart?.totals?.subtotal ?? 0) >
      configuration.maximumOrderAmount
    ) {
      createToast(
        <>
          <strong>Cart Limit Reached:</strong> You have reached the maximum
          order limit for your order. Please contact your Allied representative
          for help with this order.
        </>,
        'error',
      );
      setButtonStatus('');
      return;
    }

    // estimated cost exceeds the line threshold
    if (
      configuration.maximumThresholdByLine &&
      estimatedCost > configuration.maximumThresholdByLine
    ) {
      createToast(
        <>
          <strong>Line Item Limit Reached:</strong> You have reached the maximum
          line item limit for this part. Please contact your Allied
          representative for help with this order.
        </>,
        'error',
      );
      setButtonStatus('');
      return;
    }

    // Next, we need to validate the quantity
    const validationQuantity = await validateQuantity(id, quantity);

    // The quantity is not valid,
    if (!validationQuantity.isValid) {
      setButtonStatus('');
      createToast(
        <>
          <strong>Inventory Query Limit Exceeded:</strong> You have exceeded the
          limit for querying inventory availability. Please contact your Allied
          representative for assistance with this order.
        </>,
        'error',
      );

      if (onError) {
        onError(ERROR_CART_QUANTITY);
      }
      return;
    }

    const isOverThreshold = await validateThreshold(
      cart.id,
      id,
      quantity,
      selectedManufacturer.id,
      selectedWarehouse.id,
      selectedDelivery.id,
    );

    if (isOverThreshold) {
      setButtonStatus('');
      createToast(
        <>
          <strong>Line Item Limit Reached:</strong> You have reached the maximum
          line item limit for this part. Please contact your Allied
          representative for help with this order.
        </>,
        'error',
      );

      if (onError) {
        onError(ERROR_CART_THRESHOLD);
      }
      return;
    }

    // Validation Passed, update cart if it exists or add it
    if (hasItemInCart || cartItem) {
      handleUpdateInCart();
    } else {
      handleAddToCart();
    }
  }, [
    cartItem,
    id,
    quantity,
    selectedManufacturer,
    selectedWarehouse,
    selectedDelivery,
    cart.id,
    configuration,
    hasItemInCart,
    refreshCart,
    handleAddToCart,
    handleUpdateInCart,
    createToast,
    onError,
  ]);

  useEffect(() => {
    (async () => {
      await getWarehouseAvailability();
    })();
  }, [getWarehouseAvailability]);

  return (
    <div className="product-add-to-cart">
      <ManufacturerSelect
        defaultValue={selectedManufacturer}
        onChange={handleManufacturerChange}
      />

      {selectedWarehouse ? (
        <>
          <DeliverySelect
            defaultValue={selectedDelivery}
            warehouse={selectedWarehouse}
            canChangeWarehouse={canSelectWarehouse}
            onChange={handleDeliveryChange}
            onChangeWarehouse={handleShowSelectWarehouseModal}
          />

          {selectedDelivery && (
            <DeliveryMessage
              warehouse={selectedWarehouse}
              delivery={selectedDelivery}
            />
          )}
        </>
      ) : (
        <>
          <NextAvailableManufacturer
            id={id}
            quantity={quantity}
            manufacturer={selectedManufacturer}
            onSelect={handleManufacturerChange}
          />
        </>
      )}

      {hasItemInCart && (
        <div className="notice notice-info text-wrap">
          This item combination is in your cart. Changes will update the
          existing item.
        </div>
      )}

      <div className="product-add-to-cart_actions">
        <NumberBox
          ref={quantityInputRef}
          className="input-quantity"
          name="quantity"
          min={1}
          defaultValue={quantity}
          valueChangeEvent="input"
          onValueChange={handleUpdateQuantity}
          disabled={!canAddToCart}
        />
        <FancyButton
          text={addToCartText}
          className="btn-primary"
          status={buttonStatus}
          onClick={handleValidate}
          disabled={!canAddToCart}
        />
      </div>
    </div>
  );
});
