

import { memo, useMemo } from 'react';
import { useCart } from '../../contexts/CartProvider';
import { Warehouse } from '../../types/products';
import convertToTime, { getHours, isWeekday } from '../../utils/convertToTime';
import { ShippingTerm } from '../../types/customer';
import { SHIPPING_TERM_COLLECT, SHIPPING_TERM_WILL_CALL } from '../../constants';

export default memo(function DeliveryMessage({
  warehouse,
  delivery,
}: {
  warehouse: Warehouse | undefined;
  delivery: ShippingTerm | undefined;
}) {
  const { willCallCombination, cartAddress } = useCart();

  const currentHour = new Date().getHours();

  const willCallPickupHour = useMemo(() => {
    if (!willCallCombination) {
      return;
    }

    return getHours(willCallCombination.shipViaCutOffTime) ?? 15;
  }, [willCallCombination]);

  const willCallPickupDay = useMemo(() => {
    if (!willCallPickupHour || !isWeekday()) {
      return 0;
    }

    return (willCallPickupHour as number) - currentHour;
  }, [willCallPickupHour, currentHour]);

  const willCallCutoffTime = useMemo(() => {
    if (!willCallCombination) {
      return;
    }

    return convertToTime(willCallCombination.shipViaCutOffTime);
  }, [willCallCombination]);

  return (
    <div className="product-add-to-cart_shipping">
      {SHIPPING_TERM_WILL_CALL === delivery?.code && (
        <>
          <p>
            Pickup at <strong>{warehouse?.name}</strong>
          </p>

          {willCallCombination && (
            <p className="text-grey-muted">
              Order within{' '}
              {willCallPickupDay > 0
                ? willCallPickupDay
                : 24 + willCallPickupDay}{' '}
              hrs. – Get it before {willCallCutoffTime}
            </p>
          )}
        </>
      )}
      {SHIPPING_TERM_COLLECT === delivery?.code && (
        <>
          {cartAddress && (
            <p>
              Ships to{' '}
              <strong>{cartAddress.postalCode?.substring(0, 5)}</strong>
            </p>
          )}

          <p className="text-grey-muted">
            Shipping options available in checkout
          </p>
        </>
      )}
    </div>
  );
});
