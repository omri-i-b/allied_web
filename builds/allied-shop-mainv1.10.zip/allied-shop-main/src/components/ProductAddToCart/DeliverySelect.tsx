

import {
  memo,
  ChangeEvent,
  useCallback,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { useCart } from '../../contexts/CartProvider';
import { Warehouse } from '../../types/products';
import { getHours, isWeekday } from '../../utils/convertToTime';
import { v4 as uuidv4 } from 'uuid';
import { ShippingTerm } from '../../types/customer';

const shipDateFormat = new Intl.DateTimeFormat('en-US', {
  weekday: 'long',
});

export default memo(function DeliverySelect({
  defaultValue,
  warehouse,
  canChangeWarehouse = false,
  onChange,
  onChangeWarehouse,
}: {
  defaultValue?: ShippingTerm;
  warehouse?: Warehouse;
  canChangeWarehouse: boolean;
  onChange: (_delivery: ShippingTerm) => void;
  onChangeWarehouse?: () => void;
}) {
  const uuid = uuidv4();
  const {
    hasShipping,
    hasWillCall,
    shippingTerm,
    willCallTerm,
    shippingCombination,
    willCallCombination,
  } = useCart();

  // Set the default as shipping
  const initialSelected = hasShipping ? shippingTerm : willCallTerm;

  const [selected, setSelected] = useState<ShippingTerm | undefined>(
    defaultValue ?? initialSelected,
  );

  // Get the current Date
  const today = useMemo(() => new Date(), []);
  const currentHour = today.getHours();

  const shippingPickupHour = useMemo(() => {
    if (!shippingCombination || !hasShipping) {
      return;
    }

    return getHours(shippingCombination.shipViaCutOffTime) ?? 15;
  }, [shippingCombination, hasShipping]);

  const shippingPickupDay = useMemo(() => {
    const pickupDay = new Date(today);
    if (0 >= (shippingPickupHour as number) - currentHour || !isWeekday()) {
      var add;

      switch (today.getDay()) {
        case 6:
          add = 2;
          break;
        case 5:
          add = 3;
          break;
        default:
          add = 1;
          break;
      }

      // Return the next business day
      pickupDay.setDate(pickupDay.getDate() + add);
    }

    // Return today
    return pickupDay;
  }, [shippingPickupHour, today, currentHour]);

  const willCallPickupHour = useMemo(() => {
    if (!willCallCombination || !hasWillCall) {
      return;
    }

    return getHours(willCallCombination.shipViaCutOffTime) ?? 15;
  }, [willCallCombination, hasWillCall]);

  const willCallPickupDay = useMemo(() => {
    const pickupDay = new Date(today);
    if (0 >= (willCallPickupHour as number) - currentHour || !isWeekday()) {
      var add;

      switch (today.getDay()) {
        case 6:
          add = 2;
          break;
        case 5:
          add = 3;
          break;
        default:
          add = 1;
          break;
      }

      // Return the next business day
      pickupDay.setDate(pickupDay.getDate() + add);
    }

    // Return today
    return pickupDay;
  }, [willCallPickupHour, today, currentHour]);

  /**
   * Update the selected delivery method
   */
  const handleDeliveryChange = useCallback(
    (e: ChangeEvent) => {
      const target = e?.target as HTMLInputElement;

      setSelected('willcall' === target.value ? willCallTerm : shippingTerm);
    },
    [willCallTerm, shippingTerm],
  );

  /**
   * Show the Select Warehouse Modal
   */
  const handleChangeWarehouse = useCallback(() => {
    if (onChangeWarehouse) {
      onChangeWarehouse();
    }
  }, [onChangeWarehouse]);

  /**
   * Trigger onChange if selected is changed
   */
  useEffect(() => {
    if (selected && onChange) {
      onChange(selected);
    }
  }, [selected, onChange]);

  return (
    <ul className="product-add-to-cart_delivery">
      <li className="product-add-to-cart_delivery_option">
        <input
          type="radio"
          id={`delivery_ship[${uuid}]`}
          name="delivery"
          value="ship"
          defaultChecked={!!(shippingTerm === selected)}
          onChange={handleDeliveryChange}
          disabled={!warehouse || !hasShipping}
        />
        <label htmlFor={`delivery_ship[${uuid}]`}>
          <strong>Ship</strong>
          {warehouse && (
            <p>
              {shippingPickupDay.getDate() === today.getDate()
                ? `today`
                : shipDateFormat.format(shippingPickupDay)}{' '}
              from&nbsp;
              {canChangeWarehouse ? (
                <button
                  type="button"
                  className="btn-link"
                  onClick={handleChangeWarehouse}
                >
                  {warehouse.name}
                </button>
              ) : (
                <>{warehouse.name}</>
              )}
            </p>
          )}
          {!warehouse && <p>Not Available</p>}
        </label>
      </li>
      <li className="product-add-to-cart_delivery_option">
        <input
          type="radio"
          id={`delivery_willcall[${uuid}]`}
          name="delivery"
          value="willcall"
          defaultChecked={!!(willCallTerm === selected)}
          onChange={handleDeliveryChange}
          disabled={!warehouse || !hasWillCall}
        />
        <label htmlFor={`delivery_willcall[${uuid}]`}>
          <strong>Will Call</strong>
          {warehouse && (
            <p>
              {willCallPickupDay.getDate() === today.getDate()
                ? `today`
                : shipDateFormat.format(willCallPickupDay)}{' '}
              at&nbsp;
              {canChangeWarehouse ? (
                <button
                  type="button"
                  className="btn-link"
                  onClick={handleChangeWarehouse}
                >
                  {warehouse.name}
                </button>
              ) : (
                <>{warehouse.name}</>
              )}
            </p>
          )}
          {!warehouse && <p>Not Available</p>}
        </label>
      </li>
    </ul>
  );
});
