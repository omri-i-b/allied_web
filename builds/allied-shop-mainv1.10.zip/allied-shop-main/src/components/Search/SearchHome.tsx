import { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { getPreSearch } from "../../actions";
import { PreSearchResults } from "../../types/products";
import { TextBox, Button as TextBoxButton } from "devextreme-react/text-box";
import { ButtonTypes } from "devextreme-react/button";
import { FocusInEvent, InputEvent } from "devextreme/ui/text_box";
import SearchSuggestions from "../../components/Search/SearchSuggestions";
import debounce from "lodash/debounce";

import "./SearchHome.scss";

export default function SearchHome() {
  const [search, setSearch] = useState("");
  const [results, setResults] = useState<PreSearchResults | undefined>(
    undefined
  );
  const [showResults, setShowResults] = useState(false);

  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<TextBox>(null);

  /**
   * Handle Body Clicks to close menus
   */
  useEffect(() => {
    function handleBodyClick({ target }: MouseEvent) {
      if (showResults && !searchRef.current?.contains(target as Node)) {
        setShowResults(false);
      }
    }

    document.addEventListener("click", handleBodyClick);

    return () => document.removeEventListener("click", handleBodyClick);
  }, [showResults]);

  useEffect(() => {
    const abortController = new AbortController();
    const signal = abortController.signal;

    // Make sure that we have at least 2 character
    if (search.length > 1) {
      (async () => {
        if (!signal.aborted) {
          const data = await getPreSearch(search);

          setResults(data);
          setShowResults(true);
        }
      })();

      // Clear the results
    } else {
      setResults(undefined);
      setShowResults(false);
    }

    return () => {
      abortController.abort();
    };
  }, [search]);

  const handleChange = (e: InputEvent) => {
    const inputValue = (e.event?.currentTarget as HTMLInputElement).value;

    if (inputValue) {
      setSearch(inputValue);
    }
  };

  const debouncedHandleChange = debounce(handleChange, 300);

  const handleFocus = useCallback(
    (e: FocusInEvent) => {
      e.event?.stopPropagation();

      if (results) {
        setShowResults(true);
      }
    },
    [results, setShowResults]
  );

  const searchButton = useMemo<ButtonTypes.Properties>(
    () => ({
      icon: "/icons/search.svg",
      stylingMode: "text",
      useSubmitBehavior: true,
    }),
    []
  );

  const searchPrimaryButton = useMemo<ButtonTypes.Properties>(
    () => ({
      text: "Search",
      stylingMode: "contained",
      useSubmitBehavior: true,
    }),
    []
  );

  const handleExampleSearch = useCallback(() => {
    setSearch("6 STD 90");
  }, []);

  /**
   * Reset the search back to empty
   */
  const handleReset = useCallback(() => {
    inputRef.current?.instance.reset();
    setSearch("");
  }, [setSearch]);

  return (
    <div className="home__hero_search">
      <div className="product-search" ref={searchRef}>
        <form className="search-form" action="/search" method="GET">
          <TextBox
            name="q"
            ref={inputRef}
            value={search}
            placeholder="Search for part"
            labelMode="hidden"
            onInput={debouncedHandleChange}
            onFocusIn={handleFocus}
          >
            <TextBoxButton
              name="search"
              location="before"
              options={searchButton}
            />
            <TextBoxButton
              name="searchButton"
              location="after"
              options={searchPrimaryButton}
            />
          </TextBox>
        </form>
        {showResults && (
          <SearchSuggestions results={results} onClear={handleReset} />
        )}
      </div>
      <div>
        Try an example:{" "}
        <button
          type="button"
          className="btn-secondary-link"
          onClick={handleExampleSearch}
        >
          6 STD 90
        </button>
      </div>
    </div>
  );
}
