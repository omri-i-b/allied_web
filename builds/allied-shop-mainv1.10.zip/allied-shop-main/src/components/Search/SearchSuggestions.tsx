import { useCallback } from 'react';
import { PreSearchResults } from '../../types/products';
import { ReactComponent as IconSearch } from '../../assets/icons/search.svg';
import './SearchSuggestions.scss';
import { Link } from 'react-router-dom';
import Image from '../Image/Image';


interface SearchSuggestionsProps {
  results?: PreSearchResults;
  onClear?: () => void;
}

export default function SearchSuggestions({
  results,
  onClear,
}: SearchSuggestionsProps) {
  const handleItemClick = useCallback(() => {
    if (onClear) {
      onClear();
    }
  }, [onClear]);

  if (!results) {
    return null;
  }

  const { 
    products,
    categories, 
    gradeProducts, 
    shapeProducts, 
    scheduleProducts, 
    pressureProducts, 
    size1Products, 
    size2Products, 
    size3Products, 
    size4Products, 
    suggestions 
  } = results;

  const hasProducts = !!(products && products.length);
  const hasSuggestions = !!(suggestions && suggestions.length);
  const hasCategories = !!(categories && categories.length);
  const hasGradeProducts = !!(gradeProducts && gradeProducts.length);
  const hasShapeProducts = !!(shapeProducts && shapeProducts.length);
  const hasScheduleProducts = !!(scheduleProducts && scheduleProducts.length);
  const hasPressureProducts = !!(pressureProducts && pressureProducts.length);
  const hasSize1Products = !!(size1Products && size1Products.length);
  const hasSize2Products = !!(size2Products && size2Products.length);
  const hasSize3Products = !!(size3Products && size3Products.length);
  const hasSize4Products = !!(size4Products && size4Products.length);
  
  const show =
    hasProducts  
    || hasCategories  
    || gradeProducts  
    || shapeProducts  
    || scheduleProducts  
    || pressureProducts  
    || hasSuggestions 
    || hasSize1Products;

  return (
    <>
      {show && (
        <div className="product-search__results">
          <div className="product-search__results_suggestions">
            {hasSuggestions && (
              <dl>
                <dt>Suggestions</dt>
                <dd>
                  <ul>
                    {suggestions.map(({ objectID, query }) => {
                      return (
                        <li key={`search-suggestion-${objectID}`}>
                          <Link
                            to={`/search?q=${encodeURIComponent(query)}`}
                            onClick={handleItemClick}
                          >
                            <i className="icon icon-search">
                              <IconSearch />
                            </i>
                            <span>{query}</span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </dd>
              </dl>
            )}

            {hasProducts && (
              <dl>
                <dt>Products</dt>
                <dd>
                  <ul>
                    {products.map(({ id, title, slug }) => {
                      return (
                        <li key={`search-product-${id}`}>
                          <Link to={slug} onClick={handleItemClick}>
                            <span>{title}</span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </dd>
              </dl>
            )}
          </div>
          <div className="product-search__results_rule"></div>
          <div className="product-search__results_categories">
            {hasCategories && (
              <dl>
                <dt>Categories</dt>
                <dd>
                  <ul>
                    {categories.map(({ title, image, slug }) => {
                      return (
                        <li key={`search-category-${title}`}>
                          <Link to={slug} onClick={handleItemClick}>
                            <figure>
                              <Image
                                src={image}
                                alt={title}
                                width={150}
                                height={150}
                                loading="lazy"
                              />
                            </figure>
                            <span>{title}</span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </dd>
              </dl>
            )}
            {hasGradeProducts && (
              <dl>
                <dt>Grades</dt>
                <dd>
                  <ul>
                    {gradeProducts.map(({ prefix, title, image, slug }) => {
                      return (
                        <li key={`search-subcategory-${title}`}>
                          <Link to={slug} onClick={handleItemClick}>
                            <figure>
                              <Image
                                src={image}
                                alt={title}
                                width={150}
                                height={150}
                                loading="lazy"
                              />
                            </figure>
                            <span>
                              {prefix && <cite>{prefix} / </cite>}
                              {title}
                            </span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </dd>
              </dl>
            )}
            {hasShapeProducts && (
              <dl>
                <dt>Shapes</dt>
                <dd>
                  <ul>
                    {shapeProducts.map(({ prefix, title, image, slug }) => {
                      return (
                        <li key={`search-subcategory-${title}`}>
                          <Link to={slug} onClick={handleItemClick}>
                            <figure>
                              <Image
                                src={image}
                                alt={title}
                                width={150}
                                height={150}
                                loading="lazy"
                              />
                            </figure>
                            <span>
                              {prefix && <cite>{prefix} / </cite>}
                              {title}
                            </span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </dd>
              </dl>
            )}
            {hasScheduleProducts && (
              <dl>
                <dt>Schedule</dt>
                <dd>
                  <ul>
                    {scheduleProducts.map(({ prefix, title, image, slug }) => {
                      return (
                        <li key={`search-subcategory-${title}`}>
                          <Link to={slug} onClick={handleItemClick}>
                            <figure>
                              <Image
                                src={image}
                                alt={title}
                                width={150}
                                height={150}
                                loading="lazy"
                              />
                            </figure>
                            <span>
                              {prefix && <cite>{prefix} / </cite>}
                              {title}
                            </span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </dd>
              </dl>
            )}
            {hasPressureProducts && (
              <dl>
                <dt>Pressure</dt>
                <dd>
                  <ul>
                    {pressureProducts.map(({ prefix, title, image, slug }) => {
                      return (
                        <li key={`search-subcategory-${title}`}>
                          <Link to={slug} onClick={handleItemClick}>
                            <figure>
                              <Image
                                src={image}
                                alt={title}
                                width={150}
                                height={150}
                                loading="lazy"
                              />
                            </figure>
                            <span>
                              {prefix && <cite>{prefix} / </cite>}
                              {title}
                            </span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </dd>
              </dl>
            )}
            {hasSize1Products && (
              <dl>
                <dt>Size</dt>
                <dd>
                  <ul>
                    {size1Products.map(({ prefix, title, image, slug }) => {
                      return (
                        <li key={`search-subcategory-${title}`}>
                          <Link to={slug} onClick={handleItemClick}>
                            <figure>
                              <Image
                                src={image}
                                alt={title}
                                width={150}
                                height={150}
                                loading="lazy"
                              />
                            </figure>
                            <span>
                              {prefix && <cite>{prefix} / </cite>}
                              {title}
                            </span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </dd>
              </dl>
            )}
            {hasSize2Products && (
              <dl>
                <dt>Size 2</dt>
                <dd>
                  <ul>
                    {size2Products.map(({ prefix, title, image, slug }) => {
                      return (
                        <li key={`search-subcategory-${title}`}>
                          <Link to={slug} onClick={handleItemClick}>
                            <figure>
                              <Image
                                src={image}
                                alt={title}
                                width={150}
                                height={150}
                                loading="lazy"
                              />
                            </figure>
                            <span>
                              {prefix && <cite>{prefix} / </cite>}
                              {title}
                            </span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </dd>
              </dl>
            )}
            {hasSize3Products && (
              <dl>
                <dt>Size 3</dt>
                <dd>
                  <ul>
                    {size3Products.map(({ prefix, title, image, slug }) => {
                      return (
                        <li key={`search-subcategory-${title}`}>
                          <Link to={slug} onClick={handleItemClick}>
                            <figure>
                              <Image
                                src={image}
                                alt={title}
                                width={150}
                                height={150}
                                loading="lazy"
                              />
                            </figure>
                            <span>
                              {prefix && <cite>{prefix} / </cite>}
                              {title}
                            </span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </dd>
              </dl>
            )}
            {hasSize4Products && (
              <dl>
                <dt>Size 4</dt>
                <dd>
                  <ul>
                    {size4Products.map(({ prefix, title, image, slug }) => {
                      return (
                        <li key={`search-subcategory-${title}`}>
                          <Link to={slug} onClick={handleItemClick}>
                            <figure>
                              <Image
                                src={image}
                                alt={title}
                                width={150}
                                height={150}
                                loading="lazy"
                              />
                            </figure>
                            <span>
                              {prefix && <cite>{prefix} / </cite>}
                              {title}
                            </span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>
                </dd>
              </dl>
            )}
          </div>
        </div>
      )}
    </>
  );
}
