import React, { useEffect } from 'react';
import GridCategory from '../Grid/GridCategory';
import { Link } from 'react-router-dom';

interface ErrorProps {
  error: Error & { digest?: string };
  reset: () => void;
}

const ErrorComponent: React.FC<ErrorProps> = ({ error, reset }) => {
  useEffect(() => {
    // Log the error to an error reporting service
    console.error(error);
  }, [error]);

  return (
    <main className="page page__error">
      <div className="container">
        <article>
          <section className="page__error_section">
            <h2 className="page__error_title">
              Something went wrong
            </h2>
            <p className="page__error_description">
              The page you attempted to view was unable to display correctly. Please try again or contact Allied.
            </p>

            <p className="page__error_cta"><Link to="/" className="btn btn-primary"><span className="dx-button-content">Back to homepage</span></Link></p>

            <GridCategory />
          </section>
        </article>
      </div>
    </main>
  );
};

export default ErrorComponent;
