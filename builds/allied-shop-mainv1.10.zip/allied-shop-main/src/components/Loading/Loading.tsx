export default function Loading() {
    return (
      <main className="page page__loading">
        <div className="container">
          <div className="box__loader">
            <div className="spinner"></div>
            <p>Loading...</p>
          </div>
        </div>
      </main>
    );
  }
  