
import './login.scss';
import { useState, useMemo, useEffect } from 'react';
import { Validator, RequiredRule, EmailRule } from 'devextreme-react/validator';
import {
  TextBox,
  Button as TextBoxButton,
  TextBoxTypes,
} from 'devextreme-react/text-box';
import { ButtonTypes } from 'devextreme-react/button';
import { Link } from 'react-router-dom';
import { Controller, useForm } from 'react-hook-form';
import { login } from '../../lib/authentication';
import ErrorComponent from '../Error/Error';
import FancyButton from '../FancyButton/FancyButton';


export default function Login() {
  const [passwordMode, setPasswordMode] =
    useState<TextBoxTypes.TextBoxType>('password');
  const { handleSubmit, control } = useForm();
  const [response, setResponse] = useState<any>();
  const [hasError, setHasError] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(false);

  const onSubmit = async (data: any) => {
    setLoading(true);
    const {email, password} = data;    
    
    try {
      const newResponse = await login(email, password);
      setResponse(newResponse);
      setLoading(false);
    } catch (error) {
      setHasError(true);
      setError(error as Error);
      setLoading(false);
    } 

  };

  function EmailField({ field }: any) {
    function emailValueChanged(e: any) {
      field.onChange(e.value);
    }

    return <TextBox
      name="email"
      label="Email *"
      labelMode="outside"
      inputAttr={{ 'aria-label': 'Email' }}
      placeholder="filip@email.com"
      onValueChanged={emailValueChanged}
      value={field.value}
    >
      <Validator>
        <RequiredRule message="Email is required" />
        <EmailRule message="Email is invalid" />
      </Validator>
    </TextBox>
  }

  function PasswordField({ field }: any) {
    function passwordValueChanged(e: any) {
      field.onChange(e.value);
    }

    return <TextBox
      name="password"
      label="Password *"
      labelMode="outside"
      maxLength={50}
      mode={passwordMode}
      inputAttr={{ 'aria-label': 'Password' }}
      placeholder="********"
      onValueChanged={passwordValueChanged}
      value={field.value}
    >
      <TextBoxButton
        name="password"
        location="after"
        options={passwordVisibilityButton}
      />
      <Validator>
        <RequiredRule message="Password is required" />
      </Validator>
    </TextBox>
  }


  useEffect(() => {
    if (response?.success) {
      // Force a full refresh to hydrate the server with the extra user data
      window.location.href = '/';
    }
  }, [response]);

  

  const passwordVisibilityButton = useMemo<ButtonTypes.Properties>(
    () => ({
      icon:
        passwordMode === 'text'
          ? '/icons/visibility-on.svg'
          : '/icons/visibility-off.svg',
      stylingMode: 'text',
      onClick: () => {
        setPasswordMode((prevPasswordMode: string) =>
          prevPasswordMode === 'text' ? 'password' : 'text',
        );
      },
    }),
    [setPasswordMode, passwordMode],
  );

  const resetError = () => {
    setHasError(false);
    setError(null);
  };

  if (hasError && error) {
    return <ErrorComponent error={error} reset={resetError} />;
  }
  

  return (
    !error && 
    <section className="box__login">
      <form className="box__login_form" onSubmit={handleSubmit(onSubmit)}>
        <h2 className="box__login_title">Log in to Allied Group</h2>

        <fieldset className="box__login_fields">
          <Controller
            name="email"
            control={control}
            render={EmailField}>
          </Controller>
          <Controller
            name="password"
            control={control}
            render={PasswordField}>
          </Controller>
          {response?.error && (
            <p className="box__login_error error">
              Unable to log in using credentials
            </p>
          )}
        </fieldset>
        <div className="box__login_actions">
          <FancyButton
            className="btn btn-primary"
            disabled={loading}
            useSubmitBehavior={true}
            text={loading ? `Logging in` : `Log in`}
            status={ loading ? 'pending' : ''}
          />
        </div>
        <div className="box__login_link">
          <p>
            Don&apos;t Have an Account? <Link to="/register">Register</Link>
          </p>
        </div>
      </form>
    </section>
  );
}