

import { useCart } from '../../contexts/CartProvider';
import GridCategory from '../../components/Grid/GridCategory';
import CartItems from '../../components/CartItems/CartItems';
import OrderSummary from '../../components/OrderSummary/OrderSummary';
import { useState } from 'react';

export default function CartContent() {
  const { count, clearCart } = useCart();

  const [hasRemovedItems, setHasRemovedItems] = useState(false);

  const cartEmpty = !!(count < 1);

  return (
    <>
      {cartEmpty && !hasRemovedItems ? (
        <div className="container">
          <article>
            <section className="page__cart_cart-empty">
              <h2 className="page__cart_cart-empty_title">
                Your Cart is Empty
              </h2>
              <p className="page__cart_cart-empty_description">
                It looks like you haven&apos;t added any items to your cart yet.
                Start shopping by category to find the products you need.
              </p>

              <GridCategory />
            </section>
          </article>
        </div>
      ) : (
        <>
          <div className="container">
            <article>
              <div className="page__cart_header">
                <h1 className="page__cart_title">
                  Cart Summary <span>({count} items)</span>
                </h1>

                <button className="btn-secondary-link" onClick={clearCart}>Clear Cart</button>
              </div>

              <CartItems setHasRemovedItems={setHasRemovedItems} />
            </article>

            <aside>
              <OrderSummary />
            </aside>
          </div>
        </>
      )}
    </>
  );
}
