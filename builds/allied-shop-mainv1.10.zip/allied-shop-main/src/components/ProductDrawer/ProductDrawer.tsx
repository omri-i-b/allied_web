import { useEffect, useState } from 'react';
import { getCategoryById, getProductById } from '../../actions';
import { Product } from '../../types/products';
import { Category, Subcategory } from '../../types/categories';
import { DataGridTypes } from 'devextreme-react/data-grid';
import ProductAddToCart from '../../components/ProductAddToCart/ProductAddToCart';
import './ProductDrawer.scss';
import { Link } from 'react-router-dom';

export default function ProductDrawer({
  data,
}: DataGridTypes.MasterDetailTemplateData) {
  const [category, setCategory] = useState<Category | null>(null);
  const [product, setProduct] = useState<Product | null>(null);

  // Fetch the product
  useEffect(() => {
    const fetchData = async () => {
      const productResponse = await getProductById(data.data.id);

      if (productResponse) {
        const categoryResponse = await getCategoryById(
          productResponse.categoryId,
        );

        if (!categoryResponse || !productResponse) {
          return null;
        }

        setCategory(categoryResponse);
        setProduct(productResponse);
      }
    };

    fetchData();
  }, [data]);

  if (!product || !category) {
    return null;
  }

  const subcategory: Subcategory | undefined = category.subcategories.find(
    (subcategory: Subcategory) => subcategory.id === product.subcategoryId,
  );

  if (!subcategory) {
    return null;
  }

  return (
    <div className="product-drawer" aria-label="Expand">
      <div className="product-drawer_description">
        <h2 className="product-drawer_title">{product.title}</h2>
        <p className="product-drawer_sku">
          <strong>Part #</strong> {product.sku}
        </p>

        <Link className="btn-primary-link" to={product.slug}>
          View Product Details
        </Link>
      </div>
      <div className="product-drawer_add-to-cart">
        <ProductAddToCart product={product} />
      </div>
    </div>
  );
}
