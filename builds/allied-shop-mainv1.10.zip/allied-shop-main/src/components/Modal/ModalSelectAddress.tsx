
import './ModalSelectAddress.scss';
import { useModal } from '../../contexts/ModalProvider';
import { useCallback, useState } from 'react';
import { Address } from '../../types/customer';
import Addresses from '../../components/Addresses/Addresses';
import { Button } from 'devextreme-react/button';

interface ModalSelectAddressProps {
  addressList: Address[];
  onSelect?: (_address: Address) => void;
}

export default function ModalSelectAddress({
  addressList,
  onSelect,
}: ModalSelectAddressProps) {
  const { closeModal } = useModal();
  const [selectedAddress, setSelectedAddress] = useState<Address>();

  const onSelectionChanged = useCallback(
    (e: any) => {
      e.component
        .byKey(e.currentSelectedRowKeys[0])
        .done((address: Address) => {
          setSelectedAddress(address);
        });
    },
    [setSelectedAddress],
  );

  const handleSelect = useCallback(() => {
    if (selectedAddress && onSelect) {
      onSelect(selectedAddress);
    }

    closeModal();
  }, [selectedAddress, onSelect, closeModal]);

  return (
    <>
      <div className="modal__body">
        <Addresses
          serverAddresses={addressList}
          onSelectionChanged={onSelectionChanged}
          selectOnly={true}
        />
      </div>
      <div className="modal__foot">
        <Button className="btn btn-primary" onClick={handleSelect} disabled={!selectedAddress}>
          Select
        </Button>
      </div>
    </>
  );
}
