
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useModal } from '../../contexts/ModalProvider';
import { Address } from '../../types/customer';
import { getCities, getStates, getUPSAddresses } from '../../actions';
import { Autocomplete, AutocompleteTypes } from 'devextreme-react/autocomplete';
import { TextBox, TextBoxTypes } from 'devextreme-react/text-box';
import { SelectBox, SelectBoxTypes } from 'devextreme-react/select-box';
import { ValidationGroup } from 'devextreme-react/validation-group';
import { Validator, RequiredRule, StringLengthRule } from 'devextreme-react/validator';
import ModalAddressVerify from './ModalAddressVerify';
import FancyButton from '../../components/FancyButton/FancyButton';
import './ModalEditAddress.scss';

interface ModalEditAddressProps {
  address?: Address;
  onComplete?: (_address: Address) => void;
}

const initialAddress = {
  id: 0,
  name: '',
  street1: '',
  city: '',
  state: '',
  postalCode: '',
  country: '',
  isVerified: false,
};

export default function ModalEditAddress(props: ModalEditAddressProps) {
  const { openModal } = useModal();

  const [buttonStatus, setButtonStatus] = useState<'pending' | 'complete' | ''>(
    '',
  );

  const [stateList, setStateList] =
    useState<
      { id: number; code: string; description: string; countryId: number }[]
    >();
  const [cityList, setCityList] =
    useState<
      { id: number; code: string; description: string; stateId: number }[]
    >();
  const [address, setAddress] = useState<Address>(
    props.address ?? initialAddress,
  );

  const filteredCityList = useMemo(() => {
    if (!stateList) {
      return cityList;
    }

    return cityList?.filter( (city) => stateList?.find( (state) => state.id === city.stateId));
  }, [cityList, stateList]);

  const bodyRef = useRef(null);
  const cityInputRef = useRef(null);
  const stateInputRef = useRef<SelectBox>(null);
  const validationGroupRef = useRef<ValidationGroup>(null);

  const saveButtonText = props.address ? 'Save' : 'Add';

  const renderCity = (data: any) => {
    const state = stateList?.find((s) => s.id === data.stateId);

    return (
      <span>
        {data.description}, {state?.code}
      </span>
    );
  };

  /**
   * Update the address values in the state
   */
  const updateAddressValue = useCallback(
    (key: string, val: string) => {
      const newAddress: { [key: string]: any } = Object.assign({}, address);

      newAddress[key] = val;

      setAddress(newAddress as Address);
    },
    [address, setAddress],
  );

  /**
   * Handle input change
   */
  const handleInputChanged = useCallback(
    (e: TextBoxTypes.ValueChangedEvent) => {
      const target = e.component;
      const name = target.option('name');

      if (!name) {
        return;
      }

      updateAddressValue(name, e.value);
    },
    [updateAddressValue],
  );

  const handleCityChanged = useCallback(
    (e: AutocompleteTypes.ItemClickEvent) => {
      const cityData = e.itemData;
      const stateData = stateList?.find((s) => s.id === cityData.stateId);

      setAddress((previousAddress) => {
        return Object.assign({}, previousAddress, {
          city: cityData.description,
          state: stateData?.code,
        });
      });

      if (stateInputRef.current) {
        stateInputRef.current.instance.reset(stateData?.code);
      }
    },
    [stateList],
  );

  const handleSelectChanged = useCallback(
    (e: SelectBoxTypes.ValueChangedEvent) => {
      const target = e.component;
      const name = target.option('name');

      if (!name) {
        return;
      }

      updateAddressValue(name, e.value);
    },
    [updateAddressValue],
  );

  /**
   * Handle the save button click
   */
  const handleSave = useCallback(async () => {
    setButtonStatus('pending');

    const validation = validationGroupRef.current?.instance.validate();

    // Check the form values
    if (validation?.isValid) {
      const matches = await getUPSAddresses(
        address.street1,
        address.city,
        address.state,
        address.postalCode,
        'US',
      );

      openModal(
        <ModalAddressVerify
          original={address}
          matches={matches.slice(0, 1)}
          onComplete={props.onComplete}
        />,
        'Verify your address',
        ['modal__address-verify'],
      );
    }
  }, [address, openModal, props]);

  /**
   * Get the state list to populate the dropdown
   */
  useEffect(() => {
    const fetchStates = async () => {
      try {
        const states = await getStates();

        if (states) {
          setStateList(states);
        }
      } catch (error) {
        console.error('unable to fetch states');
      }
    };

    const fetchCities = async () => {
      try {
        const cities = await getCities();

        if (cities) {
          setCityList(cities);
        }
      } catch (error) {
        console.error('unable to fetch cities');
      }
    };
    fetchStates();
    fetchCities();
  }, []);

  return (
    <>
      <div className="modal__body" ref={bodyRef}>
        <ValidationGroup ref={validationGroupRef}>
          <div className="address-fields">
            <TextBox
              name="name"
              label="Company or Contact Name*"
              labelMode="outside"
              placeholder="Company"
              defaultValue={address?.name}
              onValueChanged={handleInputChanged}
              maxLength={50}
            >
              <Validator>
                <RequiredRule message="Name is required" />
                <StringLengthRule max={50} message="Maximum 50 characters" />
              </Validator>
            </TextBox>
            <TextBox
              name="street1"
              label="Address*"
              labelMode="outside"
              placeholder="1515 Elm Street"
              defaultValue={address?.street1}
              onValueChanged={handleInputChanged}
              maxLength={70}
            >
              <Validator>
                <RequiredRule message="Address is required" />
                <StringLengthRule max={70} message="Maximum 70 characters" />
              </Validator>
            </TextBox>
            <Autocomplete
              ref={cityInputRef}
              name="city"
              label="City*"
              labelMode="outside"
              placeholder="Austin"
              dataSource={filteredCityList}
              valueExpr="description"
              onItemClick={handleCityChanged}
              itemRender={renderCity}
              defaultValue={address.city}
              maxItemCount={100}
              dropDownOptions={{
                container: bodyRef.current || document.body,
              }}
              maxLength={40}
            >
              <Validator>
                <RequiredRule message="City is required" />
                <StringLengthRule max={40} message="Maximum 40 characters" />
              </Validator>
            </Autocomplete>

            <div className="flex gap-4">
              <SelectBox
                ref={stateInputRef}
                name="state"
                label="State*"
                labelMode="outside"
                dataSource={stateList}
                valueExpr="code"
                displayExpr="description"
                inputAttr={{ 'aria-label': 'State' }}
                className="w-2/3"
                defaultValue={address.state}
                onValueChanged={handleSelectChanged}
                dropDownOptions={{
                  container: bodyRef.current || document.body,
                }}
              >
                <Validator>
                  <RequiredRule message="State is required" />
                </Validator>
              </SelectBox>
              <TextBox
                name="postalCode"
                label="Zip*"
                labelMode="outside"
                placeholder="78750"
                defaultValue={address?.postalCode}
                onValueChanged={handleInputChanged}
                maxLength={5}
              >
                <Validator>
                  <RequiredRule message="Zip is required" />
                  <StringLengthRule max={5} message="Maximum 5 characters" />
                </Validator>
              </TextBox>
            </div>
          </div>
        </ValidationGroup>
      </div>
      <div className="modal__foot">
        <FancyButton
          text={saveButtonText}
          className="btn btn-primary"
          onClick={handleSave}
          status={buttonStatus}
          disabled={false}
        />
      </div>
    </>
  );
}
