
import './ModalAddressVerify.scss';
import { Button } from 'devextreme-react/button';
import { useModal } from '../../contexts/ModalProvider';
import { Address } from '../../types/customer';
import { useCallback, useState } from 'react';
import ModalEditAddress from './ModalEditAddress';
import FancyButton from '../../components/FancyButton/FancyButton';

interface UPSAddress {
  address: string;
  cityName: string;
  stateCode: string;
  zipCode: string;
}

interface ModalAddressVerifyProps {
  original: Address;
  matches: UPSAddress[];
  onComplete?: (_address: Address) => void;
}

export default function ModalAddressVerify({
  original,
  matches,
  onComplete,
}: ModalAddressVerifyProps) {
  const { openModal, closeModal } = useModal();

  const [buttonStatus, setButtonStatus] = useState<'pending' | 'complete' | ''>(
    '',
  );

  if (!matches) {
    if (onComplete) {
      onComplete(original);
    }

    closeModal();
  }

  const handleUseSuggested = useCallback(
    (address: UPSAddress) => {
      setButtonStatus('pending');

      if (onComplete) {
        onComplete(
          Object.assign({}, original, {
            street1: address.address,
            city: address.cityName,
            state: address.stateCode,
            postalCode: address.zipCode,
            isVerified: true,
          }),
        );

        closeModal();
      }
    },
    [original, onComplete, closeModal],
  );

  const handleTryAgain = useCallback(() => {
    openModal(<ModalEditAddress address={original} />, 'Add new address', [
      'modal__edit-address',
    ]);
  }, [openModal, original]);

  return (
    <>
      <div className="modal__body">
        <p>We were not able to verify your address, but found a close match.</p>

        <ul className="address_list">
          {matches.map((address, idx) => {
            return (
              <li key={`address=${idx}`} className="address_item">
                <address>
                  {address.address}
                  <br />
                  {address.cityName}, {address.stateCode} {address.zipCode}
                </address>
                <FancyButton
                  text={`Use Suggested`}
                  className="btn btn-primary"
                  status={buttonStatus}
                  disabled={false}
                  onClick={() => {
                    handleUseSuggested(address);
                  }}
                />
              </li>
            );
          })}
        </ul>

        <div className="address_try-again">
          Not correct?{' '}
          <Button className="btn btn-primary-link" onClick={handleTryAgain}>
            Try Again
          </Button>
        </div>
      </div>
    </>
  );
}
