
import { useCallback, useEffect, useState } from 'react';
import { useModal } from '../../contexts/ModalProvider';
import { useCart } from '../../contexts/CartProvider';
import { Product } from '../../types/products';
import { getRelatedProductsById } from '../../actions';
import { Button } from 'devextreme-react/button';
import CardRelatedProduct from '../../components/Card/CardRelatedProduct';
import Image from '../../components/Image/Image';
import './ModalAddedToCart.scss';
import { Link } from 'react-router-dom';

let USDollar = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
});

interface ModalAddedToCartProps {
  product: {
    id: number;
    title: string;
    image?: string;
    quantity: number;
    price: number;
  };
}

export default function ModalAddedToCart({ product }: ModalAddedToCartProps) {
  const { closeModal } = useModal();
  const { count, totals } = useCart();

  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);

  const { id, image, title, quantity, price } = product;

  useEffect(() => {
    (async () => {
      const data = await getRelatedProductsById(id);

      if (data) {
        setRelatedProducts(data);
      }
    })();
  }, [id]);

  const handleClose = useCallback(() => {
    closeModal();
  }, [closeModal]);

  return (
    <>
      <div className="modal__body">
        <div className="product">
          <figure className="product_image">
            {image && (
              <Image
                src={image}
                alt={title}
                width={72}
                height={72}
                loading="lazy"
              />
            )}
          </figure>
          <div className="product_details">
            <div className="product_details_name">
              <span>{title}</span>
            </div>
            <div className="product_details_quantity">
              <span>{quantity}</span>
            </div>
            <div className="product_details_price">
              <span>{USDollar.format(price)}</span>
            </div>
          </div>
        </div>

        {relatedProducts?.length > 0 && (
          <div className="related-products">
            <h3 className="related-products_title">
              Frequently Bought Together
            </h3>

            <ul>
              {relatedProducts.slice(0, 3).map((relatedProduct) => {
                return (
                  <li key={`related-${relatedProduct.id}`}>
                    <CardRelatedProduct {...relatedProduct} />
                  </li>
                );
              })}
            </ul>
          </div>
        )}

        <div className="product-totals">
          <h3>Your Cart ({count})</h3>
          <div>
            <p>Subtotal: {USDollar.format(totals.subtotal)}</p>
            <small>Weight: {totals.weight.toFixed(1)} lbs</small>
          </div>
        </div>
      </div>
      <div className="modal__foot">
        <Button className="btn btn-primary-outline" onClick={handleClose}>
          Continue Shopping
        </Button>
        <Link className="btn btn-primary" to="/cart/" onClick={handleClose}>
          View Cart
        </Link>
      </div>
    </>
  );
}
