
import './ModalDeliveryAddress.scss';
import { useModal } from '../../contexts/ModalProvider';
import { ChangeEvent, useCallback, useEffect, useState } from 'react';
import { getAllAddresses } from '../../actions';
import { Address } from '../../types/customer';
import { useCart } from '../../contexts/CartProvider';
import { Button } from 'devextreme-react';
import { Link } from 'react-router-dom';

export default function ModalDeliveryAddress() {
  const { closeModal } = useModal();
  const { cartAddress, setCartAddress } = useCart();
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [selectedAddress, setSelectedAddress] = useState<Address | undefined>(
    cartAddress,
  );

  const handleClose = useCallback(() => {
    closeModal();
  }, [closeModal]);

  const handleSelect = useCallback(
    (e: ChangeEvent) => {
      const target = e?.target as HTMLInputElement;

      if (target?.checked) {
        const selectedAddress = addresses.find(({ id }) => {
          return id === parseInt(target.value, 10);
        });

        if (selectedAddress) {
          setSelectedAddress(selectedAddress);
        }
      }
    },
    [addresses],
  );

  const handleSave = useCallback(() => {
    if (selectedAddress) {
      setCartAddress(selectedAddress);
    }

    closeModal();
  }, [selectedAddress, setCartAddress, closeModal]);

  useEffect(() => {
    const fetchData = async () => {
      const data = await getAllAddresses();

      if (data) {
        setAddresses(data);
      }
    };
    fetchData();
  }, []);

  return (
    <>
      <div className="modal__body">
        <ul className="modal__delivery-address_list">
          {addresses.map(
            ({ id, street1, street2, city, state, postalCode }) => {
              return (
                <li
                  key={`address-${id}`}
                  className="modal__delivery-address_option"
                >
                  <input
                    type="radio"
                    id={`address[${id}]`}
                    name="cart_address"
                    onChange={handleSelect}
                    defaultChecked={selectedAddress?.id === id}
                    value={id}
                  />
                  <label htmlFor={`address[${id}]`}>
                    <address>
                      {street1}
                      <br />
                      {street2 && (
                        <>
                          {street2}
                          <br />
                        </>
                      )}
                      {city}, {state} {postalCode}
                    </address>
                  </label>
                </li>
              );
            },
          )}
        </ul>
      </div>
      <div className="modal__foot">
        <Button className="btn btn-primary" onClick={handleSave}>
          Select Address
        </Button>
        <Link
          className="btn btn-secondary-outline"
          to="/account/addresses"
          onClick={handleClose}
        >
          <span className="dx-button-content">Manage Addresses</span>
        </Link>
      </div>
    </>
  );
}
