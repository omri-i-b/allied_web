
import './ModalTerms.scss';

export default function ModalTerms() {
  return (
    <>
      <div className="modal__body">
        <ul className="terms-list">
          <li>No returns after 30 days</li>
          <li>All returns will be charged at minimum a 25% restocking fee.</li>
          <li>
            All cancelled orders prior to shipment will be charged a 15%
            cancellation fee
          </li>
          <li>All returns require written notification</li>
          <li>All returns are subject to a quality inspection upon receipt</li>
          <li>Machined or modified items are non-cancellable</li>
          <li>Cut pipe is non-cancellable</li>
          <li>All pipe shipped in SRL length</li>
        </ul>
      </div>
      <div className="modal__foot"></div>
    </>
  );
}
