import './ModalActivateCart.scss';
import { Button } from 'devextreme-react/button';
import { useModal } from '../../contexts/ModalProvider';
import { useCallback } from 'react';

interface ModalActivateCartProps {
  onReplace: () => void;
}

export default function ModalActivateCart({
  onReplace,
}: ModalActivateCartProps) {
  const { closeModal } = useModal();

  const handleReplace = useCallback(() => {
    if (onReplace) {
      onReplace();
    }

    closeModal();
  }, [closeModal, onReplace]);

  const handleCancel = useCallback(() => {
    closeModal();
  }, [closeModal]);

  return (
    <>
      <div className="modal__body">
        <p>These items will be moved to your cart.</p>

        <p>
          This will remove all current items in your cart and add these items
          instead. (Note: This action cannot be undone.)
        </p>
      </div>
      <div className="modal__foot">
        <Button className="btn btn-outline-primary" onClick={handleCancel}>
          Cancel
        </Button>
        <Button className="btn btn-primary" onClick={handleReplace}>
          Replace Cart
        </Button>
      </div>
    </>
  );
}
