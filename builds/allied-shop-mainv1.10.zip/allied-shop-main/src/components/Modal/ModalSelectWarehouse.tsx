

import { ChangeEvent, memo, useCallback, useMemo, useState } from 'react';
import { useCart } from '../../contexts/CartProvider';
import { useModal } from '../../contexts/ModalProvider';
import Image from '../../components/Image/Image';
import { Button } from 'devextreme-react/button';
import { getHours, isWeekday } from '../../utils/convertToTime';
import { AvailableWarehouse, Product } from '../../types/products';
import {ReactComponent as IconInfo} from '../../assets/icons/info-fill.svg';
import {ReactComponent as IconCheck} from '../../assets/icons/check-fill.svg';

import './ModalSelectWarehouse.scss';

const shipDateFormat = new Intl.DateTimeFormat('en-US', {
  weekday: 'long',
});

export default memo(function ModalSelectWarehouse({
  product,
  selectedWarehouse,
  warehouses,
  onChange,
}: {
  product: Product;
  selectedWarehouse?: AvailableWarehouse;
  warehouses: AvailableWarehouse[];
  onChange: (_warehouse: AvailableWarehouse) => void;
}) {
  const { image, title, sku } = product;

  const { shippingCombination, hasShipping } = useCart();
  const { closeModal } = useModal();

  const [selected, setSelected] = useState<AvailableWarehouse | undefined>(
    selectedWarehouse,
  );

  const today = useMemo(() => new Date(), []);
  const currentHour = today.getHours();

  const shippingPickupHour = useMemo(() => {
    if (!shippingCombination || !hasShipping) {
      return;
    }

    return getHours(shippingCombination.shipViaCutOffTime) ?? 15;
  }, [shippingCombination, hasShipping]);

  const shippingPickupDay = useMemo(() => {
    const pickupDay = new Date(today);
    if (0 >= (shippingPickupHour as number) - currentHour || !isWeekday()) {
      var add;

      switch (today.getDay()) {
        case 6:
          add = 2;
          break;
        case 5:
          add = 3;
          break;
        default:
          add = 1;
          break;
      }

      // Return the next business day
      pickupDay.setDate(pickupDay.getDate() + add);
    }

    // Return today
    return pickupDay;
  }, [shippingPickupHour, today, currentHour]);

  const handleWarehouseChange = useCallback(
    (e: ChangeEvent) => {
      const target = e?.target as HTMLInputElement;
      const newWarehouse = warehouses.find(
        (w) => w.id === parseInt(target.value, 10),
      );

      if (newWarehouse) {
        setSelected(newWarehouse);
      }
    },
    [warehouses],
  );

  const handleSave = useCallback(() => {
    if (onChange && selected) {
      onChange(selected);
    }

    closeModal();
  }, [selected, onChange, closeModal]);

  return (
    <>
      <div className="modal__body modal__select-warehouse">
        <div className="product">
          <figure className="product_image">
            {image && (
              <Image
                src={image}
                alt={title}
                width={72}
                height={72}
                loading="lazy"
              />
            )}
          </figure>
          <div className="product_details">
            <div className="product_details_name">
              <span>{title}</span>
            </div>
            <div className="product_details_sku">
              <span>{sku}</span>
            </div>
          </div>
        </div>

        <p className="modal__select-warehouse_warning">
          <i className="icon icon-info" data-tooltip="Tooltip text here">
            <IconInfo />
          </i>{' '}
          Choose another warehouse for dates and availability. Availability varies by manufacturer.
        </p>

        {warehouses && (
          <>
            <h3 className="modal__select-warehouse_subtitle">
              Available in {warehouses.length} location(s)
            </h3>
            <ul className="modal__select-warehouse_warehouse-list">
              {warehouses.map(({ id, name }) => {
                return (
                  <li
                    key={`warehouse-${id}`}
                    className="modal__select-warehouse_warehouse-item"
                  >
                    <input
                      type="radio"
                      name="warehouse"
                      id={`warehouse-${id}`}
                      value={id}
                      defaultChecked={!!(id === selected?.id)}
                      onChange={handleWarehouseChange}
                    />
                    <label htmlFor={`warehouse-${id}`}>
                      <i className="icon icon-check">
                        <IconCheck />
                      </i>
                      <span>
                        {name}
                        {/* Removing the date after the location because we're showing WC and shipping the same, which isn't always the case */}
                        {/* {name} -{' '} */}
{/*                         <em>
                          available{' '}
                          {shippingPickupDay.getDate() === today.getDate()
                            ? `today`
                            : shipDateFormat.format(shippingPickupDay)}
                        </em> */}
                      </span>
                    </label>
                  </li>
                );
              })}
            </ul>
          </>
        )}
      </div>
      <div className="modal__foot">
        <Button className="btn btn-primary" onClick={handleSave}>
          Select Warehouse
        </Button>
      </div>
    </>
  );
});
