import './ModalDeleteCart.scss';
import { Button } from 'devextreme-react/button';
import { useModal } from '../../contexts/ModalProvider';
import { useCallback } from 'react';

interface ModalDeleteCartProps {
  onDelete: () => void;
}

export default function ModalDeleteCart({ onDelete }: ModalDeleteCartProps) {
  const { closeModal } = useModal();

  const handleCancel = useCallback(() => {
    closeModal();
  }, [closeModal]);

  const handleDelete = useCallback(() => {
    if (onDelete) {
      onDelete();
    }

    closeModal();
  }, [closeModal, onDelete]);

  return (
    <>
      <div className="modal__body">
        <p>
          Are you sure you want to delete this purchase list? Your items will
          not be saved.
        </p>
      </div>
      <div className="modal__foot">
        <Button className="btn btn-outline-primary" onClick={handleCancel}>
          Cancel
        </Button>
        <Button className="btn btn-primary" onClick={handleDelete}>
          Delete
        </Button>
      </div>
    </>
  );
}
