
import { ReactNode, useEffect, useRef } from 'react';
import './Modal.scss';
import {ReactComponent as IconClose} from '../../assets/icons/close.svg';

interface ModalProps {
  showModal: boolean;
  title?: string;
  component: ReactNode;
  isDrawer: boolean;
  extraClasses: string[];
  onCancel?: () => void;
}

export default function Modal({
  showModal,
  title,
  component,
  isDrawer,
  extraClasses,
  onCancel,
}: ModalProps) {
  let modalClasses = ['modal'];

  if (isDrawer) {
    modalClasses.push('drawer');
  }

  if (extraClasses) {
    modalClasses = modalClasses.concat(extraClasses);
  }

  const modalRef = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    if (modalRef.current) {
      if (showModal) {
        modalRef.current.showModal();
        document.body.classList.add('is-frozen');
      } else {
        modalRef.current.close();
        document.body.classList.remove('is-frozen');
      }
    }
  }, [showModal]);

  return (
    <dialog className={modalClasses.join(' ')} ref={modalRef}>
      <div className="modal__content">
        <div className="modal__head">
          <h2 className="modal__head_title">{title}</h2>
          {onCancel && (
            <button type="button" onClick={onCancel} title="cancel">
              <i className="icon icon-close">
                <IconClose />
              </i>
            </button>
          )}
        </div>
        {component}
      </div>
    </dialog>
  );
}
