import { useCallback, useEffect, useRef, useState } from 'react';
import { useModal } from '../../contexts/ModalProvider';
import { Button } from 'devextreme-react/button';
import { TextBox, TextBoxTypes } from 'devextreme-react/text-box';
import { ValidationGroup } from 'devextreme-react/validation-group';
import './ModalSaveCart.scss';

interface ModalSaveCartProps {
  value?: string;
  onSave: (_notes?: string) => void;
}

export default function ModalSaveCart({ value, onSave }: ModalSaveCartProps) {
  const { closeModal } = useModal();

  const [notes, setNotes] = useState(value);
  const validationGroupRef = useRef<ValidationGroup>(null);
  const nameRef = useRef<TextBox>(null);

  const handleNoteChanged = useCallback((e: TextBoxTypes.ValueChangedEvent) => {
    setNotes(e.value);
  }, []);

  const handleSave = useCallback(() => {
    const validation = validationGroupRef.current?.instance.validate();

    if (validation?.isValid) {
      if (onSave) {
        onSave(notes);
      }

      closeModal();
    }
  }, [closeModal, notes, onSave, validationGroupRef]);

  useEffect( () => {
    nameRef.current?.instance.focus();
  }, [nameRef]);

  return (
    <>
      <form className="modal__form" onSubmit={handleSave}>
        <div className="modal__body">
          <ValidationGroup ref={validationGroupRef}>
            <TextBox
              ref={nameRef}
              label="Name/Notes"
              labelMode="outside"
              defaultValue={notes}
              maxLength={50}
              onValueChanged={handleNoteChanged}
            ></TextBox>
          </ValidationGroup>
        </div>
        <div className="modal__foot">
          <Button className="btn btn-primary" useSubmitBehavior={true}>
            Save
          </Button>
        </div>
      </form>
    </>
  );
}
