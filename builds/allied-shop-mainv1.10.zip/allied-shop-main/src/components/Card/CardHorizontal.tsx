import { Link } from 'react-router-dom';
import './CardHorizontal.scss';
import Image from '../Image/Image';

interface CardHorizontalProps {
  image?: string;
  title: string;
  link?: string;
}

export default function CardHorizontal({
  image,
  title,
  link,
}: CardHorizontalProps) {
  return (
    <div className="card__horizontal">
      <figure className="card__horizontal_image">
        {image ? (
          <Image
            src={image}
            alt={title}
            width={150}
            height={150}
            loading="lazy"
          />
        ) : (
          <Image
            src="/images/placeholder.png"
            alt={title}
            width={150}
            height={150}
            loading="lazy"
          />
        )}
      </figure>
      <h3 className="card__horizontal_title">{title}</h3>
      {link && <Link to={link} className="card__horizontal_link"></Link>}
    </div>
  );
}
