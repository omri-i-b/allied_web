import { Product } from '../../types/products';
import Image from '../../components/Image/Image';
import './CardProduct.scss';
import { Link } from 'react-router-dom';

interface CardProductProps extends Product {}

export default function CardProduct({ image, title, slug }: CardProductProps) {
  
  return (
    <div className="card__product">
      <figure className="card__product_image">
        {image ? (
          <Image
            src={image}
            alt={title}
            width={150}
            height={150}
            loading="lazy"
          />
        ) : (
          <Image
            src="/images/placeholder.png"
            alt={title}
            width={150}
            height={150}
            loading="lazy"
          />
        )}
      </figure>
      <h3 className="card__product_title">{title}</h3>
      {slug && <Link to={slug} className="link-expand"></Link>}
    </div>
  );
}
