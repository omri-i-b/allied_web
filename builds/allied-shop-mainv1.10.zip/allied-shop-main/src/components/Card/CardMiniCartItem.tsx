import { CartItem } from '../../types/cart';
import Image from '../../components/Image/Image';
import './CardMiniCartItem.scss';

let USDollar = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
});

export default function CardMinitCartItem({
  name,
  image,
  quantity,
  price,
}: CartItem) {
  return (
    <div className="mini-cart-item">
      <figure className="mini-cart-item_image">
        {image ? (
          <Image src={image} alt={name} width={60} height={60} loading="lazy" />
        ) : (
          <Image
            src="/images/placeholder.png"
            alt={name}
            width={60}
            height={60}
            loading="lazy"
          />
        )}
      </figure>
      <div className="mini-cart-item_content">
        <h3 className="mini-cart-item_title">{name}</h3>
        <p className="mini-cart-item_quantity">
          Qty: <strong>{quantity}</strong>
        </p>
        <p className="mini-cart-item_price">
          Price: <strong>{USDollar.format(price)}</strong>
        </p>
      </div>
    </div>
  );
}
