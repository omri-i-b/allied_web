import { Product } from '../../types/products';
import './CardRelatedProduct.scss';
import Image from '../Image/Image';

export default function CardRelatedProduct({ title, image, slug }: Product) {
  return (
    <div className="card card__related-product">
      <figure className="card__related-product_image">
        {image ? (
          <Image
            src={image}
            alt={title}
            width={60}
            height={60}
            loading="lazy"
          />
        ) : (
          <Image
            src="/images/placeholder.png"
            alt={title}
            width={60}
            height={60}
            loading="lazy"
          />
        )}
      </figure>
      <h3 className="card__related-product_title"><a href={slug} className="link-expand">{title}</a></h3>
    </div>
  );
}
