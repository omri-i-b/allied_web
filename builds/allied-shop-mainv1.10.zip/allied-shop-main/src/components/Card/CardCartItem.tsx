
import { memo, useCallback, useMemo, useState } from 'react';
import { CartItem } from '../../types/cart';
import { useCart } from '../../contexts/CartProvider';
import { removeItemFromCart } from '../../actions';
import { getHours, isWeekday } from '../../utils/convertToTime';
import { Button } from 'devextreme-react/button';
import Image from '../../components/Image/Image';
import {ReactComponent as IconTrash} from '../../assets/icons/trash.svg';
import {ReactComponent as IconEdit} from '../../assets/icons/edit.svg';
import './CardCartItem.scss';
import { Link } from 'react-router-dom';

const USDollar = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
});

const shipDateFormat = new Intl.DateTimeFormat('en-US', {
  weekday: 'short',
  month: 'long',
  day: 'numeric',
});

type CartItemWithUndo = CartItem & { undo: boolean };

function isCartItemWithUndo(
  item: CartItem | CartItemWithUndo,
): item is CartItemWithUndo {
  return (item as CartItemWithUndo).undo !== undefined;
}

export interface CardCartItemProps {
  item: CartItem | CartItemWithUndo;
  deleteItemHandler?: (..._params: any[]) => void;
  undoItemHandler?: (..._params: any[]) => void;
  index?: number;
}

export default memo(function CardCartItem({
  item,
  deleteItemHandler,
  undoItemHandler,
  index,
}: CardCartItemProps) {
  const {
    cartId,
    image,
    slug,
    name,
    price,
    quantity,
    weight,
    manufacturerName,
    warehouseName,
    shipTermId,
    oldPrice,
  } = item;

  const undo = isCartItemWithUndo(item) ? item.undo : false;

  const {
    id,
    refreshCart,
    willCallTerm,
    shippingCombination,
    willCallCombination,
  } = useCart();
  

  const [isPending, setIsPending] = useState(false);

  const isWillCall = shipTermId === willCallTerm?.id;
  const currentHour = new Date().getHours();

  const cutOffHour = useMemo(() => {
    if (!shipTermId) {
      return;
    }

    // get combination based on shipTerm
    const combination = isWillCall ? willCallCombination : shippingCombination;

    if (!combination) {
      return;
    }

    return getHours(combination.shipViaCutOffTime) ?? 0;
  }, [shipTermId, isWillCall, shippingCombination, willCallCombination]);

  const pickupDay = useMemo(() => {
    const today = new Date();

    if (0 >= (cutOffHour as number) - currentHour || !isWeekday()) {
      var add;

      switch (today.getDay()) {
        case 6:
          add = 2;
          break;
        case 5:
          add = 3;
          break;
        default:
          add = 1;
          break;
      }

      // Return the next business day
      today.setDate(today.getDate() + add);
    }

    // Return today
    return today;
  }, [cutOffHour, currentHour]);

  const handleRemoveItem = useCallback(async () => {
    setIsPending(true);

    const response = await removeItemFromCart(cartId, id);
    if (response) {

      setTimeout(async () => {
        await refreshCart();
      }, 500);

      if (deleteItemHandler) {
        deleteItemHandler(item, index);
      }
    }
  }, [cartId, refreshCart, id, deleteItemHandler, item, index]);

  const handleUndoItem = useCallback(async () => {
    if (undoItemHandler) {
      undoItemHandler(item);
    }
  }, [item, undoItemHandler]);

  if (undo) {
    return (
      <div className={`card card__cart-item`}>
        <div className="card__cart-item_undo">
          <div>
            <Link className="item-name" to={slug}>
              {name}
            </Link>{' '}
            was removed from shopping cart.
          </div>
          <div className="card__cart-item_undo_actions">
            <Button
              className="btn-secondary-link btn-undo"
              onClick={handleUndoItem}
              icon="undo"
              text="Undo"
              rtlEnabled={true}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`card card__cart-item ${isPending ? 'is-pending' : ''}`}>
      <figure className="card__cart-item_image">
        {image ? (
          <Image
            src={image}
            alt={name}
            width={150}
            height={150}
            loading="lazy"
          />
        ) : (
          <Image
            src="/images/placeholder.png"
            alt={name}
            width={150}
            height={150}
            loading="lazy"
          />
        )}
      </figure>
      <div className="card__cart-item_details">
        <h3>
          <Link to={slug}>{name}</Link>
        </h3>

        <dl>
          {weight > 0 && (
            <div>
              <dt>Weight</dt>
              <dd>{weight}</dd>
            </div>
          )}
          {manufacturerName && (
            <div>
              <dt>Manufacturer</dt>
              <dd>{manufacturerName}</dd>
            </div>
          )}
        </dl>
      </div>
      <div className="card__cart-item_quantity">{quantity}</div>
      <div className="card__cart-item_price">
        {oldPrice ? (
          <span className="flex flex-col">
            <ins>{USDollar.format(price)}</ins>
            <del>{USDollar.format(oldPrice)}</del>
          </span>
        ) : (
          <>{USDollar.format(price)}</>
        )}
      </div>
      <div className="card__cart-item_actions">
        <button
          className="btn-secondary-link btn-trash"
          type="button"
          onClick={handleRemoveItem}
        >
          <span className="btn-label">Remove</span>
          <i className="icon icon-chevron">
            <IconTrash />
          </i>
        </button>
        <Link
          to={`${slug}?cartId=${cartId}`}
          className="btn-secondary-link btn-edit"
        >
          <span className="btn-label">Edit</span>
          <i className="icon icon-chevron">
            <IconEdit />
          </i>
        </Link>
      </div>
    </div>
  );
});
