import { OrderItem } from '../../types/customer';
import Image from '../../components/Image/Image';
import './CardOrderItem.scss';
import { Link } from 'react-router-dom';

const USDollar = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
});

export default function CardOrderItem({
  name,
  image,
  slug,
  manufacturer,
  quantity,
  weight,
  price,
}: OrderItem) {
  return (
    <div className={`card card__order-item`}>
      <figure className="card__order-item_image">
        {image ? (
          <Image
            src={image}
            alt={name}
            width={150}
            height={150}
            loading="lazy"
          />
        ) : (
          <Image
            src="/images/placeholder.png"
            alt={name}
            width={150}
            height={150}
            loading="lazy"
          />
        )}
      </figure>
      <div className="card__order-item_details">
        <h3>
          <Link to={slug}>{name}</Link>
        </h3>

        <dl>
          {!!weight && (
            <div>
              <dt>Weight</dt>
              <dd>{(weight || 0).toFixed(1)} lbs</dd>
            </div>
          )}
          {manufacturer && (
            <div>
              <dt>Manufacturer</dt>
              <dd>{manufacturer}</dd>
            </div>
          )}
          {quantity && (
            <div>
              <dt>Qty</dt>
              <dd>{quantity}</dd>
            </div>
          )}
          <div>
            <dt>Price</dt>
            <dd>{USDollar.format(price)}</dd>
          </div>
        </dl>
      </div>
    </div>
  );
}
