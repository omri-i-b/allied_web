import Image from '../Image/Image';
import './CardVertical.scss';
import { Link } from 'react-router-dom';

interface CardVerticalProps {
  image?: string;
  title: string;
  link?: string;
  isHomePage?: boolean;
}

export default function CardVertical({
  image,
  title,
  link,
  isHomePage
}: CardVerticalProps) {
  return (
    <div className={`card__vertical ${isHomePage ? 'card__vertical_home' : ''}`}>
      <figure className={`card__vertical_image ${isHomePage ? 'card__vertical_image-home' : ''}`}>
        {image ? (
          <Image
            src={image}
            alt={title}
            width={150}
            height={150}
            loading="lazy"
          />
        ) : (
          <Image
            src="/images/placeholder.png"
            alt={title}
            width={150}
            height={150}
            loading="lazy"
          />
        )}
      </figure>
      <h3 className="card__vertical_title">{title}</h3>
      {link && <Link to={link} className="card__vertical_link"></Link>}
    </div>
  );
}
