import { Product } from '../../types/products';
import Image from '../../components/Image/Image';
import {ReactComponent as IconChevronRight} from '../../assets/icons/chevron-right.svg';
import './CardSearchResult.scss';
import { Link } from 'react-router-dom';

export default function CardSearchResult({
  title,
  image,
  sku,
  material,
  pressure,
  size,
  schedule,
  slug,
}: Product) {
  return (
    <div className="card__search-result">
      <figure className="card__search-result_image">
        {image ? (
          <Image
            src={image}
            alt={title}
            width={150}
            height={150}
            loading="lazy"
          />
        ) : (
          <Image
            src="/images/placeholder.png"
            alt={title}
            width={150}
            height={150}
            loading="lazy"
          />
        )}
      </figure>
      <div className="card__search-result_details">
        <h3 className="card__search-result_title">{title}</h3>

        <dl className="card__search-result_features">
          {sku && (
            <div>
              <dt>Part #</dt>
              <dd>{sku}</dd>
            </div>
          )}
          {material && (
            <div>
              <dt>Material</dt>
              <dd>{material}</dd>
            </div>
          )}
          {pressure && (
            <div>
              <dt>Pressure</dt>
              <dd>{pressure}</dd>
            </div>
          )}
          {size && (
            <div>
              <dt>Size</dt>
              <dd>{size}</dd>
            </div>
          )}
          {schedule && (
            <div>
              <dt>Schedule</dt>
              <dd>{schedule}</dd>
            </div>
          )}
        </dl>
      </div>
      <button className="card__search-result_button" type="button">
        <IconChevronRight />
      </button>
      <Link to={slug} className="link-expand"></Link>
    </div>
  );
}
