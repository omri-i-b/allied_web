
import { Link, useLocation } from 'react-router-dom';
import './AccountNav.scss';


export default function AccountNav() {
  const location = useLocation();
  const pathname = location.pathname;

  return (
    <aside className="sidebar">
      <nav className="account-nav">
        <ul className="account-nav__menu">
          <li>
            <Link
              className={`account-nav__menu-item ${pathname === '/account' ? 'active' : ''}`}
              to="/account"
            >
              My Account
            </Link>
          </li>
          <li>
            <Link
              className={`account-nav__menu-item ${pathname === '/account/order-history' ? 'active' : ''}`}
              to="/account/order-history"
            >
              Order History
            </Link>
          </li>
          <li>
            <Link
              className={`account-nav__menu-item ${pathname === '/account/saved-carts' ? 'active' : ''}`}
              to="/account/saved-carts"
            >
              Saved Carts
            </Link>
          </li>
          <li>
            <Link
              className={`account-nav__menu-item ${pathname === '/account/addresses' ? 'active' : ''}`}
              to="/account/addresses"
            >
              Addresses
            </Link>
          </li>
        </ul>
      </nav>
    </aside>
  );
}
