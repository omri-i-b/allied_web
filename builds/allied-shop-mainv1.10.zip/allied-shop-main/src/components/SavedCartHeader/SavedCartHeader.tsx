
import { useCallback, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useModal } from '../../contexts/ModalProvider';
import { useCart } from '../../contexts/CartProvider';
import { useToast } from '../../contexts/ToastProvider';
import { Button } from 'devextreme-react/button';
import ModalDeleteCart from '../Modal/ModalDeleteCart';
import ModalActivateCart from '../Modal/ModalActivateCart';
import ModalSaveCart from '../Modal/ModalSaveCart';
import {
  deleteCart,
  removeItemFromCart,
  replaceCart,
  saveCart,
} from '../../actions';
import { Cart } from '../../types/cart';
import {ReactComponent as IconEdit} from '../../assets/icons/edit_large.svg';

import './SavedCartHeader.scss';

export default function SavedCartHeader({ cart }: { cart: Cart }) {
  const navigate = useNavigate();
  const { openModal } = useModal();
  const { createToast } = useToast();
  const { count, refreshCart, configuration } = useCart();

  const [cartState, setCartState] = useState(cart);

  /**
   * Delete the saved cart
   */
  const handleDelete = useCallback(async () => {
    const response = await deleteCart(cartState.id);

    if (!response) {
      return;
    }

    // Redirect to the cart page
    navigate('/account/saved-carts');
  }, [cartState.id, navigate]);

  /**
   * Replace the active cart with saved cart
   */
  const handleReplace = useCallback(async () => {
    const response = await replaceCart(cartState.id, cartState.notes);

    if (!response.success) {
      return;
    }

    // Refresh the cart context
    setTimeout(async () => {
      await refreshCart();

      // Redirect to the cart page
      navigate('/cart');
    }, 1000);
  }, [cartState, refreshCart, navigate]);

  /**
   * Validate the new cart before replacement
   */
  const handleValidate = useCallback(() => {
    if (!configuration) {
      return;
    }

    try {
      const estimatedTotal = cartState.items.reduce(
        (total, item) => total + item.price,
        0,
      );

      // If Cart is over the maximum then stop it from going any further
      if (
        configuration.maximumOrderAmount &&
        estimatedTotal > configuration.maximumOrderAmount
      ) {
        createToast(
          <>
            <strong>Cart Limit Reached:</strong> You have reached the maximum
            order limit for your order. Please contact your Allied
            representative for help with this cart.
          </>,
          'error',
        );
        throw new Error('Cart is over maximum amount');
      }

      // Check if each line item is within threshold
      cartState.items.forEach(async (item) => {
        const estimatedCost = item.price * item.quantity;

        if (
          configuration.maximumThresholdByLine &&
          estimatedCost > configuration.maximumThresholdByLine
        ) {
          await removeItemFromCart(item.cartId, cartState.id);

          createToast(
            <>
              <strong>Line Item Limit Reached:</strong> You have reached the
              maximum line item limit for {item.name} and has been removed from
              your cart.
              <Link to={item.slug}>Click Here</Link> add it again with a new
              quanitity.
            </>,
            'error',
          );
          throw new Error('Line item is over maximum threshold');
        }
      });
    } catch {
      return;
    }

    // Otherwise, lets replace it
    handleReplace();
  }, [
    cartState.id,
    cartState.items,
    configuration,
    createToast,
    handleReplace,
  ]);

  /**
   * Save the notes to the cart
   */
  const handleSaveCart = useCallback(
    async (notes?: string) => {
      await saveCart(cartState.id, notes);

      setCartState({ ...cartState, notes });
    },
    [cartState],
  );

  /**
   * Show the edit modal
   */
  const handleShowSavedCartModal = useCallback(() => {
    openModal(
      <ModalSaveCart value={cartState.notes} onSave={handleSaveCart} />,
      'Edit cart',
      ['modal__save-cart'],
    );
  }, [cartState.notes, openModal, handleSaveCart]);

  /**
   * Show the Delete Modal
   */
  const handleShowDeleteModal = useCallback(() => {
    openModal(
      <ModalDeleteCart onDelete={handleDelete} />,
      'Delete saved cart?',
      ['modal__delete-cart'],
    );
  }, [openModal, handleDelete]);

  /**
   * Show the Activate Modal
   */
  const handleShowActivateModal = useCallback(() => {
    if (!count) {
      handleValidate();
      return;
    }

    openModal(
      <ModalActivateCart onReplace={handleValidate} />,
      'Add to cart?',
      ['modal__activate-cart'],
    );
  }, [openModal, handleValidate, count]);

  return (
    <div className="saved-cart__details_header">
      <h1 className="saved-cart__details_title">
        {cartState.notes} <span>({cartState.count} items)</span>{' '}
        <button
          type="button"
          className="btn btn-icon"
          onClick={handleShowSavedCartModal}
        >
          <IconEdit />
        </button>
      </h1>

      <div className="saved-cart__details_actions">
        <Button
          className="btn btn-outline-primary"
          onClick={handleShowDeleteModal}
        >
          Delete
        </Button>
        <Button className="btn btn-primary" onClick={handleShowActivateModal}>
          Recall cart
        </Button>
      </div>
    </div>
  );
}
