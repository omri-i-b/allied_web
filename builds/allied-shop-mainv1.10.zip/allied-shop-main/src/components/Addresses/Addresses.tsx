
import DataGrid, {
  Column,
  Item,
  LoadPanel,
  Pager,
  Paging,
  SearchPanel,
  Toolbar,
  Selection,
} from 'devextreme-react/data-grid';
import { useCallback, useEffect, useState } from 'react';
import { Address } from '../../types/customer';
import { Button } from 'devextreme-react';
import { useModal } from '../../contexts/ModalProvider';
import { getAllAddresses, saveAddress } from '../../actions';
import './Addresses.scss';
import { useToast } from '../../contexts/ToastProvider';
import ModalEditAddress from '../Modal/ModalEditAddress';

interface AddressesProps {
  serverAddresses?: Address[];
  onSelectionChanged?: (..._params: any[]) => void;
  selectOnly?: boolean;
}

export default function Addresses({
  serverAddresses,
  onSelectionChanged,
  selectOnly = false,
}: AddressesProps) {
  const { openModal } = useModal();
  const { createToast } = useToast();

  const [addressList, setAddressList] = useState<Address[] | undefined>(
    serverAddresses,
  );

  useEffect(() => {
    if (serverAddresses) {
      setAddressList(serverAddresses);
    }
  }, [serverAddresses]);

  /**
   * Refresh the Address Data
   */
  const refreshAddressList = useCallback(async () => {
    const data = await getAllAddresses();

    if (data) {
      setAddressList(data);
    }
  }, [setAddressList]);

  /**
   * Save the New Address
   */
  const handleSaveAddress = useCallback(
    async (verifiedAddress: Address) => {
      const savedAddressId = await saveAddress(
        verifiedAddress.name,
        verifiedAddress.street1,
        verifiedAddress.street2 ?? '',
        verifiedAddress.city,
        verifiedAddress.state,
        verifiedAddress.postalCode,
        verifiedAddress.isVerified,
      );

      if (savedAddressId) {
        setTimeout(() => {
          refreshAddressList();
        }, 500);
      } else {
        createToast(<>There was a problem creating the address</>, 'error');
      }
    },
    [refreshAddressList, createToast],
  );

  /**
   * Add a new address
   */
  const handleShowAddNewAddressModal = useCallback(() => {
    openModal(
      <ModalEditAddress onComplete={handleSaveAddress} />,
      'Add new address',
      ['modal__edit-address'],
    );
  }, [openModal, handleSaveAddress]);

  const getAddress = (rowData: Address) => {
    const { name, street1, street2, city, state, postalCode } = rowData;
    const street = [street1, street2].filter(Boolean).join(', ');

    return `${name}, ${street}, ${city}, ${state} ${postalCode}`;
  };

  if (selectOnly) {
    // We hide columns here to able to search for them
    return (
      <div className="addresses selectable">
        <DataGrid
          showBorders={true}
          dataSource={addressList}
          onSelectionChanged={onSelectionChanged}
          showColumnLines={false}
        >
          <Selection mode="single" />
          <SearchPanel visible={true} placeholder="Search" />
          <Column
            dataField="name"
            caption="Company Name"
            dataType="string"
            visible={false}
          />
          <Column
            dataField="street1"
            caption="Address"
            dataType="string"
            visible={false}
          />
          <Column dataField="city" dataType="string" visible={false} />
          <Column dataField="state" dataType="string" visible={false} />
          <Column
            dataField="postalCode"
            caption="Zip"
            dataType="string"
            visible={false}
          />
          <Column dataField="Address" calculateDisplayValue={getAddress} />
          <LoadPanel enabled />
          <Paging defaultPageSize={6} />
          <Pager
            visible={true}
            displayMode="compact"
            showPageSizeSelector={true}
            showInfo={true}
            infoText={'Page {0} of {1} ({2} results)'}
          />
        </DataGrid>
      </div>
    );
  }

  return (
    <div className="addresses">
      <DataGrid
        showBorders={true}
        dataSource={addressList}
        onSelectionChanged={onSelectionChanged}
        showColumnLines={false}
      >
        <SearchPanel visible={true} placeholder="Search" />
        <Column dataField="name" caption="Company Name" dataType="string" />
        <Column dataField="street1" caption="Address" dataType="string" />
        <Column dataField="city" dataType="string" />
        <Column dataField="state" dataType="string" />
        <Column dataField="postalCode" caption="Zip" dataType="string" />
        <LoadPanel enabled />
        <Toolbar>
          <Item location="before" name="searchPanel" />
          <Item location="after">
            <Button
              className="btn btn-primary"
              onClick={handleShowAddNewAddressModal}
            >
              Add new Address
            </Button>
          </Item>
        </Toolbar>
        <Paging defaultPageSize={12} />
        <Pager
          visible={true}
          allowedPageSizes={[12, 24, 50, 100]}
          displayMode="compact"
          showPageSizeSelector={true}
          showInfo={true}
          infoText={'Page {0} of {1} ({2} results)'}
        />
      </DataGrid>
    </div>
  );
}
