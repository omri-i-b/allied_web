
import './Filters.scss';
import { ChangeEvent, useCallback, useEffect, useState } from 'react';
import {ReactComponent as IconChevronDown} from '../../assets/icons/chevron-down.svg';
import {ReactComponent as IconCheck} from '../../assets/icons/check.svg';
import { FilterGroupType, FiltersType } from '../../types/categories';
import { useSearchParams } from 'react-router-dom';

function FilterGroup({ filterGroup, filters, setFilters }:{ filterGroup: FilterGroupType; filters:FiltersType; setFilters: (_filters:FiltersType) => void; }) { 
  const [searchParams, setSearchParams] = useSearchParams();

  const [expanded, setExpanded] = useState(true);

  // Toggle the group
  const handleClick = useCallback(() => {
    setExpanded(!expanded);
  }, [expanded, setExpanded]);

  // Update the search params
  const updateSearchParams = useCallback(
    (key: string, val: string) => {

      if (val) {
        searchParams.set(key, val);
      } else {
        searchParams.delete(key);
      }

      setSearchParams(searchParams);
    },
    [searchParams, setSearchParams],
  );
  
  // When a filter is toggled
  const handleFilterChange = useCallback(
    (e: ChangeEvent, id: number) => {
      const target = e.target as HTMLInputElement;
      const newFilters: { [key: string]: number[] } = Object.assign(
        {},
        filters,
      );

      if (!newFilters) {
        return;
      }

      // Is checked, add to the array
      if (target.value && !newFilters[filterGroup.slug].includes(id)) {
        newFilters[filterGroup.slug].push(id);
      } else {
        let idx = newFilters[filterGroup.slug].indexOf(id);
        newFilters[filterGroup.slug].splice(idx, 1);
      }

      setFilters(newFilters as FiltersType);
    },
    [filterGroup, filters, setFilters],
  );

  useEffect(() => {
    updateSearchParams('filters', JSON.stringify(filters));
  }, [filters, updateSearchParams]);

  return (
    <div className="filter-container">
      <dl
        className={`filter-group filter-group_${filterGroup.slug}`}
        aria-expanded={expanded}
      >
        <dt className="filter-group__header">
          <button type="button" onClick={handleClick}>
            <span>{filterGroup.title}</span>
            <i className="icon icon-chevron">
              <IconChevronDown />
            </i>
          </button>
        </dt>
        <dd className="filter-group__content">
          <div className="filters">
            <ul className="filters__list">
              {filterGroup.filters
                .map(({ id, name }) => {
                  const isChecked =
                    (filters as { [key: string]: number[] })[
                      filterGroup.slug
                    ].indexOf(id) > -1;

                  return (
                    <li key={`filter-${id}`} className={`filters__item`}>
                      <input
                        type="checkbox"
                        name={`${filterGroup.slug}[${id}]`}
                        id={`${filterGroup.slug}[${id}]`}
                        checked={isChecked}
                        onChange={(e) => {
                          handleFilterChange(e, id);
                        }}
                      />
                      <label htmlFor={`${filterGroup.slug}[${id}]`}>
                        <span className="checkbox">
                          <i className="icon icon-check">
                            <IconCheck />
                          </i>
                        </span>
                        <span>
                          {name}
                          {/* {name} <ins>({count})</ins> */}
                        </span>
                      </label>
                    </li>
                  );
                })}
            </ul>
          </div>
        </dd>
      </dl>
    </div>
  );
}

export default function Filters({
  filterGroups,
  filters,
  setFilters
}: {
  filterGroups: FilterGroupType[];
  filters: FiltersType;
  setFilters: (_filters:FiltersType) => void;
}) {
  return (
    <aside className="sidebar__filters">
      {filterGroups.map((filterGroup) => {
        const hasFilters = filterGroup.filters.length > 0;
        return (
          <div key={filterGroup.title}>
            {hasFilters && <FilterGroup filterGroup={filterGroup} filters={filters} setFilters={setFilters} />}
          </div>
        );
      })}
    </aside>
  );
}
