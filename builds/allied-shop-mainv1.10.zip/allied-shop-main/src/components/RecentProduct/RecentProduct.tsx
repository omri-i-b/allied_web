

import { getRecentProducts } from '../../actions';
import { memo, useEffect, useState } from 'react';
import ProductCarousel from '../ProductCarousel/ProductCarousel';

export default memo(function RecentProduct() {
  const [recent, setRecent] = useState<any>();

  useEffect(() => {

    const fetchData = async () => {
      const recentPromise = await getRecentProducts();
      recentPromise && setRecent(recentPromise)
      
    }
    fetchData();
  }, [])

  return recent && (
    <section className="cart__recently-viewed">
      <div className="container">
        <h2 className="cart__recently-viewed_title">Recently Viewed</h2>

        <ProductCarousel products={recent} />
      </div>
    </section>
  )
});
