
import { memo, useCallback, useMemo, useState } from 'react';
import { useModal } from '../../contexts/ModalProvider';
import { useCart } from '../../contexts/CartProvider';
import { saveCart } from '../../actions';
import { Button } from 'devextreme-react/button';
import { CheckBox, CheckBoxTypes } from 'devextreme-react/check-box';
import ModalTerms from '../../components/Modal/ModalTerms';
import ModalSaveCart from '../../components/Modal/ModalSaveCart';
import FancyButton from '../../components/FancyButton/FancyButton';
import {ReactComponent as IconChevronDown} from '../../assets/icons/chevron-down.svg';
import './OrderSummary.scss';
import CardMinitCartItem from '../Card/CardMiniCartItem';
import { useNavigate } from 'react-router-dom';

interface OrderSummaryProps {
  isConfirmation?: boolean;
  isCheckout?: boolean;
  isReady?: boolean;
  buttonStatus?: 'pending' | 'complete' | '';
  onCheckout?: () => void;
}

let USDollar = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
});

export default memo(function OrderSummary({
  isConfirmation = false,
  isCheckout = false,
  isReady = true,
  buttonStatus = '',
  onCheckout,
}: OrderSummaryProps) {
  const { configuration, id, count, items, totals, resetCart, isValid } =
    useCart();
  const { openModal } = useModal();
  const navigate = useNavigate();

  const initialDiscount = useMemo(() => {
    var codes = [];

    if (configuration?.flatDiscount) {
      codes.push({
        code: `Allied${configuration.flatDiscount}`,
        type: 'percent',
        amount: configuration.flatDiscount,
      });
    }
    return codes;
  }, [configuration?.flatDiscount]);

  const [discounts] = useState(initialDiscount);
  //const [showDiscount, setShowDiscount] = useState(false); // removed to remove discount code section
  const [showCartItems, setShowCartItems] = useState(false);
  const [termsAgree, setTermsAgree] = useState(true);

  const hasDiscount = !!discounts.length;

  /* removing discount code section

const handleToggleDiscount = useCallback(() => {
    setShowDiscount(!showDiscount);
  }, [showDiscount]); */

  const handleToggleCartItems = useCallback(() => {
    setShowCartItems(!showCartItems);
  }, [showCartItems]);

  /**
   * Show the terms modal
   */
  const handleShowTermsModal = useCallback(() => {
    openModal(<ModalTerms />, 'Terms and Conditions', ['modal__terms']);
  }, [openModal]);

  /**
   * Update the terms agree
   */
  const handleTermsAgree = useCallback((e: CheckBoxTypes.ValueChangedEvent) => {
    setTermsAgree(e.value);
  }, []);

  /**
   * Save the cart
   */
  const handleSaveCart = useCallback(
    async (notes?: string) => {
      const save = await saveCart(id, notes);

      if (save) {
        await resetCart();

        navigate('/');
      }
    },
    [id, navigate, resetCart],
  );

  /**
   * Show Save Cart Modal
   */
  const handleShowSaveCartModal = useCallback(() => {
    openModal(<ModalSaveCart onSave={handleSaveCart} />, 'Save cart', [
      'modal__save-cart',
    ]);
  }, [handleSaveCart, openModal]);

  /**
   * Go to checkout
   */
  const handleGoToCheckout = useCallback(() => {
    navigate('/checkout');
  }, [navigate]);

  /**
   * Checkout the cart
   */
  const handleCheckout = useCallback(() => {
    if (onCheckout) {
      onCheckout();
    }
  }, [onCheckout]);

  return (
    <div
      className="order-summary"
      data-discount={hasDiscount ? 'true' : 'false'}
    >
      <h2 className="order-summary_title">Order Summary</h2>

      <dl className="order-summary_totals">
        <div>
          <dt>Subtotal</dt>
          <dd>{USDollar.format(totals.subtotal)}</dd>
        </div>
        <div>
          <dt>Estimated Tax</dt>
          <dd>{USDollar.format(totals.tax)}</dd>
        </div>
        {!!totals.discount && (
          <div className="discount-amount">
            <dt>Discount</dt>
            <dd>{USDollar.format(totals.discount)}</dd>
          </div>
        )}
        <div>
          <dt>Estimated Weight</dt>
          <dd>{totals.weight.toFixed(1)} lbs</dd>
        </div>
        <div>
          <dt>Total</dt>
          <dd>{USDollar.format(totals.total)}</dd>
        </div>
      </dl>

      {/* !isConfirmation && (
        <dl
          className="order-summary_discount-code accordion"
          aria-expanded={showDiscount}
          role="tab"
        >
          <dt>
            <button type="button" onClick={handleToggleDiscount}>
              Add Discount Code{' '}
              <i className="icon icon-chevron-down">
                <IconChevronDown />
              </i>
            </button>
          </dt>
          <dd>
            <div className="accordion-content">
              <TextBox name="discount_code" labelMode="hidden" />

              {discounts && (
                <ul className="tag__list">
                  {discounts.map(({ code }) => {
                    return (
                      <li key={`discount-${code}`}>
                        <span className="tag">
                          {code}
                          <button type="button">
                            <i className="icon icon-close">
                              <IconClose />
                            </i>
                          </button>
                        </span>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </dd>
        </dl>
      ) */}

      {isCheckout && (
        <dl
          className="order-summary_cart-items accordion"
          aria-expanded={showCartItems}
          role="tab"
        >
          <dt>
            <button type="button" onClick={handleToggleCartItems}>
              <span>Cart ({count} Items)</span>{' '}
              <i className="icon icon-chevron-down">
                <IconChevronDown />
              </i>
            </button>
          </dt>
          <dd>
            <div className="accordion-content">
              {!!count && (
                <ul>
                  {items.map((item) => {
                    return (
                      <li key={`mini-cart-item-${item.cartId}`}>
                        <CardMinitCartItem {...item} />
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </dd>
        </dl>
      )}

      {isCheckout && (
        <div className="order-summary_terms">
          <CheckBox
            name="terms_agree"
            iconSize={14}
            onValueChanged={handleTermsAgree}
            defaultValue={termsAgree}
            disabled={!isReady}
          />
          <label>
            I agree to the Allied Group{' '}
            <button
              type="button"
              className="btn btn-secondary-link"
              onClick={handleShowTermsModal}
            >
              Terms and Conditions
            </button>
            .
          </label>
        </div>
      )}

      {!isConfirmation && (
        <div className="order-summary_actions">
          {isCheckout ? (
            <>
              <FancyButton
                text="Complete Purchase"
                className="btn-primary"
                status={buttonStatus}
                onClick={handleCheckout}
                disabled={!isReady || !termsAgree}
              />
            </>
          ) : (
            <>
              <Button
                className="btn btn-primary"
                onClick={handleGoToCheckout}
                disabled={!isValid}
              >
                Go to checkout
              </Button>
              <Button
                className="btn btn-primary-outline"
                onClick={handleShowSaveCartModal}
                disabled={!isValid}
              >
                Save cart
              </Button>
            </>
          )}
        </div>
      )}
    </div>
  );
});
