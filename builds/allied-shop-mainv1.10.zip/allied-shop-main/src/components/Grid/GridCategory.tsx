
import { useEffect, useState } from 'react';
import { getAllCategories } from '../../actions';
import { Category } from '../../types/categories';
import CardVertical from '../../components/Card/CardVertical';
import './GridCategory.scss';

export default function GridCategory() {
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    (async () => {
      const data = await getAllCategories();
      if (data) {
        setCategories(data);
      }
    })();
  }, []);

  return (
    <ul className="grid grid-category">
      {categories.map((category) => {
        return (
          <li
            key={`category-grid-item-${category.slug}`}
            className="category-grid__grid_item"
          >
            <CardVertical
              image={category.image}
              title={category.title}
              link={`/products/${category.slug}`}
            />
          </li>
        );
      })}
    </ul>
  );
}
