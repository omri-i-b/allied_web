
import { CartItem } from '../../types/cart';
import './ChipShipment.scss';
import { useMemo, useRef, useState } from 'react';

interface ChipShipmentProps {
  items: CartItem[];
}

export default function ChipShipment({ items }: ChipShipmentProps) {
  const MAX_DISPLAY = 3;

  const [showDetails, setShowDetails] = useState(false);

  const chipRef = useRef<HTMLDivElement>(null);

  const displayItems = useMemo(() => {
    let shortList = items.map((i) => i.name).slice(0, MAX_DISPLAY);

    if (items.length > MAX_DISPLAY) {
      shortList.push(`...${items.length - MAX_DISPLAY} more`);
    }

    return shortList;
  }, [items]);

  const handleShowDetails = () => {
    setShowDetails(true);
  };

  const handleHideDetails = () => {
    setShowDetails(false);
  };

  return (
    <div
      className="chip-shipment"
      ref={chipRef}
      onMouseOver={handleShowDetails}
      onMouseOut={handleHideDetails}
    >
      {items.length} Items
      {showDetails && (
        <ul className="chip-shipment_details">
          {displayItems.map((item, idx) => {
            return <li key={`chip-shipment_details-${idx}-${item}`}>{item}</li>;
          })}
        </ul>
      )}
    </div>
  );
}
