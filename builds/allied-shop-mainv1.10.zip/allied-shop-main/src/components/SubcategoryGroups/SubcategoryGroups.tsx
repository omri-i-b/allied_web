
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Subcategory, FilterGroupType, FiltersType, FilterType } from '../../types/categories';
import { SelectBox, SelectBoxTypes } from 'devextreme-react/select-box';
import DataGrid, {
  Column,
  DataGridTypes,
  Grouping,
  LoadPanel,
  MasterDetail,
  Pager,
  Paging,
} from 'devextreme-react/data-grid';
import ProductDrawer from '../../components/ProductDrawer/ProductDrawer';
import Image from '../../components/Image/Image';
import {ReactComponent as IconClose} from '../../assets/icons/close.svg';
import './SubcategoryGroups.scss';
import { Product } from '../../types/products';

export function SubcategoryGroups({
  subcategory,
  filterGroups,
  groupBy,
  filters,
  results,
  setGroupBy,
  setFilters,
}: {
  subcategory: Subcategory;
  filterGroups: FilterGroupType[];
  groupBy: string;
  filters: FiltersType;
  results: {
    total: number;
    products: Product[];
  };
  setGroupBy: (_groupBy:string) => void;
  setFilters: (_filters:FiltersType) => void;
}) {
  const [addedFilters, setAddedFilters] = useState<FilterGroupType[]>([]);

  const groupListRef = useRef<DataGrid>(null);

  const onContentReady = (e: DataGridTypes.ContentReadyEvent) => {
    if (!e.component.getSelectedRowKeys().length) {
      e.component.selectRowsByIndexes([0]);
    }
  };

  const onSelectionChanged = (e: DataGridTypes.RowClickEvent) => {
    const isExpanded = e.handled ? !e.isExpanded : e.isExpanded;

    if ("group" === e.rowType) {
      return
    }

    if (isExpanded) {
      e.component.collapseRow(e.key);
    } else {
      e.component.expandRow(e.key);
    }
  };

  useEffect(() => {
    // populate names of filters based on ids on the filters array matching in filterGroups
    const result: FilterGroupType[] = filterGroups
      .map((option) => {
        const filterValues = filters[option.slug as keyof FiltersType];
        if (filterValues && filterValues.length > 0) {
          return {
            ...option,
            filters: option.filters.filter((f) => filterValues.includes(f.id)),
          };
        }
        return null;
      })
      .filter((option): option is FilterGroupType => option !== null);
    
    setAddedFilters(result);
  }, [filters, filterGroups]);

  // Create the Dropdown options
  const groupByOptions = useMemo(() => {
    var groups = [];

    const hasSize = results.products.filter((p) => !!p.size);
    const hasPressure = results.products.filter((p) => !!p.pressure);
    const hasMaterial = results.products.filter((p) => !!p.material);
    const hasSchedule = results.products.filter((p) => !!p.schedule);
    const hasGrade = results.products.filter((p) => !!p.grade);

    if (hasSize.length) {
      groups.push({
        name: 'Size (inch)',
        value: 'size',
      });
    }

    if (hasPressure.length) {
      groups.push({
        name: 'Pressure',
        value: 'pressure',
      });
    }

    if (hasMaterial.length) {
      groups.push({
        name: 'Material',
        value: 'material',
      });
    }

    if (hasSchedule.length) {
      groups.push({
        name: 'Schedule',
        value: 'schedule',
      });
    }

    if (hasGrade.length) {
      groups.push({
        name: 'Grade',
        value: 'grade',
      });
    }

    return groups;
  }, [results]);


  const removeFilter = (filter: FilterType, slug: string) => {
    const newFilters: { [key: string]: number[] } = Object.assign({}, filters);
    newFilters[slug] = newFilters[slug].filter((id) => filter.id !== id);

    setFilters(newFilters as FiltersType);
  };

  const removeAllFilters = () => {
    const newFilters: { [key: string]: number[] } = {
      categories: [...filters.categories],
      sizes: [],
      schedules: [],
      grades: [],
      pressures: [],
      shapes: [...filters.shapes],
    };

    setFilters(newFilters as FiltersType);

    if (groupListRef.current) {
      groupListRef.current.instance.collapseAll(-1);
    }
  };

  // Update grouBy on select
  const handleGroupByChange = useCallback(
    (e: SelectBoxTypes.ValueChangedEvent) => {
      if (groupBy !== e.value) {
        setGroupBy(e.value);
      }
    },
    [groupBy, setGroupBy],
  );

  // The header cell
  const GroupCell = (options: {
    value: string;
    column: { caption: string };
  }) => {
    return (
      <div className="group-header">
        {options.value ? `${options.value} ${options.column.caption}` : 'N/A'}
      </div>
    );
  };

  // Filter chips
  const Chip = ({ filter, slug }: { filter: FilterType; slug: string }) => {
    return (
      <div className="page__subcategory_chip">
        {filter.name}
        <button
          type="button"
          onClick={() => removeFilter(filter, slug)}
          title="remove"
        >
          <i className="icon icon-close">
            <IconClose />
          </i>
        </button>
      </div>
    );
  };

  return (
    <>
      <div className="page__subcategory_header">
        <div className="page__subcategory_header_row">
          <div className="subcategory__groups_main">
            <h1 className="page__subcategory_title">{subcategory.title}</h1>
            <p className="page__subcategory_product-total">
              {new Intl.NumberFormat().format(results.total)} products
            </p>
            <div className="page__subcategory_chip_container">
              <>
                {addedFilters.flatMap(({ filters, slug }) =>
                  filters.map((filter) => (
                    <Chip key={filter.id} filter={filter} slug={slug} />
                  )),
                )}
                {addedFilters.length > 0 && (
                  <div
                    className="page__subcategory_chip_clear"
                    onClick={removeAllFilters}
                  >
                    Clear All
                    <button type="button" title="remove">
                      <i className="icon icon-close">
                        <IconClose />
                      </i>
                    </button>
                  </div>
                )}
              </>
            </div>
          </div>
          <div className="subcategory__groups_sort">
            <SelectBox
              name="groupBy"
              label="Group By:"
              labelMode="outside"
              items={groupByOptions}
              displayExpr="name"
              valueExpr="value"
              placeholder="Group By:"
              stylingMode="filled"
              inputAttr={{ 'aria-label': 'Group By' }}
              defaultValue={groupBy}
              onValueChanged={handleGroupByChange}
            />
          </div>
        </div>
        {subcategory.image && (
          <figure className="page__subcategory_image">
            <Image
              src={subcategory.image}
              alt={subcategory.title}
              width={150}
              height={150}
              loading="lazy"
            />
          </figure>
        )}
      </div>
      <div className="subcategory__groups">
        <dl className="subcategory__group">
          <dd className="subcategory__group_list">
            <DataGrid
              ref={groupListRef}
              dataSource={results.products}
              showBorders={false}
              id="grid-container"
              keyExpr="sku"
              onRowClick={onSelectionChanged}
              onContentReady={onContentReady}
              rowAlternationEnabled={true}
            >
              <Column
                dataField="title"
                caption="Description"
                allowSorting
                sortIndex={0}
                sortOrder="asc"
              />
              <Column
                dataField="size"
                groupIndex={'size' === groupBy ? 0 : -1}
                showWhenGrouped={true}
                groupCellRender={GroupCell}
                visible={!!groupByOptions.find((g) => 'size' === g.value)}
                width={'auto'}
                allowSorting
              />
              <Column
                dataField="pressure"
                groupIndex={'pressure' === groupBy ? 0 : -1}
                showWhenGrouped={true}
                groupCellRender={GroupCell}
                visible={!!groupByOptions.find((g) => 'pressure' === g.value)}
                width={'auto'}
                allowSorting
              />
              <Column
                dataField="grade"
                groupIndex={'grade' === groupBy ? 0 : -1}
                showWhenGrouped={true}
                groupCellRender={GroupCell}
                visible={!!groupByOptions.find((g) => 'grade' === g.value)}
                width={'auto'}
                allowSorting
              />
              <Column
                dataField="material"
                groupIndex={'material' === groupBy ? 0 : -1}
                showWhenGrouped={true}
                groupCellRender={GroupCell}
                visible={false}
                width={'auto'}
                allowSorting
              />
              <Column
                dataField="schedule"
                groupIndex={'schedule' === groupBy ? 0 : -1}
                showWhenGrouped={true}
                groupCellRender={GroupCell}
                visible={!!groupByOptions.find((g) => 'schedule' === g.value)}
                width={'auto'}
                allowSorting
              />
              <Column
                dataField=""
                groupIndex={-1}
                showWhenGrouped={true}
                groupCellRender={() => {
                  return <div className="overflow-visible"></div>;
                }}
                visible={true}
                width={35}
                allowSorting={false}
              />
              <MasterDetail enabled={true} component={ProductDrawer} />
              <LoadPanel enabled />
              <Grouping
                autoExpandAll={true}
                allowCollapsing={false}
                expandMode="buttonClick"
              />
              <Paging defaultPageSize={100} />
              <Pager
                visible={true}
                allowedPageSizes={[100, 250, 500]}
                displayMode="compact"
                showPageSizeSelector={true}
                showInfo={true}
              />
            </DataGrid>
          </dd>
        </dl>
      </div>
    </>
  );
}
