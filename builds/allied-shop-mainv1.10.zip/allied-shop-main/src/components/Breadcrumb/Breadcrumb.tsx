
import { Link } from 'react-router-dom';
import './Breadcrumb.scss';

interface BreadcrumbProps {
  list?: {
    title: string;
    path?: string;
  }[];
}

export default function Breadcrumb({ list }: BreadcrumbProps) {
  return (
    <nav className="breadcrumb">
      <div className="container">
        {list && (
          <ul className="breadcrumb__list">
            {list.map(({ title, path }) => {
              return (
                <li key={title}>
                  {path && <Link to={path}>{title}</Link>}
                  {!path && <span>{title}</span>}
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </nav>
  );
}
