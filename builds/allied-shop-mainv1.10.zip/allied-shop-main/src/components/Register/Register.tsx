
import './Register.scss';
import { useState, useCallback, useEffect, useRef } from 'react';
import { ValidationGroup } from 'devextreme-react/validation-group';
import { Validator, RequiredRule, EmailRule } from 'devextreme-react/validator';
import { TextBox } from 'devextreme-react/text-box';
import { SelectBox } from 'devextreme-react/select-box';
import { Button } from 'devextreme-react/button';
import { register } from '../../actions';
import { ReactComponent as IconArrowLeft } from '../../assets/icons/arrow-left.svg'
import { ReactComponent as IconCheck } from '../../assets/icons/check-circle.svg';
import { STATES } from '../../constants';
import { Link } from 'react-router-dom';
import { Controller, useForm } from 'react-hook-form';


type Booleanish = boolean | 'true' | 'false';

interface StepProps {
  active: Booleanish;
  control: any;
  pending?: boolean;
  onComplete?: () => void;
  onCancel?: () => void;
}

function PersonalDetails({ active, control, onComplete }: StepProps) {
  const validationGroupRef = useRef<ValidationGroup>(null);

  const rules = { X: /[0-9]/ };

  const handleSubmit = () => {
    const validation = validationGroupRef.current?.instance.validate();

    // Check the form values
    if (validation?.isValid && onComplete) {
      onComplete();
    }
  };

  function FirstNameFiled({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }
    return <TextBox
      name="first_name"
      label="First Name"
      labelMode="outside"
      inputAttr={{ 'aria-label': 'First Name' }}
      placeholder="Filip"
      onValueChanged={fieldValueChange}
      value={field.value}
      maxLength={35}
    >
      <Validator>
        <RequiredRule message="First name is required" />
      </Validator>
    </TextBox>
  }

  function LastNameFiled({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }
    return <TextBox
      name="last_name"
      label="Last Name"
      labelMode="outside"
      inputAttr={{ 'aria-label': 'Last Name' }}
      placeholder="Smith"
      onValueChanged={fieldValueChange}
      value={field.value}
      maxLength={35}
    >
      <Validator>
        <RequiredRule message="Last name is required" />
      </Validator>
    </TextBox>
  }

  function CompanyNameFiled({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }
    return <TextBox
      name="company_name"
      label="Company Name"
      labelMode="outside"
      inputAttr={{ 'aria-label': 'Company Name' }}
      placeholder="Allied Group"
      onValueChanged={fieldValueChange}
      value={field.value}
      maxLength={50}
    >
      <Validator>
        <RequiredRule message="Company name is required" />
      </Validator>
    </TextBox>
  }

  function TitleField({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }
    return <TextBox
      name="title"
      label="Title"
      labelMode="outside"
      inputAttr={{ 'aria-label': 'Title' }}
      placeholder="Sales Advisor"
      onValueChanged={fieldValueChange}
      value={field.value}
      maxLength={50}
    >
      <Validator>
        <RequiredRule message="Title is required" />
      </Validator>
    </TextBox>
  }

  function EmailField({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }
    return <TextBox
      name="email"
      label="Email"
      labelMode="outside"
      inputAttr={{ 'aria-label': 'Email' }}
      placeholder="filip@email.com"
      onValueChanged={fieldValueChange}
      value={field.value}
      maxLength={50}
    >
      <Validator>
        <RequiredRule message="Email is required" />
        <EmailRule message="Email is invalid" />
      </Validator>
    </TextBox>
  }

  function PhoneField({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }
    return <TextBox
      name="mobile_phone"
      label="Mobile Phone"
      labelMode="outside"
      inputAttr={{ 'aria-label': 'Phone' }}
      mask="(XXX) XXX-XXXX"
      maskRules={rules}
      placeholder="(555) 555-5555"
      onValueChanged={fieldValueChange}
      value={field.value}
    >
      <Validator>
        <RequiredRule message="Mobile phone is required" />
      </Validator>
    </TextBox>
  }


  return (
    <div className="box__register" aria-expanded={active}>
      <div className="box__register_content">
        <h2 className="box__register_title collapsed-hide">
          Register for Allied Group
        </h2>

        <h3 className="box__register_step">Personal Details</h3>

        <fieldset className="box__register_fields collapsed-hide">
          <ValidationGroup ref={validationGroupRef}>
            <div className="flex gap-4">
              <Controller
                name="first_name"
                control={control}
                render={FirstNameFiled}>
              </Controller>
              <Controller
                name="last_name"
                control={control}
                render={LastNameFiled}>
              </Controller>
            </div>
            <Controller
              name="company_name"
              control={control}
              render={CompanyNameFiled}>
            </Controller>
            <Controller
              name="title"
              control={control}
              render={TitleField}>
            </Controller>
            <Controller
              name="email"
              control={control}
              render={EmailField}>
            </Controller>
            <Controller
              name="mobile_phone"
              control={control}
              render={PhoneField}>
            </Controller>
          </ValidationGroup>
        </fieldset>
        <div className="box__register_actions collapsed-hide">
          <Button className="btn btn-primary" onClick={handleSubmit}>
            Next (1/2)
          </Button>
        </div>
        <div className="box__register_link collapsed-hide">
          <p>
            Already Have an Account? <Link to="/login">Log in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

function CompanyDetails({ active, control, pending, onComplete, onCancel }: StepProps) {
  const validationGroupRef = useRef<ValidationGroup>(null);

  const rules = { X: /[0-9]/ };

  const handleSubmit = () => {
    const validation = validationGroupRef.current?.instance.validate();

    // Check the form values
    if (validation?.isValid && onComplete) {
      onComplete();
    }
  };

  function AddressFiled({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }
    return <TextBox
      name="address"
      label="Address *"
      labelMode="outside"
      inputAttr={{ 'aria-label': 'Address' }}
      placeholder="44 Elm Street"
      onValueChanged={fieldValueChange}
      value={field.value}
      maxLength={70}
    >
      <Validator>
        <RequiredRule message="Address is required" />
      </Validator>
    </TextBox>
  }

  function CityFiled({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }
    return <TextBox
      name="city"
      label="City"
      labelMode="outside"
      inputAttr={{ 'aria-label': 'City' }}
      placeholder="Austin"
      onValueChanged={fieldValueChange}
      value={field.value}
      maxLength={40}
    >
      <Validator>
        <RequiredRule message="City is required" />
      </Validator>
    </TextBox>
  }

  function StateFiled({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }
    return <SelectBox
      name="state"
      label="State"
      labelMode="outside"
      items={STATES}
      displayExpr="name"
      valueExpr="abbreviation"
      inputAttr={{ 'aria-label': 'State' }}
      placeholder="Texas"
      className="w-2/3"
      onValueChanged={fieldValueChange}
      value={field.value}
    >
      <Validator>
        <RequiredRule message="State is required" />
      </Validator>
    </SelectBox>
  }

  function ZipCodeFiled({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }
    return <TextBox
      name="zip_code"
      label="Zip"
      labelMode="outside"
      inputAttr={{ 'aria-label': 'Zip' }}
      placeholder="78750"
      onValueChanged={fieldValueChange}
      value={field.value}
      maxLength={5}
    >
      <Validator>
        <RequiredRule message="Zip code is required" />
      </Validator>
    </TextBox>
  }

  function OfficePhoneFiled({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }
    return <TextBox
      name="office_phone"
      label="Office Phone"
      labelMode="outside"
      inputAttr={{ 'aria-label': 'Office Phone' }}
      mask="(XXX) XXX-XXXX"
      maskRules={rules}
      placeholder="(555) 555-5555"
      onValueChanged={fieldValueChange}
      value={field.value}
    >
      <Validator>
        <RequiredRule message="Office phone is required" />
      </Validator>
    </TextBox>
  }

  return (
    <div className="box__register" aria-expanded={active}>
      <div className="box__register_content">
        {onCancel && (
          <button
            type="button"
            className="box__register_back collapsed-hide"
            onClick={() => {
              onCancel();
            }}
          >
            <i className="icon icon-arrow">
              <IconArrowLeft />
            </i>
          </button>
        )}

        <h2 className="box__register_title collapsed-hide">
          Register for Allied Group
        </h2>

        <h3 className="box__register_step">Address</h3>

        <fieldset className="box__register_fields collapsed-hide">
          <ValidationGroup ref={validationGroupRef}>
            <Controller
              name="address"
              control={control}
              render={AddressFiled}>
            </Controller>
            <Controller
              name="city"
              control={control}
              render={CityFiled}>
            </Controller>
            <div className="flex gap-4">
              <Controller
                name="state"
                control={control}
                render={StateFiled}>
              </Controller>
              <Controller
                name="zip_code"
                control={control}
                render={ZipCodeFiled}>
              </Controller>
            </div>
            <Controller
              name="office_phone"
              control={control}
              render={OfficePhoneFiled}>
            </Controller>
          </ValidationGroup>
        </fieldset>
        <div className="box__register_actions collapsed-hide">
          <Button
            className="btn btn-primary"
            disabled={pending}
            onClick={handleSubmit}
          >
            Register
          </Button>
        </div>
        <div className="box__register_link  collapsed-hide">
          <p>
            Already Have an Account? <Link to="/login">Log in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default function Register() {
  const [step, setStep] = useState(0);
  // const [response, dispatch] = useFormState(register, undefined);
  // const { pending } = useFormStatus();
  const [email, setEmail] = useState('');
  const { handleSubmit, control } = useForm();
  const [response, setResponse] = useState<any>();
  const [pending, setPending] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);

  const onSubmit = async (data: any) => {    
    setPending(true);
    const { first_name,
      last_name,
      title,
      company_name,
      email,
      mobile_phone,
      address,
      city,
      state,
      zip_code,
      office_phone
    } = data;

    const formData = new FormData();
    formData.append('first_name', first_name);
    formData.append('last_name', last_name);
    formData.append('company_name', company_name);
    formData.append('title', title);
    formData.append('email', email);
    formData.append('mobile_phone', mobile_phone);
    formData.append('address', address);
    formData.append('city', city);
    formData.append('state', state);
    formData.append('zip_code', zip_code);
    formData.append('office_phone', office_phone);

    try {
      setPending(true);
      const newResponse = await register({}, formData);
      newResponse && setResponse(newResponse);
    } catch (error) {
      setResponse({ message: "Unable to register the user!" });
    } finally {
      setPending(false);
    }
  };

  const changeStep = useCallback(
    (newStep: number) => {
      setStep(newStep);
    },
    [setStep],
  );

  useEffect(() => {
    if (response?.success) {
      if (response?.email) {
        setEmail(response.email);
      }

      setStep(2);
    }
  }, [response]);

  return (
    <>
      {step < 2 && (
        <form className="box__register_form" ref={formRef} onSubmit={handleSubmit(onSubmit)}>
          <PersonalDetails
            active={step === 0}
            control={control}
            pending={pending}
            onComplete={() => {
              changeStep(1);
            }}
          />

          <CompanyDetails
            active={step === 1}
            control={control}
            pending={pending}
            onCancel={() => {
              changeStep(0);
            }}
            onComplete={() => {
              formRef.current?.requestSubmit();
            }}
          />
        </form>
      )}
      {step === 2 && (
        <div className="box__register">
          <div className="box__register_content">
            <h2 className="box__register_title">Register for Allied Group</h2>

            <div className="box__register_thankyou">
              <i className="icon icon-check shrink-0">
                <IconCheck />
              </i>
              <p>
                Your request for an Allied Shop account has been
                submitted. If approved, you will receive an e-mail
                at{' '}<strong>{email}</strong> to sign in.
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
