import './ChangePassword.scss';
import { useState, useMemo, useEffect } from 'react';
// import { useFormState, useFormStatus } from 'react-dom';
import { Validator, RequiredRule } from 'devextreme-react/validator';
import {
  TextBox,
  Button as TextBoxButton,
  TextBoxTypes,
} from 'devextreme-react/text-box';
import { Button, ButtonTypes } from 'devextreme-react/button';
import { changePassword } from '../../actions';
// import { signOut } from 'next-auth/react';
import { ReactComponent as IconAlert } from '../../assets/icons/alert.svg';
import { Controller, useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { RootState } from '../../redux/store';

export default function ChangePassword() {
  const navigate = useNavigate();
  const resetPassword = useSelector((state: RootState) => state.resetPassword);

  const [oldPasswordMode, setOldPasswordMode] =
    useState<TextBoxTypes.TextBoxType>('password');
  const [newPasswordMode, setNewPasswordMode] =
    useState<TextBoxTypes.TextBoxType>('password');
  const [verifyPasswordMode, setVerifyPasswordMode] =
    useState<TextBoxTypes.TextBoxType>('password');
  const [isError, setIsError] = useState(false);

  const { handleSubmit, control } = useForm();
  const [response, setResponse] = useState<any>();
  const [pending, setPending] = useState(false);


  const onSubmit = async (data: any) => {
    setPending(true);
    const { old_password, new_password, verify_password } = data;

    const formData = new FormData();
    formData.append('old_password', old_password);
    formData.append('new_password', new_password);
    formData.append('verify_password', verify_password);

    try {
      const newResponse = await changePassword({}, formData);
      newResponse && setResponse(newResponse);
    } catch (error) {
      setResponse({ message: "Unable to change password!" });
    } finally {
      setPending(false);
    }
  };

  // const [response, dispatch] = useFormState(changePassword, undefined);
  // const { pending } = useFormStatus();

  useEffect(() => {
    if (!response) {
      return;
    }

    if (response?.success) {
      navigate('/');
      return;
    }

    if (response.message) {
      setIsError(true);
      return;
    }
  }, [response, navigate]);

  useEffect( () => {
    if (!resetPassword) {
      navigate('/');
    }
  }, [resetPassword, navigate]);

  const oldPasswordVisibilityButton = useMemo<ButtonTypes.Properties>(
    () => ({
      icon:
        oldPasswordMode === 'text'
          ? '/icons/visibility-on.svg'
          : '/icons/visibility-off.svg',
      stylingMode: 'text',
      onClick: () => {
        setOldPasswordMode((prevPasswordMode: string) =>
          prevPasswordMode === 'text' ? 'password' : 'text',
        );
      },
    }),
    [setOldPasswordMode, oldPasswordMode],
  );

  const newPasswordVisibilityButton = useMemo<ButtonTypes.Properties>(
    () => ({
      icon:
        newPasswordMode === 'text'
          ? '/icons/visibility-on.svg'
          : '/icons/visibility-off.svg',
      stylingMode: 'text',
      onClick: () => {
        setNewPasswordMode((prevPasswordMode: string) =>
          prevPasswordMode === 'text' ? 'password' : 'text',
        );
      },
    }),
    [setNewPasswordMode, newPasswordMode],
  );

  const verifyPasswordVisibilityButton = useMemo<ButtonTypes.Properties>(
    () => ({
      icon:
        verifyPasswordMode === 'text'
          ? '/icons/visibility-on.svg'
          : '/icons/visibility-off.svg',
      stylingMode: 'text',
      onClick: () => {
        setVerifyPasswordMode((prevPasswordMode: string) =>
          prevPasswordMode === 'text' ? 'password' : 'text',
        );
      },
    }),
    [setVerifyPasswordMode, verifyPasswordMode],
  );

  function OldPasswordField({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }

    return <TextBox
      name="old_password"
      label="Old Password *"
      labelMode="outside"
      mode={oldPasswordMode}
      maxLength={50}
      inputAttr={{ 'aria-label': 'Old Password' }}
      placeholder="********"
      onValueChanged={fieldValueChange}
      value={field.value}
    >
      <TextBoxButton
        name="password"
        location="after"
        options={oldPasswordVisibilityButton}
      />
      <Validator>
        <RequiredRule message="Password is required" />
      </Validator>
    </TextBox>
  }

  function NewPasswordField({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }

    return <TextBox
      name="new_password"
      label="New Password *"
      labelMode="outside"
      maxLength={50}
      mode={newPasswordMode}
      inputAttr={{ 'aria-label': 'New Password' }}
      placeholder="********"
      onValueChanged={fieldValueChange}
      value={field.value}
    >
      <TextBoxButton
        name="password"
        location="after"
        options={newPasswordVisibilityButton}
      />
      <Validator>
        <RequiredRule message="Password is required" />
      </Validator>
    </TextBox>
  }

  function VerifyPasswordField({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }

    return <TextBox
      name="verify_password"
      label="Confirm Password *"
      labelMode="outside"
      maxLength={50}
      mode={verifyPasswordMode}
      inputAttr={{ 'aria-label': 'Confirm Password' }}
      placeholder="********"
      onValueChanged={fieldValueChange}
      value={field.value}
    >
      <TextBoxButton
        name="password"
        location="after"
        options={verifyPasswordVisibilityButton}
      />
      <Validator>
        <RequiredRule message="Password is required" />
      </Validator>
    </TextBox>
  }

  return (
    <section className="box__change-password">
      <form className="box__change-password_form" onSubmit={handleSubmit(onSubmit)}>
        <h2 className="box__change-password_title">Change Password</h2>

        {isError && (
          <div className="notice notice-error">
            <i className="icon icon-alert">
              <IconAlert />
            </i>
            <p>
              {response?.message ??
                'There was a problem updating your password.'}
            </p>
          </div>
        )}

        <fieldset className="box__change-password_fields">
          <Controller
            name="old_password"
            control={control}
            render={OldPasswordField}>
          </Controller>
          <Controller
            name="new_password"
            control={control}
            render={NewPasswordField}>
          </Controller>
          <Controller
            name="verify_password"
            control={control}
            render={VerifyPasswordField}>
          </Controller>
        </fieldset>
        <div className="box__change-password_actions">
          <Button
            className="btn btn-primary"
            disabled={pending}
            useSubmitBehavior={true}
          >
            Change Password
          </Button>
        </div>
      </form>
    </section>
  );
}
