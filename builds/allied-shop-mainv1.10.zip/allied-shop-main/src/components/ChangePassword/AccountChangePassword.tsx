
import { useState, useMemo, useEffect } from 'react';
import { changePassword } from '../../actions';
import { Validator, RequiredRule } from 'devextreme-react/validator';
import {
  TextBox,
  Button as TextBoxButton,
  TextBoxTypes,
} from 'devextreme-react/text-box';
import { Button, ButtonTypes } from 'devextreme-react/button';
import { ReactComponent as IconInfo } from '../../assets/icons/info-fill.svg';
import { ReactComponent as IconAlert } from '../../assets/icons/alert.svg';
import './AccountChangePassword.scss';
import { Controller, useForm } from 'react-hook-form';

export default function AccountChangePassword() {
  const [oldPasswordMode, setOldPasswordMode] =
    useState<TextBoxTypes.TextBoxType>('password');
  const [newPasswordMode, setNewPasswordMode] =
    useState<TextBoxTypes.TextBoxType>('password');
  const [verifyPasswordMode, setVerifyPasswordMode] =
    useState<TextBoxTypes.TextBoxType>('password');
  const [isComplete, setIsComplete] = useState(false);
  const [isError, setIsError] = useState(false);

  const { handleSubmit, control } = useForm();
  const [response, setResponse] = useState<any>();
  const [pending, setPending] = useState(false);

  const onSubmit = async (data: any) => {
    setPending(true);
    const {old_password, new_password, verify_password} = data;
    
    const formData = new FormData();
    formData.append('old_password', old_password);
    formData.append('new_password', new_password);
    formData.append('verify_password', verify_password);

    try {
      const newResponse = await changePassword({}, formData);
      setResponse(newResponse);
    } catch (error) {
      setResponse({message: "Unable to change password!"});
    } finally {
      setPending(false);
    }
  };

  useEffect(() => {
    if (!response) {
      return;
    }

    if (response.success) {
      setIsComplete(true);
      return;
    }

    if (response.message) {
      setIsError(true);
      return;
    }

    setPending(false);
  }, [response]);


  const oldPasswordVisibilityButton = useMemo<ButtonTypes.Properties>(
    () => ({
      icon:
        oldPasswordMode === 'text'
          ? '/icons/visibility-on.svg'
          : '/icons/visibility-off.svg',
      stylingMode: 'text',
      onClick: () => {
        setOldPasswordMode((prevPasswordMode: string) =>
          prevPasswordMode === 'text' ? 'password' : 'text',
        );
      },
    }),
    [setOldPasswordMode, oldPasswordMode],
  );

  const newPasswordVisibilityButton = useMemo<ButtonTypes.Properties>(
    () => ({
      icon:
        newPasswordMode === 'text'
          ? '/icons/visibility-on.svg'
          : '/icons/visibility-off.svg',
      stylingMode: 'text',
      onClick: () => {
        setNewPasswordMode((prevPasswordMode: string) =>
          prevPasswordMode === 'text' ? 'password' : 'text',
        );
      },
    }),
    [setNewPasswordMode, newPasswordMode],
  );

  const verifyPasswordVisibilityButton = useMemo<ButtonTypes.Properties>(
    () => ({
      icon:
        verifyPasswordMode === 'text'
          ? '/icons/visibility-on.svg'
          : '/icons/visibility-off.svg',
      stylingMode: 'text',
      onClick: () => {
        setVerifyPasswordMode((prevPasswordMode: string) =>
          prevPasswordMode === 'text' ? 'password' : 'text',
        );
      },
    }),
    [setVerifyPasswordMode, verifyPasswordMode],
  );

  function OldPasswordField({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }

    return <TextBox
      name="old_password"
      label="Old Password *"
      labelMode="outside"
      maxLength={50}
      mode={oldPasswordMode}
      inputAttr={{ 'aria-label': 'Old Password' }}
      placeholder="********"
      onValueChanged={fieldValueChange}
      value={field.value}
    >
      <TextBoxButton
        name="password"
        location="after"
        options={oldPasswordVisibilityButton}
      />
      <Validator>
        <RequiredRule message="Password is required" />
      </Validator>
    </TextBox>
  }

  function NewPasswordField({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }

    return <TextBox
      name="new_password"
      label="New Password *"
      labelMode="outside"
      maxLength={50}
      mode={newPasswordMode}
      inputAttr={{ 'aria-label': 'New Password' }}
      placeholder="********"
      onValueChanged={fieldValueChange}
      value={field.value}
    >
      <TextBoxButton
        name="password"
        location="after"
        options={newPasswordVisibilityButton}
      />
      <Validator>
        <RequiredRule message="Password is required" />
      </Validator>
    </TextBox>
  }

  function VerifyPasswordField({ field }: any) {
    function fieldValueChange(e: any) {
      field.onChange(e.value);
    }

    return <TextBox
      name="verify_password"
      label="Confirm Password *"
      labelMode="outside"
      maxLength={50}
      mode={verifyPasswordMode}
      inputAttr={{ 'aria-label': 'Confirm Password' }}
      placeholder="********"
      onValueChanged={fieldValueChange}
      value={field.value}
    >
      <TextBoxButton
        name="password"
        location="after"
        options={verifyPasswordVisibilityButton}
      />
      <Validator>
        <RequiredRule message="Password is required" />
      </Validator>
    </TextBox>
  }

  return (
    <section className="account_password">
      <form className="account_password_form" onSubmit={handleSubmit(onSubmit)}>
        <h2 className="account_password_title">Password</h2>

        {isComplete && (
          <div className="notice notice-info">
            <i className="icon icon-info">
              <IconInfo />
            </i>
            <p>Your password has been updated.</p>
          </div>
        )}

        {isError && (
          <div className="notice notice-error">
            <i className="icon icon-alert">
              <IconAlert />
            </i>
            <p>
              {response?.message ??
                'There was a problem updating your password.'}
            </p>
          </div>
        )}

        <fieldset className="account_password_fields">
          <Controller
            name="old_password"
            control={control}
            render={OldPasswordField}>
          </Controller>
          <Controller
            name="new_password"
            control={control}
            render={NewPasswordField}>
          </Controller>
          <Controller
            name="verify_password"
            control={control}
            render={VerifyPasswordField}>
          </Controller>

        </fieldset>
        <div className="account_password_actions">
          <Button
            className="btn btn-primary"
            disabled={pending}
            useSubmitBehavior={true}
          >
            Save Changes
          </Button>
        </div>
      </form>
    </section>
  );
}
