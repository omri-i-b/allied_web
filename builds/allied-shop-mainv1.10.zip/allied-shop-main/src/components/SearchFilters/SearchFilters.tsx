
import './SearchFilters.scss';
import { ChangeEvent, useCallback, useState } from 'react';
import {ReactComponent as IconChevronDown} from '../../assets/icons/chevron-down.svg';
import {ReactComponent as IconCheck} from '../../assets/icons/check.svg';
import { Facet } from '../../types/products';
import { useSearch } from '../../contexts/SearchProvider';

function SearchFilterGroup(facet: Facet) {
  const { filters, setFilters } = useSearch();

  const [expanded, setExpanded] = useState(true);

  // Toggle the group
  const handleClick = useCallback(() => {
    setExpanded(!expanded);
  }, [expanded, setExpanded]);

  // When a filter is toggled
  const handleFilterChange = useCallback(
    (e: ChangeEvent, val: string) => {
      const target = e.target as HTMLInputElement;
      const newFilters: { [key: string]: string[] } = Object.assign(
        {},
        filters,
      );

      if (!newFilters) {
        return;
      }

      // Is checked, add to the array
      if (target.checked) {
        newFilters[facet.type].push(val);
      } else {
        let idx = newFilters[facet.type].indexOf(val);
        newFilters[facet.type].splice(idx, 1);
      }

      setFilters(newFilters);
    },
    [facet.type, filters, setFilters],
  );

  return (
    <div className="filter-search-container">
      <dl
        className={`filter-group filter-group_${facet.type}`}
        aria-expanded={expanded}
      >
        <dt className="filter-group__header">
          <button type="button" onClick={handleClick}>
            <span>{facet.title}</span>
            <i className="icon icon-chevron">
              <IconChevronDown />
            </i>
          </button>
        </dt>
        <dd className="filter-group__content">
          <div className="filters">
            <ul className="filters__list">
              {facet.items.map((item) => {
                const isChecked =
                  (filters as { [key: string]: string[] })[facet.type].indexOf(
                    item.facet,
                  ) > -1;

                return (
                  <li
                    key={`filter-${facet.type}-${item.facet}`}
                    className={`filters__item`}
                  >
                    <input
                      type="checkbox"
                      name={`${facet.type}['${item.facet}']`}
                      id={`${facet.type}['${item.facet}']`}
                      defaultChecked={isChecked}
                      value="yes"
                      onChange={(e) => {
                        handleFilterChange(e, item.facet);
                      }}
                    />
                    <label htmlFor={`${facet.type}['${item.facet}']`}>
                      <span className="checkbox">
                        <i className="icon icon-check">
                          <IconCheck />
                        </i>
                      </span>
                      <span>
                        <strong>
                          {item.prefix && <cite>{item.prefix} / </cite>}
                          {item.title}
                        </strong>{' '}
                        <ins>({item.count})</ins>
                      </span>
                    </label>
                  </li>
                );
              })}
            </ul>
          </div>
        </dd>
      </dl>
    </div>
  );
}

export default function SearchFilters() {
  const { facets } = useSearch();
  return (
    <aside className="sidebar__filters">
      {facets.map((facet) => {
        const hasFilters = facet.items.length > 0;
        return (
          <div key={facet.title}>
            {hasFilters && <SearchFilterGroup {...facet} />}
          </div>
        );
      })}
    </aside>
  );
}
