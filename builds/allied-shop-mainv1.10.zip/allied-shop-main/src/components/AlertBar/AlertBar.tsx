
import React, { useEffect, useState } from 'react';
import { JSX } from 'react';
import { useCart } from '../../contexts/CartProvider';
import './AlertBar.scss';
import { Link, useLocation } from 'react-router-dom';

export default function AlertBar() {
  const { configuration } = useCart();
  
  
  const location = useLocation();
  const hasDiscount = !!configuration?.flatDiscount;
  const isCheckout = location.pathname === '/checkout';
  

  const baseMessage = `Welcome to shop.alliedfit.com${
    hasDiscount
      ? ` | Enjoy a ${configuration.flatDiscount}% discount on all orders`
      : ''
  }`;

  const [currentMessage, setCurrentMessage] = useState<string | JSX.Element>(
    baseMessage,
  );

  const [fade, setFade] = useState(false);

  useEffect(() => {
    const alternateMessage: JSX.Element = (
      <>
        Featured Product: SS Cast Fittings{' '}
        <Link
          to="/products/cast-fittings/"
          className="underline text-white-500"
        >
          Shop Now
        </Link>
      </>
    );

    const intervalId = setInterval(() => {
      setFade(true);
      setTimeout(() => {
        setCurrentMessage((prevMessage) =>
          prevMessage === baseMessage ? alternateMessage : baseMessage,
        );
        setFade(false);
      }, 500); // Matches the CSS transition duration
    }, 6000);

    return () => clearInterval(intervalId); // Cleanup on unmount
  }, [baseMessage]);

  return (
    <aside className={`alert-bar ${isCheckout ? 'hidden' : ''}`}>
      <div className="container">
        <p
          className={`transition-opacity duration-500 ${
            fade ? 'opacity-0' : 'opacity-100'
          }`}
        >
          {currentMessage}
        </p>
      </div>
    </aside>
  );
}
