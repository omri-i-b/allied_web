import { useCallback, useEffect, useState } from 'react';
import CheckoutAddressList from './CheckoutAddressList';
import { Address } from '../../types/customer';
import { getAllAddresses, saveAddress } from '../../actions';
import { useCart } from '../../contexts/CartProvider';
import { useModal } from '../../contexts/ModalProvider';
import ModalSelectAddress from '../Modal/ModalSelectAddress';
import ModalEditAddress from '../Modal/ModalEditAddress';
import { useToast } from '../../contexts/ToastProvider';
import { Button } from 'devextreme-react/button';

interface CheckoutStepShippingAddressProps {
  active: boolean;
  selectedAddress?: Address;
  onSelect?: (_address: Address) => void;
  onEdit?: () => void;
}

export default function CheckoutStepShippingAddress({
  active,
  selectedAddress,
  onSelect,
  onEdit,
}: CheckoutStepShippingAddressProps) {
  const { cartAddress } = useCart();
  const { openModal } = useModal();
  const { createToast } = useToast();

  const [addressList, setAddressList] = useState<Address[]>([]);

  /**
   * Refresh the address list
   */
  const refreshAddressList = useCallback(async () => {
    const data = await getAllAddresses();

    if (data) {
      setAddressList(data);
    }

    return data;
  }, []);

  /**
   * Save the New Address
   */
  const handleSaveAddress = useCallback(
    async (verifiedAddress: Address) => {
      const savedAddressId = await saveAddress(
        verifiedAddress.name,
        verifiedAddress.street1,
        verifiedAddress.street2 ?? '',
        verifiedAddress.city,
        verifiedAddress.state,
        verifiedAddress.postalCode,
        verifiedAddress.isVerified,
      );

      if (savedAddressId) {
        setTimeout(async () => {
          const data = await refreshAddressList();

          if (!data) {
            return;
          }

          const newAddress = data.find((a) => a.id === savedAddressId);

          if (newAddress && onSelect) {
            onSelect(newAddress);
          }
        }, 500);
      } else {
        createToast(<>There was a problem creating the address</>, 'error');
      }
    },
    [refreshAddressList, createToast, onSelect],
  );

  // Add new address
  const handleAddAddress = useCallback(() => {
    openModal(
      <ModalEditAddress onComplete={handleSaveAddress} />,
      'Add new address',
      ['modal__edit-address'],
    );
  }, [openModal, handleSaveAddress]);

  // Select from saved addresses
  const handleShowLocationModal = useCallback(() => {
    openModal(
      <ModalSelectAddress addressList={addressList} onSelect={onSelect} />,
      'Select Delivery Address',
      ['modal__select-address'],
    );
  }, [openModal, addressList, onSelect]);

  useEffect(() => {
    (async () => {
      await refreshAddressList();
    })();
  }, [refreshAddressList]);

  return (
    <div className="checkout-step-shipping-address">
      {active ? (
        <>
          <h2 className="checkout-step-shipping-address_title">
            <span>
              Shipping Address <em>(1/2)</em>
            </span>

            <Button
              className="btn btn-secondary-link"
              onClick={handleAddAddress}
            >
              + Add new address
            </Button>
          </h2>

          <CheckoutAddressList
            addressList={addressList}
            selectedAddress={selectedAddress || cartAddress}
            onSelect={onSelect}
            onShowLocationModal={handleShowLocationModal}
            onAddAddress={handleAddAddress}
          />
        </>
      ) : (
        <>
          <dl className="checkout-step-shipping-address_group">
            <dt>
              Shipping Address{' '}
              <Button className="btn btn-primary-link" onClick={onEdit}>
                Edit
              </Button>
            </dt>
            <dd>
              {selectedAddress && (
                <address>
                  <strong>{selectedAddress.name}</strong>
                  <br />
                  {selectedAddress.street1}
                  <br />
                  {selectedAddress.street2 && (
                    <>
                      {selectedAddress.street2}
                      <br />
                    </>
                  )}
                  {selectedAddress.city}, {selectedAddress.state}{' '}
                  {selectedAddress.postalCode}
                </address>
              )}
            </dd>
          </dl>
        </>
      )}
    </div>
  );
}
