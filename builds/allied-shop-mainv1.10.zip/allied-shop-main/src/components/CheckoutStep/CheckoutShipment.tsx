import { DateBox, DateBoxTypes } from 'devextreme-react/date-box';
import { SelectBox, SelectBoxTypes } from 'devextreme-react/select-box';
import { TextArea, TextAreaTypes } from 'devextreme-react/text-area';
import { TextBox, TextBoxTypes } from 'devextreme-react/text-box';
import { Button } from 'devextreme-react/button';
import { ValidationGroup } from 'devextreme-react/validation-group';
import { Validator, RequiredRule } from 'devextreme-react/validator';
import { Shipment } from './CheckoutStepShippingOptions';
import {
  ChangeEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useCart } from '../../contexts/CartProvider';
import { getHours, isWeekday } from '../../utils/convertToTime';
import {ReactComponent as IconInfo} from '../../assets/icons/info-fill.svg';
import {ReactComponent as IconCalendar} from '../../assets/icons/calendar.svg';
import { getEstimatedShipPickUpDate } from '../../actions';
import { useDebouncedCallback } from 'use-debounce';
import { ShippingCombination } from '../../types/customer';
import ChipShipment from '../Chips/ChipShipment';

const shipDateFormat = new Intl.DateTimeFormat('en-US', {
  weekday: 'short',
  month: 'long',
  day: 'numeric',
});

const shortDateFormat = new Intl.DateTimeFormat('en-US', {
  month: 'long',
  day: 'numeric',
});

interface CheckoutShipmentProps {
  active: boolean;
  packageCount: number;
  shipment: Shipment;
  onEdit?: () => void;
  onUpdate?: (_shipment: Shipment) => void;
  onComplete?: (_ready:boolean) => void;
}

export default function CheckoutShipment({
  active,
  packageCount,
  shipment,
  onEdit,
  onUpdate = () => {},
  onComplete = () => {},
}: CheckoutShipmentProps) {
  const {
    warehouse,
    weight,
    shipDate,
    requiredShipDate,
    combination,
    freightAccount,
    note,
    items,
  } = shipment;
  const {
    shippingCombinations,
    shippingCombination,
    hasPrepaid,
    prepaidCombinations,
    setAllowThirdParty,
  } = useCart();

  const [isDirty, setIsDirty] = useState(false);

  const validationGroupRef = useRef<ValidationGroup>(null);
  const carrierSelectRef = useRef<SelectBox>(null);

  const currentHour = new Date().getHours();

  const cutOffHour = useMemo(() => {
    if (!shippingCombination) {
      return;
    }

    return getHours(shippingCombination.shipViaCutOffTime) ?? 0;
  }, [shippingCombination]);

  const shippingDay = useMemo(() => {
    const today = new Date();

    if (0 >= (cutOffHour as number) - currentHour || !isWeekday()) {
      var add;

      switch (today.getDay()) {
        case 6:
          add = 2;
          break;
        case 5:
          add = 3;
          break;
        default:
          add = 1;
          break;
      }

      // Return the next business day
      return today.setDate(today.getDate() + add);
    }

    // Return today
    return today;
  }, [cutOffHour, currentHour]);

  /**
   * Disable the weekends from being selected
   */
  const getDisabledDates = (args: any) => {
    const today = new Date();
    const selectedDate = args.date;
  
    const dayOfWeek = selectedDate.getDay();
    if (dayOfWeek === 0 || dayOfWeek === 6) {
      return true;
    }
  
    return selectedDate.toDateString() === today.toDateString();
  };  

  /**
   * Get only combinations that are not Will Call
   */
  const nonWillCallCombinations = useMemo(() => {
    if (!shippingCombinations) {
      return;
    }

    return shippingCombinations.filter(
      (combination) => 'WILL' !== combination.carrierCode,
    );
  }, [shippingCombinations]);

  /**
   * Generic function to update a step value
   */
  const updateShipmentValue = useCallback(
    async (key: any, val: any) => {
      if (!key) {
        return;
      }

      if (!isDirty) {
        setIsDirty(true);
      }

      // Make a copy of the package and update the key and value
      const newShipment = { ...shipment, [key]: val };

      if ('combination' === key && newShipment.combination) {
        const estimatedShipPickUpDate = await getEstimatedShipPickUpDate(
          newShipment.combination.shipViaId,
          newShipment.warehouse.id,
        );

        newShipment.estimatedShipPickUpDate = estimatedShipPickUpDate;

        if (!newShipment.requiredShipDate) {
          newShipment.requiredShipDate = estimatedShipPickUpDate;
        }
      }

      if (onUpdate) {
        onUpdate(newShipment);
      }
    },
    [shipment, onUpdate, isDirty],
  );

  /**
   * Change the display value in select to be carrier + shipVia
   */
  const combinationDisplay = useCallback((item: ShippingCombination) => {
    return item && `${item.carrierDescription} - ${item.shipViaDescription}`;
  }, []);

  /**
   * Handle ship date change
   */
  const handleShipDateChange = useCallback(
    (e: ChangeEvent<HTMLInputElement>) => {
      const target = e.target;
      const match = target.name.match(/^ship_date\[(.+?)]$/);
      var warehouseId: number = 0;

      if (match) {
        warehouseId = parseInt(match[1], 10);
      }

      if (!warehouseId) {
        return;
      }

      updateShipmentValue('shipDate', target.value);
    },
    [updateShipmentValue],
  );

  /**
   * Handle Date Change
   */
  const handleDateChange = useCallback(
    (e: DateBoxTypes.ValueChangedEvent) => {
      const newDate = new Date(e.value);

      updateShipmentValue('requiredShipDate', newDate.toISOString());
    },
    [updateShipmentValue],
  );

  /**
   * Handle the carrier select
   */
  const handleCarrierSelect = useCallback(
    (e: SelectBoxTypes.ValueChangedEvent) => {
      const combination = shippingCombinations?.find((c) => c.id === e.value);

      if (!combination) {
        return;
      }

      updateShipmentValue('combination', combination);
    },
    [shippingCombinations, updateShipmentValue],
  );

  const handleSelectPrepaid = useCallback(
    (combinationId: number) => {
      const combination = prepaidCombinations?.find(
        (c) => c.id === combinationId,
      );

      if (!combination) {
        return;
      }

      if (carrierSelectRef.current) {
        carrierSelectRef.current.instance.reset(combination.id as any);
      }
    },
    [prepaidCombinations, carrierSelectRef],
  );

  /**
   * Handle the freight number changed
   */
  const handleFreightNumberChange = useDebouncedCallback(
    (e: TextBoxTypes.ValueChangedEvent) => {
      updateShipmentValue('freightAccount', e.value);
    },
    250,
  );

  /**
   * Handle Note Change
   */
  const handleNoteChange = useCallback(
    (e: TextAreaTypes.ValueChangedEvent) => {
      updateShipmentValue('note', e.value);
    },
    [updateShipmentValue],
  );

  const hasPrepaidSelected = useMemo(() => {
    return !!prepaidCombinations.find((c) => c.id === shipment.combination?.id);
  }, [shipment, prepaidCombinations]);

  useEffect(() => {
    setAllowThirdParty(!hasPrepaidSelected);
  }, [hasPrepaidSelected, setAllowThirdParty]);

  /**
   * Validate the shipment
   */
  useEffect(() => {
    setIsDirty(true);

    const validation = validationGroupRef.current?.instance.validate();

    if (!validation?.isValid) {
      if (onComplete) {
        onComplete(false);
      }

      if (validation?.brokenRules) {
        const first = (validation.brokenRules[0] as any).validator;

        setTimeout(() => {
          first.focus();
        }, 250);
      }
      return;
    }

    if (onComplete) {
      onComplete(true);
    }
  }, [shipment, validationGroupRef, onComplete]);

  return (
    <>
      {active ? (
        <div className="checkout-shipment">
          <ValidationGroup ref={validationGroupRef}>
            <div className="step-delivery-options_shipment">
              <span className="flex gap-3">
                <span>
                  Package {packageCount} from <strong>{warehouse.name}</strong>
                </span>
                <ChipShipment items={items} />
              </span>
              <small>Est {(weight || 0).toFixed(1)} lbs</small>
            </div>

            <div className="step-delivery-options_date">
              <h2 className="step-delivery-options_date_title">
                <i className="icon icon-calendar">
                  <IconCalendar />
                </i>
                <span>Shipping Date*</span>
                <i className="icon icon-info" data-tooltip="This is a tooltip">
                  <IconInfo />
                </i>
              </h2>

              <p className="step-delivery-options_date_description">
                Select a time to ship your order.
              </p>

              <ul className="step-delivery-options_date_selector">
                <li className="step-delivery-options_date_selector_option">
                  <input
                    type="radio"
                    id="ship_date_asap"
                    name={`ship_date[${warehouse.id}]`}
                    value="asap"
                    onChange={handleShipDateChange}
                    defaultChecked={
                      !shipDate || 'asap' === shipDate ? true : false
                    }
                  />
                  <label htmlFor="ship_date_asap">ASAP</label>
                </li>
                <li className="step-delivery-options_date_selector_option">
                  <input
                    type="radio"
                    id="ship_date_manual"
                    name={`ship_date[${warehouse.id}]`}
                    value="manual"
                    onChange={handleShipDateChange}
                    defaultChecked={
                      shipDate && 'asap' !== shipDate ? true : false
                    }
                  />
                  <label htmlFor="ship_date_manual">On a future date</label>
                </li>
                {shipDate === 'manual' && (
                  <li>
                    <div className="date-field">
                      <DateBox
                        type="date"
                        label="Date"
                        labelMode="hidden"
                        name={`ship_date_manual[${warehouse.id}]`}
                        min={new Date()}
                        defaultValue={requiredShipDate || shippingDay}
                        displayFormat="shortdate"
                        onValueChanged={handleDateChange}
                        disabledDates={getDisabledDates}
                      >
                        <Validator>
                          <RequiredRule message="Date is required" />
                        </Validator>
                      </DateBox>
                    </div>
                  </li>
                )}
              </ul>

              <p className="step-delivery-options_date_availability">
                Available to ship on{' '}
                <strong>{shipDateFormat.format(shippingDay)}</strong>
              </p>
            </div>

            <div className="step-delivery-options_carrier">
              <h2 className="step-delivery-options_carrier_title">
                Select a carrier and service level *
              </h2>

              <p className="step-delivery-options_carrier_description">
                Select your preferred shipping carrier and service . Price and
                delivery estimates will be available from Allied once your order
                is submitted.
              </p>

              <SelectBox
                ref={carrierSelectRef}
                placeholder="Select"
                width={400}
                name={`carrier[${warehouse.id}]`}
                dataSource={nonWillCallCombinations}
                valueExpr="id"
                searchEnabled={true}
                searchMode="contains"
                displayExpr={combinationDisplay}
                defaultValue={combination?.id}
                onValueChanged={handleCarrierSelect}
                label="Carrier and service level *"
                labelMode="hidden"
              >
                <Validator>
                  <RequiredRule message="Select preferred method" />
                </Validator>
              </SelectBox>

              {hasPrepaid && !hasPrepaidSelected && (
                <>
                  {prepaidCombinations.length > 1 ? (
                    <div className="flex flex-col gap-2">
                      <p className="step-delivery-options_carrier_prepaid">
                        <strong>Prepaid Available:</strong> Click to select.
                      </p>
                      <ul className="step-delivery-options_carrier_prepaid_list">
                        {prepaidCombinations.map((prepaidCombination) => {
                          return (
                            <li key={`prepaid-${prepaidCombination.id}`}>
                              <button
                                className="btn btn-primary-link"
                                onClick={() => {
                                  handleSelectPrepaid(prepaidCombination.id);
                                }}
                              >
                                {prepaidCombination.carrierDescription}
                              </button>
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  ) : (
                    <p className="step-delivery-options_carrier_prepaid">
                      <strong>Prepaid Available:</strong> Click to select{' '}
                      <button
                        className="btn btn-primary-link"
                        onClick={() => {
                          handleSelectPrepaid(prepaidCombinations[0].id);
                        }}
                      >
                        {prepaidCombinations[0].carrierDescription}
                      </button>
                      .
                    </p>
                  )}
                </>
              )}

              {!hasPrepaidSelected && (
                <TextBox
                  name={`freight_account[${warehouse.id}]`}
                  width={400}
                  label="Freight Collect Account Number *"
                  labelMode="outside"
                  defaultValue={freightAccount}
                  valueChangeEvent="input"
                  onValueChanged={handleFreightNumberChange}
                >
                  <Validator>
                    <RequiredRule message="Enter account number" />
                  </Validator>
                </TextBox>
              )}

              <TextArea
                name={`note[${warehouse.id}]`}
                width={400}
                label="Note"
                labelMode="outside"
                defaultValue={note}
                onValueChanged={handleNoteChange}
              ></TextArea>
            </div>
          </ValidationGroup>
        </div>
      ) : (
        <dl className="checkout-shipment">
          <dt>
            <span className="flex gap-3">
              <span>
                Package {packageCount} from <em>{warehouse.name}</em>
              </span>
              <ChipShipment items={shipment.items} />
            </span>
            {isDirty && (
              <Button className="btn btn-primary-link" onClick={onEdit}>
                Edit
              </Button>
            )}
          </dt>
          <dd>
            <ul>
              {requiredShipDate && (
                <li>
                  <strong>Ships on</strong>{' '}
                  {shortDateFormat.format(new Date(requiredShipDate))}
                </li>
              )}
              {combination && (
                <li>
                  <strong>Carrier</strong> {combination?.carrierDescription}
                </li>
              )}
              {freightAccount && (
                <li>
                  <strong>Freight Collect Account Number</strong>{' '}
                  {freightAccount}
                </li>
              )}
              {note && (
                <li>
                  <strong>Note</strong> {note}
                </li>
              )}
            </ul>
          </dd>
        </dl>
      )}
    </>
  );
}
