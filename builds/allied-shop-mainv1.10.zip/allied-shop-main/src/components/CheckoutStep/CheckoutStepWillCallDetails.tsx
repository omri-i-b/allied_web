import {
  ChangeEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useCart } from '../../contexts/CartProvider';
import { Warehouse } from '../../types/products';
import CheckoutStep from '../../components/CheckoutStep/CheckoutStep';
import { Button } from 'devextreme-react/button';
import { DateBox, DateBoxTypes } from 'devextreme-react/date-box';
import { TextArea, TextAreaTypes } from 'devextreme-react/text-area';
import { ValidationGroup } from 'devextreme-react/validation-group';
import { Validator, RequiredRule } from 'devextreme-react/validator';
import { getHours, isWeekday } from '../../utils/convertToTime';
import {ReactComponent as IconCalendar} from '../../assets/icons/calendar.svg';
import ChipShipment from '../Chips/ChipShipment';
import { CartItem } from '../../types/cart';

const deliveryDayFormat = new Intl.DateTimeFormat('en-US', {
  weekday: 'short',
  month: 'long',
  day: 'numeric',
});

interface CheckoutStepWillCallDetailsProps {
  mixed: boolean;
  active: boolean;
  dirty: boolean;
  values?: any;
  onNext: () => void;
  onEdit: () => void;
  onUpdate: (_values: any) => void;
}

export interface WillCallStepValues {
  shipments: Shipment[];
}

type Shipment = {
  warehouse: Warehouse;
  weight?: number;
  shipDate?: string;
  requiredShipDate?: string;
  estimatedShipPickUpDate?: string;
  note?: string;
  items: CartItem[];
};

export default function CheckoutStepWillCallDetails({
  mixed = false,
  active,
  dirty,
  values,
  onNext,
  onEdit,
  onUpdate,
}: CheckoutStepWillCallDetailsProps) {
  const { items, willCallTerm, willCallCombination } = useCart();

  const [stepValues, setStepValues] = useState<WillCallStepValues | undefined>(
    values,
  );
  const [isReady, setIsReady] = useState(false);

  const validationGroupRef = useRef<ValidationGroup>(null);

  const currentHour = new Date().getHours();

  const cutOffHour = useMemo(() => {
    if (!willCallCombination) {
      return;
    }

    return getHours(willCallCombination.shipViaCutOffTime) ?? 0;
  }, [willCallCombination]);

  const pickupDay = useMemo(() => {
    const today = new Date();

    if (0 >= (cutOffHour as number) - currentHour || !isWeekday()) {
      var add;

      switch (today.getDay()) {
        case 6:
          add = 2;
          break;
        case 5:
          add = 3;
          break;
        default:
          add = 1;
          break;
      }

      // Return the next business day
      today.setDate(today.getDate() + add);
    }

    // Return today
    return today;
  }, [cutOffHour, currentHour]);

  /**
   * Convert the cart items into shipping packages
   */
  const willCallPackages = useMemo(() => {
    var shipments: Shipment[] = [];

    if (!willCallTerm || !willCallCombination) {
      return [];
    }

    // Filter out any non-shipping items
    var filteredItems = items.filter(
      (item) => item.shipTermId === willCallTerm.id,
    );

    // Group the items by Warhouse name
    var filteredItemsByWarehouse = Object.groupBy(
      filteredItems,
      ({ warehouseCode }) => warehouseCode,
    );

    // Convert into a shipment
    Object.keys(filteredItemsByWarehouse).forEach(async (warehouse) => {
      const willCallItems = filteredItemsByWarehouse[warehouse];

      if (!willCallItems) {
        return;
      }

      const weight = willCallItems.reduce(
        (total: number, item: { weight: number }) => total + item.weight,
        0,
      );

      // Use the data from the first item
      const firstItem = willCallItems[0];

      const today = pickupDay;

      // Create a shipment
      shipments.push({
        warehouse: {
          id: firstItem.warehouseId,
          code: firstItem.warehouseCode,
          name: firstItem.warehouseName,
        } as Warehouse,
        weight,
        requiredShipDate: today.toISOString(),
        estimatedShipPickUpDate: today.toISOString(),
        items: willCallItems,
      });
    });

    return shipments;
  }, [items, willCallTerm, willCallCombination, pickupDay]);

  /**
   * On load setup the values if none passed
   */
  useEffect(() => {
    if (!stepValues) {
      let newValues = willCallPackages;
      setStepValues({ shipments: newValues });
    }
  }, [willCallPackages, stepValues]);

  /**
   * Disable the weekends from being selected
   */
  const getDisabledDates = (args: any) => {
    const dayOfWeek = args.date.getDay();
    return dayOfWeek === 0 || dayOfWeek === 6;
  };

  /**
   * Update the step value
   */
  const updateStepValue = useCallback(
    (warehouseId: number, key: any, val: any) => {
      if (!warehouseId || !key) {
        return;
      }

      // Make a copy of the step values
      const newValues = Object.assign({}, stepValues);

      // Find the index of the shipment we want to update
      const shipmentIdx: number = newValues.shipments.findIndex(
        (p: Shipment) => p.warehouse.id === warehouseId,
      );

      // Make a copy of the shipment and update the key and value
      const newShipment = Object.assign({}, newValues.shipments[shipmentIdx], {
        [key]: val,
      });

      // Update the values
      newValues.shipments[shipmentIdx] = newShipment;

      // Update the step values
      setStepValues(newValues);

      if (onUpdate) {
        onUpdate(stepValues);
      }
    },
    [stepValues, onUpdate],
  );

  /**
   * Handle ship date change
   */
  const handleShipDateChange = useCallback(
    (e: ChangeEvent) => {
      const target = e?.target as HTMLInputElement;
      const match = target.name.match(/^ship_date\[(.+?)]$/);
      var warehouseId: number = 0;

      if (match) {
        warehouseId = parseInt(match[1], 10);
      }

      if (!warehouseId) {
        return;
      }

      updateStepValue(warehouseId, 'shipDate', target.value);

      if ('asap' === target.value) {
        const requiredShipDate = pickupDay;

        updateStepValue(
          warehouseId,
          'requiredShipDate',
          requiredShipDate.toISOString(),
        );
        updateStepValue(
          warehouseId,
          'estimatedShipPickUpDate',
          requiredShipDate.toISOString(),
        );
      }
    },
    [updateStepValue, pickupDay],
  );

  /**
   * Handle Date Change
   */
  const handleDateChange = useCallback(
    (e: DateBoxTypes.ValueChangedEvent) => {
      const target = e?.component;
      const match = target.option('name')?.match(/^ship_date_manual\[(.+?)]$/);
      var warehouseId: number = 0;

      if (match) {
        warehouseId = parseInt(match[1], 10);
      }

      if (!warehouseId) {
        return;
      }

      const newDate = new Date(e.value);

      updateStepValue(warehouseId, 'requiredShipDate', newDate.toISOString());
      updateStepValue(
        warehouseId,
        'estimatedShipPickUpDate',
        newDate.toISOString(),
      );
    },
    [updateStepValue],
  );

  /**
   * Handle Note Change
   */
  const handleNoteChange = useCallback(
    (e: TextAreaTypes.ValueChangedEvent) => {
      const target = e?.component;
      const match = target.option('name')?.match(/^note\[(.+?)]$/);
      var warehouseId: number = 0;

      if (match) {
        warehouseId = parseInt(match[1], 10);
      }

      if (!warehouseId) {
        return;
      }

      updateStepValue(warehouseId, 'note', e.value);
    },
    [updateStepValue],
  );

  const handleValidate = useCallback(() => {
    const validation = validationGroupRef.current?.instance.validate();

    if (validation?.isValid && onNext) {
      onNext();
    }
  }, [validationGroupRef, onNext]);

  useEffect(() => {
    if (!active) {
      return;
    }

    const validation = validationGroupRef.current?.instance.validate();

    if (!validation?.isValid) {
      setIsReady(false);
      
      if (validation?.brokenRules) {
        const first = (validation.brokenRules[0] as any).validator;

        setTimeout(() => {
          first.focus();
        }, 250);
      }
      return;
    }

    setIsReady(!!stepValues);
  }, [stepValues, active, validationGroupRef]);

  if (!stepValues) {
    return;
  }

  const StepTitle = () => {
    return (
      <>
        {mixed ? (
          <>
            Mixed Order: <em>Will Call</em>
          </>
        ) : (
          <>Will Call</>
        )}
      </>
    );
  };

  return (
    <CheckoutStep
      title={<StepTitle />}
      dirty={dirty}
      active={active}
      onEdit={onEdit}
    >
      {active ? (
        <div className="checkout-step_content step-will-call-details">
          <ValidationGroup ref={validationGroupRef}>
            {stepValues?.shipments?.map(
              ({
                warehouse,
                shipDate,
                requiredShipDate,
                estimatedShipPickUpDate,
                note,
                items,
              }) => {
                return (
                  <div
                    key={`step-will-call-details-${warehouse.id}`}
                    className="step-will-call-details_shipping-group"
                  >
                    <div className="step-will-call-details_date">
                      <h2 className="step-will-call-details_title">
                        <i className="icon icon-calendar">
                          <IconCalendar />
                        </i>
                        <span>
                          Availability Date for Will Call{' '}
                          <em>{warehouse.name}</em>
                        </span>
                        <ChipShipment items={items} />
                      </h2>

                      <p className="step-will-call-details_description">
                        Select a time to retrieve your will call order.
                      </p>

                      <ul className="step-will-call-details_date_selector">
                        <li className="step-will-call-details_date_selector_option">
                          <input
                            type="radio"
                            id="ship_date_asap"
                            name={`ship_date[${warehouse.id}]`}
                            value="asap"
                            onChange={handleShipDateChange}
                            defaultChecked={
                              !shipDate || 'asap' === shipDate ? true : false
                            }
                          />
                          <label htmlFor="ship_date_asap">Same day</label>
                        </li>
                        <li className="step-will-call-details_date_selector_option">
                          <input
                            type="radio"
                            id="ship_date_manual"
                            name={`ship_date[${warehouse.id}]`}
                            value="manual"
                            onChange={handleShipDateChange}
                            defaultChecked={
                              shipDate && 'asap' !== shipDate ? true : false
                            }
                          />
                          <label htmlFor="ship_date_manual">
                            On a future date
                          </label>
                        </li>
                        {shipDate === 'manual' && (
                          <li>
                            <div className="date-field">
                              <DateBox
                                type="date"
                                label="Date"
                                labelMode="hidden"
                                name={`ship_date_manual[${warehouse.id}]`}
                                min={pickupDay}
                                defaultValue={requiredShipDate}
                                displayFormat="shortdate"
                                onValueChanged={handleDateChange}
                                disabledDates={getDisabledDates}
                              >
                                <Validator>
                                  <RequiredRule message="Date is required" />
                                </Validator>
                              </DateBox>
                            </div>
                          </li>
                        )}
                      </ul>
                    </div>

                    <div className="step-will-call-details_pickup">
                      <div>
                        <h3 className="step-will-call-details_name">
                          {warehouse.name}
                        </h3>
                        {estimatedShipPickUpDate && (
                          <p className="step-will-call-details_description">
                            Order available for pickup in Will Call window on{' '}
                            <strong>
                              {deliveryDayFormat.format(
                                Date.parse(estimatedShipPickUpDate),
                              )}
                            </strong>
                          </p>
                        )}
                      </div>

                      <TextArea
                        name={`note[${warehouse.id}]`}
                        width={400}
                        label="Note"
                        labelMode="outside"
                        placeholder="Enter any notes or attention."
                        defaultValue={note}
                        onValueChanged={handleNoteChange}
                      ></TextArea>
                    </div>
                  </div>
                );
              },
            )}
          </ValidationGroup>
          <div className="checkout-step_actions">
            <Button
              className="btn btn-primary"
              onClick={handleValidate}
              disabled={!isReady}
            >
              Continue
            </Button>
          </div>
        </div>
      ) : (
        <>
          {dirty && (
            <div className="checkout-step_content step-will-call-details">
              {stepValues.shipments.map(
                ({ warehouse, estimatedShipPickUpDate, note, items }, idx) => {
                  return (
                    <div
                      key={`shipment-${idx + 1}`}
                      className="step-will-call-details_summary"
                    >
                      <div className="step-will-call-details_summary_warehouse">
                        <h3 className="step-will-call-details_name">
                          <span className="flex gap-3">
                            <span>{warehouse.name}</span>
                            <ChipShipment items={items} />
                          </span>
                        </h3>
                        {estimatedShipPickUpDate && (
                          <p className="step-will-call-details_description">
                            Order available for pickup in Will Call window on{' '}
                            <strong>
                              {deliveryDayFormat.format(
                                Date.parse(estimatedShipPickUpDate),
                              )}
                            </strong>
                          </p>
                        )}
                      </div>

                      {note && (
                        <div className="step-will-call-details_summary_note">
                          <h3>Note</h3>
                          <p>{note}</p>
                        </div>
                      )}
                    </div>
                  );
                },
              )}
            </div>
          )}
        </>
      )}
    </CheckoutStep>
  );
}
