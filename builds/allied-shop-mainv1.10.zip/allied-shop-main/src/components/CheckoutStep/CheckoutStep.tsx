
import { ReactNode, useEffect, useMemo, useState } from 'react';
import './CheckoutStep.scss';

interface CheckoutStepProps {
  title: string | ReactNode;
  active: boolean;
  dirty: boolean;
  children: ReactNode;
  onEdit: () => void;
  hideEdit?: boolean;
}

export default function CheckoutStep({
  title,
  active = false,
  dirty = false,
  children,
  onEdit,
  hideEdit = false,
}: CheckoutStepProps) {
  const [isOpen, setIsOpen] = useState<boolean>(active);
  const [isDirty, setIsDirty] = useState<boolean>(dirty);

  useEffect(() => {
    setIsOpen(active);
  }, [active]);

  useEffect(() => {
    setIsDirty(dirty);
  }, [dirty]);

  const showEdit = useMemo(() => {
    return !isOpen && isDirty && !hideEdit;
  }, [isOpen, isDirty, hideEdit]);

  return (
    <dl className="checkout-step" aria-expanded={isOpen} role="tab">
      <dt>
        {title}
        {showEdit && (
          <button type="button" onClick={onEdit}>
            Edit
          </button>
        )}
      </dt>
      <dd>{children}</dd>
    </dl>
  );
}
