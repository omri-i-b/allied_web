import { ShippingCombination } from '../../types/customer';
import { Warehouse } from '../../types/products';
import {ReactComponent as IconTruck} from '../../assets/icons/truck.svg';
import CheckoutShipment from './CheckoutShipment';
import { useCallback, useState } from 'react';
import { CartItem } from '../../types/cart';

export type Shipment = {
  warehouse: Warehouse;
  weight?: number;
  combination?: ShippingCombination;
  shipDate?: string;
  requiredShipDate?: string;
  estimatedShipPickUpDate?: string;
  freightAccount?: string;
  note?: string;
  thirdParty?: Boolean;
  items: CartItem[];
};

interface CheckoutStepShippingOptionsProps {
  active: boolean;
  activeShipment?: number;
  shipments?: Shipment[];
  onUpdate?: (_shipments: Shipment[]) => void;
  onEdit?: (_idx: number) => void;
  onNextShipment?: (_ready:boolean) => void;
}

export default function CheckoutStepShippingOptions({
  active,
  activeShipment = 0,
  shipments = [],
  onEdit = () => {},
  onUpdate = () => {},
  onNextShipment = () => {},
}: CheckoutStepShippingOptionsProps) {
  const [isDirty, setIsDirty] = useState(false);

  const handleUpdate = useCallback(
    (shipment: Shipment, idx: number) => {
      setIsDirty(true);

      const newShipments = [...shipments];

      newShipments[idx] = shipment;

      if (onUpdate) {
        onUpdate(newShipments);
      }
    },
    [shipments, onUpdate],
  );

  return (
    <div className="checkout-step-shipping-options">
      {active ? (
        <>
          <h2 className="checkout-step-shipping-options_title">
            <span>
              Shipping Options <em>(2/2)</em>
            </span>
          </h2>

          <div className="step-delivery-options_shipping-groups">
            <div className="step-delivery-options_shipping-groups_header">
              <h2 className="step-delivery-options_shipping-groups_title">
                <i className="icon icon-truck">
                  <IconTruck />
                </i>{' '}
                Shipping
              </h2>
              <p className="step-delivery-options_shipping-groups_count">
                out of {shipments?.length} warehouses
              </p>
            </div>
          </div>

          {shipments?.map((shipment, idx) => {
            const packageCount = idx + 1;
            return (
              <CheckoutShipment
                key={`checkout-step-shipping-options-${shipment.warehouse.id}`}
                active={activeShipment === idx}
                packageCount={packageCount}
                shipment={shipment}
                onUpdate={(shipment) => {
                  handleUpdate(shipment, idx);
                }}
                onEdit={() => {
                  onEdit(idx);
                }}
                onComplete={(complete:boolean = true) => {
                  if (activeShipment === idx) {
                    onNextShipment(complete);
                  }
                }}
              />
            );
          })}
        </>
      ) : (
        <>
          <dl className="checkout-step-shipping-options_group">
            <dt>Shipping Options</dt>
            {isDirty && (
              <dd>
                <div className="step-delivery-options_shipping-groups">
                  <div className="step-delivery-options_shipping-groups_header">
                    <h2 className="step-delivery-options_shipping-groups_title">
                      <i className="icon icon-truck">
                        <IconTruck />
                      </i>{' '}
                      Shipping
                    </h2>
                    <p className="step-delivery-options_shipping-groups_count">
                      out of {shipments?.length} warehouses
                    </p>
                  </div>
                </div>

                {shipments.length > 0 && (
                  <>
                    {shipments.map((shipment, idx) => {
                      const packageCount = idx + 1;
                      return (
                        <CheckoutShipment
                          key={`checkout-step-shipping-options-${shipment.warehouse.id}`}
                          active={false}
                          packageCount={packageCount}
                          shipment={shipment}
                          onEdit={() => {
                            onEdit(idx);
                          }}
                        />
                      );
                    })}
                  </>
                )}
              </dd>
            )}
          </dl>
        </>
      )}
    </div>
  );
}
