
import CheckoutStep from '../../components/CheckoutStep/CheckoutStep';
import { Address } from '../../types/customer';
import { Button } from 'devextreme-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import CheckoutStepShippingAddress from './CheckoutStepShippingAddress';
import CheckoutStepShippingOptions, {
  Shipment,
} from './CheckoutStepShippingOptions';
import { useCart } from '../../contexts/CartProvider';
import { Warehouse } from '../../types/products';

interface CheckoutStepShippingDetailsProps {
  mixed: boolean;
  active: boolean;
  dirty: boolean;
  values?: ShippingStepValues;
  onNext: () => void;
  onEdit: () => void;
  onUpdate: (_values: any) => void;
}

export interface ShippingStepValues {
  selectedAddress: Address;
  shipments: Shipment[];
}

export default function CheckoutStepShippingDetails({
  mixed = false,
  active = false,
  dirty = false,
  values,
  onNext,
  onEdit,
  onUpdate,
}: CheckoutStepShippingDetailsProps) {
  const STEP_ADDRESS = 'address';
  const STEP_OPTIONS = 'options';

  const { items, shippingTerm } = useCart();

  const [stepValues, setStepValues] = useState<ShippingStepValues | undefined>(
    values,
  );
  const [isReady, setIsReady] = useState(false);

  const [currentStep, setCurrentStep] = useState(STEP_ADDRESS);
  const [currentShipment, setCurrentShipment] = useState(0);
  const [currentShipmentComplete, setCurrentShipmentComplete] = useState(false);

  /**
   * Convert the cart items into shipping packages
   */
  const shippingPackages = useMemo(() => {
    var shipments: Shipment[] = [];

    if (!shippingTerm) {
      return [];
    }

    // Filter out any non-shipping items
    var filteredItems = items.filter(
      (item) => item.shipTermId === shippingTerm.id,
    );

    // Group the items by Warhouse name
    var filteredItemsByWarehouse = Object.groupBy(
      filteredItems,
      ({ warehouseCode }) => warehouseCode,
    );

    // Convert into a shipment
    Object.keys(filteredItemsByWarehouse).forEach((warehouse) => {
      const shippingItems = filteredItemsByWarehouse[warehouse];

      if (!shippingItems) {
        return;
      }

      const weight = shippingItems.reduce(
        (total: number, item: { weight: number }) => total + item.weight,
        0,
      );

      // Use the data from the first item
      const firstItem = shippingItems[0];

      // Create a shipment
      shipments.push({
        items: shippingItems,
        warehouse: {
          id: firstItem.warehouseId,
          code: firstItem.warehouseCode,
          name: firstItem.warehouseName,
        } as Warehouse,
        weight,
      });
    });

    return shipments;
  }, [items, shippingTerm]);

  const updateAddress = useCallback(
    (address: Address) => {
      if (address.id !== stepValues?.selectedAddress?.id) {
        const newValues = {
          ...stepValues,
          selectedAddress: address,
        } as ShippingStepValues;

        setStepValues(newValues);

        if (onUpdate) {
          onUpdate(newValues);
        }
      }
    },
    [stepValues, onUpdate],
  );

  const handleActivateAddress = useCallback(() => {
    setCurrentStep(STEP_ADDRESS);
    onEdit();
  }, [onEdit]);

  const updateShipments = useCallback(
    (shipments: Shipment[]) => {
      const newValues = {
        ...stepValues,
        shipments,
      } as ShippingStepValues;

      setStepValues(newValues);

      if (onUpdate) {
        onUpdate(newValues);
      }
    },
    [stepValues, onUpdate],
  );

  const handleActivateOptions = useCallback(
    (shipmentIdx: number) => {
      setCurrentStep(STEP_OPTIONS);
      setCurrentShipment(shipmentIdx);
      onEdit();
    },
    [onEdit],
  );

  const handleNextShipment = useCallback((ready:boolean) => {
    setCurrentShipmentComplete(ready);
  }, []);

  const handleContinue = useCallback(() => {
    // If the Step is the address, then move to the options
    if (STEP_ADDRESS === currentStep) {
      setCurrentStep(STEP_OPTIONS);
      return;
    }

    // If the Step is the Options, then check if the currentShipment is ready
    if (STEP_OPTIONS === currentStep) {
      if (currentShipment < Math.max(0, shippingPackages.length - 1)) {
        setCurrentShipmentComplete(false);
        setCurrentShipment(currentShipment + 1);
      } else {
        onNext();
      }
      return;
    }

  }, [onNext, currentStep, currentShipment, shippingPackages]);

  /**
   * On load setup the values if none passed
   */
  useEffect(() => {
    if (
      (!stepValues?.shipments || !stepValues?.shipments.length) &&
      shippingPackages.length
    ) {
      const newValues = {
        ...stepValues,
        shipments: shippingPackages,
      } as ShippingStepValues;

      setStepValues(newValues);

      if (onUpdate) {
        onUpdate(newValues);
      }
    }
  }, [shippingPackages, stepValues, onUpdate]);

  // Allow moving to next step
  useEffect(() => {
    if (STEP_ADDRESS === currentStep) {
      setIsReady(!!stepValues?.selectedAddress);
      return;
    }

    if (STEP_OPTIONS === currentStep) {
      setIsReady(currentShipmentComplete);
      return;
    }

    setIsReady(false);
  }, [stepValues, currentStep, currentShipmentComplete]);

  const StepTitle = () => {
    return (
      <>
        {mixed ? (
          <>
            Mixed Order: <em>Shipping</em>
          </>
        ) : (
          <>Shipping</>
        )}
      </>
    );
  };

  return (
    <CheckoutStep
      title={<StepTitle />}
      dirty={dirty}
      active={active}
      onEdit={onEdit}
      hideEdit={true}
    >
      {active ? (
        <div className="checkout-step_content step-shipping-details">
          <CheckoutStepShippingAddress
            selectedAddress={stepValues?.selectedAddress}
            active={STEP_ADDRESS === currentStep}
            onSelect={updateAddress}
            onEdit={handleActivateAddress}
          />

          <CheckoutStepShippingOptions
            shipments={stepValues?.shipments}
            active={STEP_OPTIONS === currentStep}
            activeShipment={currentShipment}
            onUpdate={updateShipments}
            onEdit={handleActivateOptions}
            onNextShipment={handleNextShipment}
          />

          <div className="checkout-step_actions">
            <Button
              className="btn btn-primary"
              onClick={handleContinue}
              disabled={!isReady}
            >
              Continue
            </Button>
          </div>
        </div>
      ) : (
        <>
          {dirty && (
            <div className="checkout-step_content step-shipping-details">
              <CheckoutStepShippingAddress
                selectedAddress={stepValues?.selectedAddress}
                active={false}
                onEdit={handleActivateAddress}
              />

              <CheckoutStepShippingOptions
                shipments={stepValues?.shipments}
                active={false}
                onEdit={handleActivateOptions}
              />
            </div>
          )}
        </>
      )}
    </CheckoutStep>
  );
}
