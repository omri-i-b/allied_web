
import { useCallback, useEffect, useState, useRef } from 'react';
import { getAllThirdPartyAddresses, saveAddress } from '../../actions';
import { useCart } from '../../contexts/CartProvider';
import { Address } from '../../types/customer';
import CheckoutStep from '../../components/CheckoutStep/CheckoutStep';
import CheckoutAddressList from '../../components/CheckoutStep/CheckoutAddressList';
import { ValidationGroup } from 'devextreme-react/validation-group';
import { Validator, RequiredRule } from 'devextreme-react/validator';
import { useModal } from '../../contexts/ModalProvider';
import { Button } from 'devextreme-react/button';
import { CheckBox } from 'devextreme-react/check-box';
import { TextBox } from 'devextreme-react/text-box';
import ModalEditAddress from '../Modal/ModalEditAddress';
import ModalSelectAddress from '../Modal/ModalSelectAddress';
import { useDebouncedCallback } from 'use-debounce';
import { useToast } from '../../contexts/ToastProvider';
import { ADDRESS_TYPE_THIRD_PARTY } from '../../constants';
import {ReactComponent as IconInfo} from '../../assets/icons/info-fill.svg';

interface CheckoutStepOrderDetailsProps {
  active: boolean;
  dirty: boolean;
  values?: any;
  onNext: () => void;
  onEdit: () => void;
  onUpdate: (_values: any) => void;
}

export interface ReviewStepValues {
  purchaseOrder: string;
  thirdParty: boolean;
}

export default function CheckoutStepOrderDetails({
  active,
  dirty,
  values,
  onNext,
  onEdit,
  onUpdate,
}: CheckoutStepOrderDetailsProps) {
  const {
    hasThirdParty,
    billingAddress,
    thirdPartyAddress,
    setThirdPartyAddress,
    allowThirdParty,
  } = useCart();
  const { openModal } = useModal();
  const { createToast } = useToast();
  const [thirdPartyAddresses, setThirdPartyAddresses] = useState<Address[]>([]);

  const [isReady, setIsReady] = useState(false);
  const [stepValues, setStepValues] = useState<ReviewStepValues | undefined>(
    values,
  );

  const validationGroupRef = useRef<ValidationGroup>(null);

  useEffect(() => {
    const fetchData = async () => {
      const data = await getAllThirdPartyAddresses();
      if (data) {
        setThirdPartyAddresses(data);
      }
    };
    fetchData();
  }, []);

  const handlePurchaseOrderChange = useDebouncedCallback((value: string) => {
    const newValues = Object.assign({}, stepValues, {
      purchaseOrder: value,
    });

    setStepValues(newValues);

    if (onUpdate) {
      onUpdate(newValues);
    }
  }, 250);

  const handleThirdPartyChanged = useCallback(
    (value: boolean | null) => {
      const newValues = Object.assign({}, stepValues, {
        thirdParty: !!value,
      });

      setStepValues(newValues);

      if (onUpdate) {
        onUpdate(newValues);
      }
    },
    [stepValues, onUpdate],
  );

  const updateAddress = useCallback(
    (address: Address | undefined) => {
      if (address) {
        setThirdPartyAddress(address);
      }
    },
    [setThirdPartyAddress],
  );

  /**
   * Update the selected address
   */
  const handleSelect = useCallback(
    (address: Address) => {
      updateAddress(address);
    },
    [updateAddress],
  );

  useEffect(() => {
    if (!active) {
      return;
    }

    const validation = validationGroupRef.current?.instance.validate();

    if (!validation?.isValid) {
      setIsReady(false);
      
      if (validation?.brokenRules) {
        const first = (validation.brokenRules[0] as any).validator;

        setTimeout(() => {
          first.focus();
        }, 250);
      }
      return;
    }

    setIsReady(!!stepValues);
  }, [stepValues, active, validationGroupRef]);

  // Refresh the Third Party Address Data
  const refreshAddressList = useCallback(
    async (selectedId?: number) => {
      const data = await getAllThirdPartyAddresses();

      if (data) {
        setThirdPartyAddresses(data);

        if (selectedId) {
          const newAddress = data.find((a) => a.id === selectedId);

          if (!newAddress) {
            return;
          }

          updateAddress(newAddress);
        }
      }
    },
    [setThirdPartyAddresses, updateAddress],
  );

  /**
   * Save the New Address
   */
  const handleSaveAddress = useCallback(
    async (verifiedAddress: Address) => {
      const savedAddressId = await saveAddress(
        verifiedAddress.name,
        verifiedAddress.street1,
        verifiedAddress.street2 ?? '',
        verifiedAddress.city,
        verifiedAddress.state,
        verifiedAddress.postalCode,
        verifiedAddress.isVerified,
        ADDRESS_TYPE_THIRD_PARTY,
      );

      if (savedAddressId) {
        setTimeout(() => {
          refreshAddressList(savedAddressId);
        }, 500);
      } else {
        createToast(<>There was a problem creating the address</>, 'error');
      }
    },
    [refreshAddressList, createToast],
  );

  // Add new address
  const handleAddAddress = useCallback(() => {
    openModal(
      <ModalEditAddress onComplete={handleSaveAddress} />,
      'Add new third party billing address',
      ['modal__edit-address'],
    );
  }, [openModal, handleSaveAddress]);

  // Select from saved addresses
  const handleShowLocationModal = useCallback(() => {
    openModal(
      <ModalSelectAddress addressList={thirdPartyAddresses} />,
      'Select third party billing address',
      ['modal__select-address'],
    );
  }, [openModal, thirdPartyAddresses]);

  return (
    <CheckoutStep
      title="Order Details"
      dirty={dirty}
      active={active}
      onEdit={onEdit}
    >
      {active ? (
        <div className="checkout-step_content step-order-details">
          <ValidationGroup ref={validationGroupRef}>
            <div className="step-order-details_purchase-order">
              <div className="step-order-details_purchase-order_header">
                <h2 className="step-order-details_title">Purchase Order</h2>
                <p className="step-order-details_description">
                  Enter your authorized purchase order number, the PO and
                  payment instruction will appear on the invoice.
                </p>
              </div>

              <TextBox
                width={400}
                label="PO Number *"
                labelMode="outside"
                maxLength={25}
                valueChangeEvent="input"
                onValueChange={handlePurchaseOrderChange}
                defaultValue={stepValues?.purchaseOrder}
              >
                <Validator>
                  <RequiredRule message="PO Number is required" />
                </Validator>
              </TextBox>
            </div>
          </ValidationGroup>
          <div className="step-order-details_billing">
            <h2 className="step-order-details_title">
              Billing Address
              <i className="icon icon-info" data-tooltip="This is a tooltip">
                <IconInfo />
              </i>
            </h2>

            {billingAddress && (
              <address className="step-order-details_billing_address">
                {billingAddress.name}
                <br />
                {billingAddress.street1}
                <br />
                {billingAddress.street2 && (
                  <>
                    {billingAddress.street2}
                    <br />
                  </>
                )}
                {billingAddress.city}, {billingAddress.state}{' '}
                {billingAddress.postalCode}
              </address>
            )}
          </div>
          {hasThirdParty && allowThirdParty && (
            <div className="step-delivery-options_third_party">
              <div className="step-delivery-options_third_party_header">
                <h2 className="step-delivery-options_third_party_title">
                  Third Party Billing (optional)
                  <i className="icon icon-info" data-tooltip="This is a tooltip">
                    <IconInfo />
                  </i>
                </h2>
                {stepValues?.thirdParty && (
                  <button
                    type="button"
                    className="btn btn-link btn-add-new"
                    onClick={handleAddAddress}
                  >
                    + Add new address
                  </button>
                )}
              </div>

              <CheckBox
                name={`third_party`}
                iconSize={14}
                text="Freight is being billed to a third party."
                defaultValue={!!stepValues?.thirdParty}
                onValueChange={handleThirdPartyChanged}
              ></CheckBox>
            </div>
          )}
          {stepValues?.thirdParty && (
            <div className="checkout-step_content step-delivery-address">
              <CheckoutAddressList
                addressList={thirdPartyAddresses}
                selectedAddress={thirdPartyAddress}
                onSelect={handleSelect}
                onShowLocationModal={handleShowLocationModal}
                onAddAddress={handleAddAddress}
              />
            </div>
          )}

          <div className="checkout-step_actions">
            <Button
              className="btn btn-primary"
              onClick={onNext}
              disabled={!isReady}
            >
              Review Order
            </Button>
          </div>
        </div>
      ) : (
        <>
          {dirty && (
            <div className="checkout-step_content step-order-details">
              <dl className="step-order-details_review">
                <div>
                  <dt>PO Number</dt>
                  <dd>{stepValues?.purchaseOrder}</dd>
                </div>
                {stepValues?.thirdParty ? (
                  <div>
                    <dt>Third Party BillingAddress</dt>
                    <dd>
                      {thirdPartyAddress && (
                        <address>
                          {thirdPartyAddress.name}
                          <br />
                          {thirdPartyAddress.street1}
                          <br />
                          {thirdPartyAddress.street2 && (
                            <>
                              {thirdPartyAddress.street2}
                              <br />
                            </>
                          )}
                          {thirdPartyAddress.city}, {thirdPartyAddress.state}{' '}
                          {thirdPartyAddress.postalCode}
                        </address>
                      )}
                    </dd>
                  </div>
                ) : (
                  <div>
                    <dt>Billing Address</dt>
                    <dd>
                      {billingAddress && (
                        <address>
                          {billingAddress.name}
                          <br />
                          {billingAddress.street1}
                          <br />
                          {billingAddress.street2 && (
                            <>
                              {billingAddress.street2}
                              <br />
                            </>
                          )}
                          {billingAddress.city}, {billingAddress.state}{' '}
                          {billingAddress.postalCode}
                        </address>
                      )}
                    </dd>
                  </div>
                )}
              </dl>
            </div>
          )}
        </>
      )}
    </CheckoutStep>
  );
}
