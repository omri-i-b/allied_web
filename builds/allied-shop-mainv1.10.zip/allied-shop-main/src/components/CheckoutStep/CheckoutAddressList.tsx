import { ChangeEvent, useCallback, useMemo } from 'react';
import { Address } from '../../types/customer';
import { Button } from 'devextreme-react/button';

interface CheckoutAddressListProps {
  addressList: Address[];
  selectedAddress?: Address;
  maxDisplay?: number;
  onSelect?: (_address: Address) => void;
  onShowLocationModal: () => void;
  onAddAddress: () => void;
}

export default function CheckoutAddressList({
  addressList,
  selectedAddress,
  maxDisplay = 3,
  onSelect = (_address) => {},
  onShowLocationModal,
  onAddAddress,
}: CheckoutAddressListProps) {
  const shortList = useMemo(() => {
    const tmpAddressList = [...addressList];

    if (selectedAddress) {
      const idx = tmpAddressList.findIndex((a) => a.id === selectedAddress.id);

      if (idx > maxDisplay) {
        tmpAddressList.splice(idx, 1);
        tmpAddressList.unshift(selectedAddress);
      }
    }

    return tmpAddressList.slice(0, maxDisplay);
  }, [addressList, selectedAddress, maxDisplay]);

  const handleAddressChange = useCallback(
    (e: ChangeEvent<HTMLInputElement>) => {
      const value = parseInt(e.target.value, 10);
      const newAddress = addressList.find((a) => value === a.id);

      if (newAddress) {
        onSelect(newAddress);
      }
    },
    [addressList, onSelect],
  );

  return (
    <>
      <ul className="checkout-address_list">
        {shortList.length > 0 ? (
          <>
            {shortList.map((address) => (
              <li
                key={`address-${address.id}`}
                className="checkout-address_option"
              >
                <input
                  type="radio"
                  id={`address-${address.id}`}
                  value={address.id}
                  name="delivery_address"
                  onChange={handleAddressChange}
                  checked={address.id === selectedAddress?.id}
                />
                <label htmlFor={`address-${address.id}`}>
                  <address>
                    <strong>{address.name}</strong>
                    <br />
                    {address.street1}
                    <br />
                    {address.street2 && (
                      <>
                        {address.street2}
                        <br />
                      </>
                    )}
                    {address.city}, {address.state} {address.postalCode}
                  </address>
                </label>
              </li>
            ))}
          </>
        ) : (
          <div className="checkout-address_empty">
            <div className="checkout-address_empty_text">
              There are no addresses saved at the moment. Add a new address to
              proceed.
            </div>
            <Button className="btn btn-primary" onClick={onAddAddress}>
              Add new address
            </Button>
          </div>
        )}
      </ul>
      <button
        type="button"
        className="btn btn-link btn-select-address"
        onClick={onShowLocationModal}
      >
        + Select from saved addresses
      </button>
    </>
  );
}
