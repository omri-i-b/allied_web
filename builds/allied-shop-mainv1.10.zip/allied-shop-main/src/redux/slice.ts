import { UserState } from '../types/user';
import { createSlice, PayloadAction } from '@reduxjs/toolkit'

const initialState: UserState = {
  id: 0,
  customerId: 0,
  customerName: '',
  customerCode: '',
  organizationId: 0,
  warehouseId: 0,
  allowChangeWarehouse: false,
  accessToken: '',
  email: '',
  firstName: '',
  lastName: '',
  resetPassword: false,
  status: 'unauthenticated'
}

export const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    setUser: (state, action: PayloadAction<UserState>) => {
      return { ...state, ...action.payload };
    },
    updateUser: (state, action: PayloadAction<Partial<UserState>>) => {
      return { ...state, ...action.payload };
    },
    logoutUser: () => {
      return initialState; // Reset to initial state on logout
    },
  },
})

// Action creators are generated for each case reducer function
export const {
  setUser,
  updateUser,
  logoutUser
} = userSlice.actions

export default userSlice.reducer