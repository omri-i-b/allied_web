// src/store.ts
import { configureStore } from '@reduxjs/toolkit';
import userReducer from './slice';
import {loadState, saveState} from '../utils/localStorage';


const persistedState = loadState();
const store = configureStore({
  reducer: userReducer,
  preloadedState: persistedState
});

store.subscribe(() => {
  saveState(store.getState())
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;

export default store;
