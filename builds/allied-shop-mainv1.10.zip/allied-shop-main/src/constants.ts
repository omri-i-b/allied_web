// SESSION DATA
export const SESSION_CART_ADDDRESS = 'SESSION_CART_ADDRESS';

// IMAGES
export const PARTS_IMAGE_BASE = 'Part/Image?';
// export const PARTS_IMAGE_BASE = 'parts';


// SEARCH
export const FACET_CATEGORY = 'partCategory';
export const FACET_SUBCATEGORY = 'partCategoryId_PartShapeId';
export const FACET_GRADE = 'partGrade';
export const FACET_SHAPE='partShape';
export const FACET_SIZE1='partSize1';
export const FACET_SIZE2='partSize2';
export const FACET_SIZE3='partSize3';
export const FACET_SIZE4='partSize4';
export const FACET_SCHEDULE='partSchedule';
export const FACET_PRESSURE='partPressureClass';

// ADDRESS TYPES
export const ADDRESS_TYPE_BILLING = 1;
export const ADDRESS_TYPE_SHIPPING = 2;
export const ADDRESS_TYPE_THIRD_PARTY = 30;

// BASKET TYPES
export const BASKET_STATUS_ACTIVE = 1;
export const BASKET_STATUS_CONFIRMED = 2;
export const BASKET_STATUS_ACCEPTED = 3;
export const BASKET_STATUS_CANCELLED = 4;
export const BASKET_STATUS_EXCEEDED = 5;
export const BASKET_STATUS_DRAFT = 6;

// MANUFACTURER TYPES
export const MANUFACTURER_GENERIC = 'Generic';
export const MANUFACTURER_APPROVED = 'Approved';
export const MANUFACTURER_CHINESE = 'Chinese';
export const MANUFACTURER_DOMESTIC = 'Domestic';

// SHIPPING TERMS
export const SHIPPING_TERM_COLLECT = 'COL';
export const SHIPPING_TERM_WILL_CALL = 'WC';
export const SHIPPING_TERM_THIRD_PARTY = '3P';
export const SHIPPING_TERM_PREPAID = 'PP';

// AUTHENTICATION STATE
export const AUTH_STATUS_AUTHENTICATED = 'authenticated';
export const AUTH_STATUS_UNAUTHENTICATED = 'unauthenticated';
export const AUTH_STATUS_LOADING = 'loading';

// ORDER STATUS
export const ORDER_STATUS_COMPLETED = 'Completed';
export const ORDER_STATUS_PENDING = 'Pending';
export const ORDER_STATUS_CANCELLED = 'Cancelled';
export const ORDER_STATUS_CLOSED = 'Closed';
export const ORDER_STATUS_CONFIRMED = 'Confirmed';
export const ORDER_STATUS_PARTIAL_COMPLETED = 'Partial Completed';
export const ORDER_STATUS_REQUEST_TO_CANCEL = 'Request To Cancel';

export const ERROR_CART_THRESHOLD = 'ERROR_CART_THRESHOLD';
export const ERROR_CART_QUANTITY = 'ERROR_CART_QUANTITY';
export const ERROR_CART_NOT_ADDED = 'ERROR_CART_NOT_ADDED';

// STATES
export const STATES = [
  {
    name: 'Alabama',
    abbreviation: 'AL',
  },
  {
    name: 'Alaska',
    abbreviation: 'AK',
  },
  {
    name: 'Arizona',
    abbreviation: 'AZ',
  },
  {
    name: 'Arkansas',
    abbreviation: 'AR',
  },
  {
    name: 'California',
    abbreviation: 'CA',
  },
  {
    name: 'Colorado',
    abbreviation: 'CO',
  },
  {
    name: 'Connecticut',
    abbreviation: 'CT',
  },
  {
    name: 'Delaware',
    abbreviation: 'DE',
  },
  {
    name: 'District Of Columbia',
    abbreviation: 'DC',
  },
  {
    name: 'Florida',
    abbreviation: 'FL',
  },
  {
    name: 'Georgia',
    abbreviation: 'GA',
  },
  {
    name: 'Hawaii',
    abbreviation: 'HI',
  },
  {
    name: 'Idaho',
    abbreviation: 'ID',
  },
  {
    name: 'Illinois',
    abbreviation: 'IL',
  },
  {
    name: 'Indiana',
    abbreviation: 'IN',
  },
  {
    name: 'Iowa',
    abbreviation: 'IA',
  },
  {
    name: 'Kansas',
    abbreviation: 'KS',
  },
  {
    name: 'Kentucky',
    abbreviation: 'KY',
  },
  {
    name: 'Louisiana',
    abbreviation: 'LA',
  },
  {
    name: 'Maine',
    abbreviation: 'ME',
  },
  {
    name: 'Maryland',
    abbreviation: 'MD',
  },
  {
    name: 'Massachusetts',
    abbreviation: 'MA',
  },
  {
    name: 'Michigan',
    abbreviation: 'MI',
  },
  {
    name: 'Minnesota',
    abbreviation: 'MN',
  },
  {
    name: 'Mississippi',
    abbreviation: 'MS',
  },
  {
    name: 'Missouri',
    abbreviation: 'MO',
  },
  {
    name: 'Montana',
    abbreviation: 'MT',
  },
  {
    name: 'Nebraska',
    abbreviation: 'NE',
  },
  {
    name: 'Nevada',
    abbreviation: 'NV',
  },
  {
    name: 'New Hampshire',
    abbreviation: 'NH',
  },
  {
    name: 'New Jersey',
    abbreviation: 'NJ',
  },
  {
    name: 'New Mexico',
    abbreviation: 'NM',
  },
  {
    name: 'New York',
    abbreviation: 'NY',
  },
  {
    name: 'North Carolina',
    abbreviation: 'NC',
  },
  {
    name: 'North Dakota',
    abbreviation: 'ND',
  },
  {
    name: 'Ohio',
    abbreviation: 'OH',
  },
  {
    name: 'Oklahoma',
    abbreviation: 'OK',
  },
  {
    name: 'Oregon',
    abbreviation: 'OR',
  },
  {
    name: 'Pennsylvania',
    abbreviation: 'PA',
  },
  {
    name: 'Rhode Island',
    abbreviation: 'RI',
  },
  {
    name: 'South Carolina',
    abbreviation: 'SC',
  },
  {
    name: 'South Dakota',
    abbreviation: 'SD',
  },
  {
    name: 'Tennessee',
    abbreviation: 'TN',
  },
  {
    name: 'Texas',
    abbreviation: 'TX',
  },
  {
    name: 'Utah',
    abbreviation: 'UT',
  },
  {
    name: 'Vermont',
    abbreviation: 'VT',
  },
  {
    name: 'Virginia',
    abbreviation: 'VA',
  },
  {
    name: 'Washington',
    abbreviation: 'WA',
  },
  {
    name: 'West Virginia',
    abbreviation: 'WV',
  },
  {
    name: 'Wisconsin',
    abbreviation: 'WI',
  },
  {
    name: 'Wyoming',
    abbreviation: 'WY',
  },
];
