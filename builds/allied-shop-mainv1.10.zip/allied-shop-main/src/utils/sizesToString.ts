/**
 * Converts a number to a propert fraction string for display
 */
export function convertToFraction(value: number) {
  // First grab the whole numbers
  const wholeNumber = Math.floor(value);
  let output = '';

  if (wholeNumber) {
    output = `${wholeNumber}`;
  }

  // Next Just get the fraction piece
  const fraction = value - wholeNumber;

  if (!fraction) {
    return output;
  }

  // Find the greatest common denominator
  const gcd = function (a: number, b: number): number {
    if (b < 0.0000001) {
      return a;
    }

    return gcd(b, Math.floor(a % b));
  };

  const len = fraction.toString().length - 2;

  var denominator = Math.pow(10, len);
  var numerator = fraction * denominator;
  var divisor = gcd(numerator, denominator);

  numerator /= divisor;
  denominator /= divisor;

  output = `${output} ${numerator}/${denominator}`;

  return output;
}

/**
 * Converts a series of sizes to a string display (1 1/2" × 2" × 2 1/4")
 */
export function convertSizesToString(
  suffix = '',
  size1: number,
  size2?: number,
  size3?: number,
  size4?: number,
) {
  var output = [`${convertToFraction(size1)}${suffix}`];

  if (size2) {
    output.push(`${convertToFraction(size2)}${suffix}`);
  }

  if (size3) {
    output.push(`${convertToFraction(size3)}${suffix}`);
  }

  if (size4) {
    output.push(`${convertToFraction(size4)}${suffix}`);
  }

  return output.join(' × ');
}
