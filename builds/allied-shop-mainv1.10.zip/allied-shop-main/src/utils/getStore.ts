export const getStore = async (): Promise<any> => {
    const storeModule = await import('../redux/store'); 
    return storeModule.default;
};