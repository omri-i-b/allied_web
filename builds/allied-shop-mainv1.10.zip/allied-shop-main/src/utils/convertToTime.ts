/**
 * Convert military time to standard time with suffix 15:00:00 to 3pm
 */
export default function convertToTime(militaryTime: string) {
  const noLeadingZero = militaryTime.replace('0.', '').trim();
  const times = noLeadingZero.split(':');
  var time = '';
  var suffix = '';

  if (!times.length) {
    return militaryTime;
  }

  const hour = parseInt(times[0], 10);
  const minute = parseInt(times[1], 10);

  if (13 > hour) {
    time += hour.toString();
    suffix = 'am';
  } else {
    time += (hour - 12).toString();
    suffix = 'pm';
  }

  if (minute > 0) {
    time += `:${minute}`;
  }

  return `${time}${suffix}`;
}

/**
 * Get only the hour from military time
 */
export function getHours(militaryTime: string) {
  const noLeadingZero = militaryTime.replace('0.', '').trim();
  const times = noLeadingZero.split(':');

  if (!times.length) {
    return militaryTime;
  }

  const hour = parseInt(times[0], 10);

  return hour;
}

/**
 * Check if today is a weekday
 */
export const isWeekday = (d = new Date()) => d.getDay() % 6 !== 0;
