import { PreSearchResults, Product, searchResults } from "../types/products";
import { fetchCategories } from "../lib/categories";
import { redirect } from "react-router-dom";
import { fetchAllManufacturers, fetchAllWarehouses, fetchBestSellers, fetchFilteredProducts, fetchPreSearch, fetchProduct, fetchProductAvailability, fetchRelatedProducts, fetchSearch, fetchWarehousesWithAvailability } from "../lib/products";
import { CartItem } from "../types/cart";
import { fetchAddCartItem, fetchCart, fetchCartItemCount, fetchCartTaxes, fetchCheckout, fetchDeleteAllCartItems, fetchDeleteCartItem, fetchUpdateCartItem, fetchValidateCart, fetchValidateQuantity, fetchValidateThreshold } from "../lib/cart";
import { fetchCities, fetchConfiguration, fetchCountries, fetchStates } from "../lib/utils";
import { Address, Order, SavedCart } from "../types/customer";
import { fetchAddresses, fetchCreateAddress, fetchDeleteCart, fetchEstimatedShipPickupDate, fetchOrderById, fetchOrders, fetchReplaceCart, fetchSaveCart, fetchSavedCart, fetchSavedCarts, fetchShippingData, fetchShippingDataByTerm, fetchShippingTerms, fetchUPSAddress } from "../lib/customer";
import Allied from "../lib";
import { ADDRESS_TYPE_BILLING, ADDRESS_TYPE_SHIPPING, ADDRESS_TYPE_THIRD_PARTY } from "../constants";
import Cookies from 'js-cookie';

/**
 * Change Password Form Submit
 * @param _currentState
 * @param formData
 * @returns
 */
export async function changePassword(
  _currentState: unknown,
  formData: FormData,
) {  
  const oldPassword = formData.get('old_password') as string;
  const newPassword = formData.get('new_password') as string;
  const verifyPassword = formData.get('verify_password') as string;
  
  
  if (!oldPassword) {
    return {
      success: false,
      message: 'No old password provided',
    };
  }

  if (!newPassword) {
    return {
      success: false,
      message: 'No new password provided',
    };
  }

  if (!verifyPassword) {
    return {
      success: false,
      message: 'No confirm password provided',
    };
  }

  if (newPassword !== verifyPassword) {
    return {
      success: false,
      message: 'Passwords do not match',
    };
  }

  const response = await Allied.Authentication.changePassword(
    newPassword,
    oldPassword,
  );

  if (!response.success) {
    throw new Error('Unable to change password');
  }

  return {
    success: true,
  };
}

/**
 * Register Form Submit
 * @param _currentState
 * @param formData
 * @returns
 */
export async function register(_currentState: unknown, formData: FormData) {
  const firstName = formData.get('first_name') as string;
  const lastName = formData.get('last_name') as string;
  const company = formData.get('company_name') as string;
  const title = formData.get('title') as string;
  const address = formData.get('address') as string;
  const city = formData.get('city') as string;
  const state = formData.get('state') as string;
  const zipCode = formData.get('zip_code') as string;
  const email = formData.get('email') as string;
  const officePhone = formData.get('office_phone') as string;
  const mobilePhone = formData.get('mobile_phone') as string;

  if (!firstName) {
    return {
      success: false,
      message: 'No first name provided',
    };
  }

  if (!lastName) {
    return {
      success: false,
      message: 'No last name provided',
    };
  }

  if (!company) {
    return {
      success: false,
      message: 'No company provided',
    };
  }

  if (!title) {
    return {
      success: false,
      message: 'No title provided',
    };
  }

  if (!address) {
    return {
      success: false,
      message: 'No address provided',
    };
  }

  if (!city) {
    return {
      success: false,
      message: 'No city provided',
    };
  }

  if (!state) {
    return {
      success: false,
      message: 'No state provided',
    };
  }

  if (!zipCode) {
    return {
      success: false,
      message: 'No zipcode provided',
    };
  }

  if (!email) {
    return {
      success: false,
      message: 'No email provided',
    };
  }

  if (!mobilePhone) {
    return {
      success: false,
      message: 'No mobile phone provided',
    };
  }

  if (!officePhone) {
    return {
      success: false,
      message: 'No office phone provided',
    };
  }

  const response = await Allied.Authentication.register(
    firstName,
    lastName,
    company,
    title,
    address,
    city,
    state,
    zipCode,
    email,
    officePhone,
    mobilePhone,
  );

  if (!response) {
    return {
      success: false,
      message: 'There was a problem registering, please try again later.',
    };
  }

  return {
    success: true,
    email,
  };
}

/**
 * Gets all categories
 */
export async function getAllCategories() {
  const response = await fetchCategories();
  
  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch categories');
      }
    }

    return [];
  }

  return response.categories;
}

/**
 * Gets a category by slug
 * @param slug
 */
export async function getCategoryBySlug(slug: string) {
  const response = await fetchCategories();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch categories');
      }
    }

    return false;
  }

  const category = response.categories?.find(
    (category) => category.slug === slug,
  );

  return category;
}

/**
 * Get a category by ID
 * @param id
 */
export async function getCategoryById(id: number) {
  const response = await fetchCategories();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch categories');
      }
    }

    return false;
  }

  const category = response.categories?.find((category) => category.id === id);

  return category;
}

/**
 * Get the Best sellers by category
 */
export async function getBestSellers() {
  const response = await fetchBestSellers();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch best sellers');
      }
    }

    return false;
  }

  return response.products;
}

/**
 * Get the Best sellers by category
 */
export async function getBestSellersByCategoryId(id: number) {
  const response = await fetchBestSellers(id);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch categories');
      }
    }

    return false;
  }

  return response.products;
}

/**
 * Get the filtered product results
 */
export async function getFilteredProducts(filters: any) {
  var total: number = 0;
  var products: Product[] = [];

  const loadMore = async (page: number) => {
    const response = await fetchFilteredProducts(filters, page);

    if (!response.success) {
      if (response.error) {
        switch (response.error) {
          case 401:
            redirect('/logout');
            break;
          default:
            throw new Error('Unable to fetch categories');
        }
      }
    }

    // Set the total if there isnt one
    if (!total && response.total) {
      total = response.total;
    }

    // Merge the products
    if (response.products) {
      products = [...products, ...response.products];
    }

    // If there is more, then get the next page
    if (total > products.length) {
      await loadMore(page + 1);
    }
  };

  await loadMore(1);

  return {
    total,
    products,
  };
}

/**
 * Get the Search Results
 */
export async function getPreSearch(query: string) {
  const response = await fetchPreSearch(query);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch search results');
      }
    }

    return {
      products: undefined,
      categories: undefined,
      gradePrducts: undefined,
      shapeProducts: undefined,
      scheduleProducts: undefined,
      pressureProducts: undefined,
      size1Products: undefined,
      size2Products: undefined,
      size3Products: undefined,
      size4Products: undefined,
      suggestions: undefined,
    };
  }

  return {
    products: response.products,
    categories: response.categories,
    gradeProducts: response.gradeProducts,
    shapeProducts: response.shapeProducts,
    scheduleProducts: response.scheduleProducts,
    pressureProducts: response.pressureProducts,
    size1Products: response.size1Products,
    size2Products: response.size2Products,
    size3Products: response.size3Products,
    size4Products: response.size4Products,
    suggestions: response.suggestions,
  } as PreSearchResults;
}

/**
 * Get the Search Results
 */
export async function getSearchResults(query: string, filters?: string[][]) {
  const response = await fetchSearch(query, filters);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch search results');
      }
    }

    return {
      count: 0,
      products: [],
      facets: [],
    };
  }

  return {
    count: response.count ?? 0,
    products: response.products,
    facets: response.facets,
  } as searchResults;
}

/**
 * Get all manufacturers
 */
export async function getAllManufacturers() {
  const response = await fetchAllManufacturers();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch manufacturers');
      }
    }

    return false;
  }

  return response.manufacturers;
}

/**
 * Get all warehouses
 */
export async function getAllWarehouses() {
  const response = await fetchAllWarehouses();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch warehouses');
      }
    }

    return false;
  }

  return response.warehouses;
}

/**
 * Get all warehouses with availability for basket items
 */
export async function getWarehousesWithAvailability(basketId: number) {
  const response = await fetchWarehousesWithAvailability(basketId);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch warehouses');
      }
    }

    return false;
  }

  return response.warehouses;
}

/**
 * Get Product By ID
 */
export async function getProductById(id: number) {
  const response = await fetchProduct(id);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch product');
      }
    }

    return false;
  }

  return response.product;
}

/**
 * Get the related products by ID
 */
export async function getRelatedProductsById(id: number) {
  const response = await fetchRelatedProducts(id);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch related products');
      }
    }

    return false;
  }

  return response.products;
}

/**
 * Get product availability
 */
export async function getProductAvailability(
  id: number,
  manufacturer: number,
  qty: number = 1,
  cartId: number,
) {
  
  const response = await fetchProductAvailability(
    id,
    manufacturer,
    qty,
    cartId,
  );

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case '401':
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch availability');
      }
    } else {
      throw new Error('Unable to fetch availability2');
    }

    return {
      primary: null,
      alternates: [],
    };
  }

  return {
    primary: response.primaryWarehouse,
    alternates: response.alternateWarehouses,
  };
}

/**
 * Get Recently Visited Products
 */
export async function getRecentProducts() {
  const data = Cookies.get('RECENTLY_VISITED_PRODUCTS');

  return data ? JSON.parse(data) : undefined;
}

/**
 * Add Recent Product
 */
export async function setRecentProduct(productId: number) {
  var products: Product[] = (await getRecentProducts()) || [];
  var product = await getProductById(productId);

  if (!product) {
    return;
  }

  // Prepend the new product
  products.unshift(product);

  // Make sure we only have uniques
  products = products.filter((value, index, array) => {
    return array.findIndex((p) => p.id === value.id) === index;
  });

  // Make sure we only store 8 products
  products.splice(8);

  // Save the Cookie
  Cookies.set('RECENTLY_VISITED_PRODUCTS', JSON.stringify(products), {
    secure: false,
  });

  return products;
}

/**
 * Get All Addresses
 */
export async function getAllAddresses() {
  const unverifiedPromise = await fetchAddresses(1);
  const verifiedPromise = await fetchAddresses(2);
  const jobsitePromise = await fetchAddresses(3);

  const [unverifiedResponse, verifiedResponse, jobsiteResponse] =
    await Promise.all([unverifiedPromise, verifiedPromise, jobsitePromise]);

  if (
    !unverifiedResponse.success ||
    !verifiedResponse.success ||
    !jobsiteResponse.success
  ) {
    if (unverifiedResponse.error) {
      switch (unverifiedResponse.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch unverified addresses');
      }
    }

    if (verifiedResponse.error) {
      switch (verifiedResponse.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch verified addresses');
      }
    }

    if (jobsiteResponse.error) {
      switch (jobsiteResponse.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch jobsite addresses');
      }
    }

    return false;
  }

  var addresses: Address[] = [];

  if (unverifiedResponse.addresses) {
    addresses = addresses.concat(unverifiedResponse.addresses);
  }

  if (verifiedResponse.addresses) {
    addresses = addresses.concat(verifiedResponse.addresses);
  }

  if (jobsiteResponse.addresses) {
    addresses = addresses.concat(jobsiteResponse.addresses);
  }

  return addresses;
}

/**
 * Get the default address
 */
export async function getDefaultAddress() {
  const response = await fetchAddresses();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch addresses');
      }
    }

    return;
  }

  if (!response.addresses) {
    return;
  }

  const defaultAddress = response.addresses.find(
    (address: Address) => address.isDefault,
  );

  return defaultAddress;
}

/**
 * Get the billing address
 */
export async function getBillingAddress() {
  const response = await fetchAddresses(ADDRESS_TYPE_BILLING);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch addresses');
      }
    }

    return;
  }

  if (!response.addresses) {
    return;
  }

  const defaultAddress = response.addresses.find(
    (address: Address) => address.isDefault,
  );

  return defaultAddress;
}

/**
 * Get the third party billing address
 */
export async function getThirdPartyAddress() {
  const response = await fetchAddresses(ADDRESS_TYPE_THIRD_PARTY);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch addresses');
      }
    }

    return;
  }

  if (!response.addresses) {
    return;
  }

  const defaultAddress = response.addresses.find(
    (address: Address) => address.isDefault,
  );

  return defaultAddress;
}

/**
 * Get all the third party billing addresses
 */
export async function getAllThirdPartyAddresses() {
  const response = await fetchAddresses(ADDRESS_TYPE_THIRD_PARTY);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch addresses');
      }
    }

    return;
  }

  if (!response.addresses) {
    return;
  }

  return response.addresses;
}

/**
 * Save an address
 */
export async function saveAddress(
  name: string,
  street1: string,
  street2: string,
  city: string,
  state: string,
  postalCode: string,
  isVerified: boolean = false,
  addressTypeId: number = ADDRESS_TYPE_SHIPPING,
) {
  // Get all of the cities and states
  const statePromise = getStates();
  const cityPromise = getCities();

  const [stateData, cityData] = await Promise.all([statePromise, cityPromise]);

  if (!stateData || !cityData) {
    return false;
  }

  // Locate the selected state by the code
  const selectedState = stateData?.find((s) => s.code === state);

  if (!selectedState) {
    return false;
  }

  // Locate the selected city by the name and state ID
  const selectedCity = cityData?.find(
    (c) =>
      c.description.toUpperCase() === city.toUpperCase() &&
      c.stateId === selectedState.id,
  );

  if (!selectedCity) {
    return false;
  }

  const response = await fetchCreateAddress(
    name,
    street1,
    street2,
    selectedCity.id,
    selectedState.id,
    postalCode,
    selectedState.countryId,
    isVerified,
    addressTypeId,
  );

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to create address');
      }
    }
  }

  return response.addressId;
}

/**
 * Get UPS Validation
 */
export async function getUPSAddresses(
  address: string,
  cityName: string,
  stateCode: string,
  zipCode: string,
  countryCode: string,
) {
  const response = await fetchUPSAddress(
    address,
    cityName,
    stateCode,
    zipCode,
    countryCode,
  );

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to create address');
      }
    }
  }

  return response.addresses || [];
}

/**
 * Get the shipping terms available
 */
export async function getShippingTerms() {
  const response = await fetchShippingTerms();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch shipping terms');
      }
    }
  }

  return response.shipTerms;
}

/**
 * Get the shipping data
 */
export async function getShippingData() {
  const response = await fetchShippingData();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch shipping data');
      }
    }
  }

  return response.combinations;
}

/**
 * Get the shipping data
 */
export async function getShippingDataByTerm(shipTermId: number) {
  const response = await fetchShippingDataByTerm(shipTermId);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch shipping data');
      }
    }
  }

  return response.combinations;
}

/**
 * Get the estimated ship pick up date
 */
export async function getEstimatedShipPickUpDate(
  shipTermId: number,
  warehouseId: number,
) {
  const response = await fetchEstimatedShipPickupDate(shipTermId, warehouseId);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch estimated ship pick up date');
      }
    }
  }

  return response.estimatedShipPickUpDate;
}

/**
 * Get the shopping cart
 */
export async function getCart() {
  const response = await fetchCart();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch cart');
      }
    }
  }

  return response.cart;
}

/**
 * Get the count of cart items
 */
export async function getCartItemCount() {
  const response = await fetchCartItemCount();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch cart');
      }
    }
  }

  return response.count;
}

/**
 * Get the cart totals
 */
export async function getCartTotals() {
  const configPromise = fetchConfiguration();
  const cartPromise = fetchCart();
  const taxPromise = fetchCartTaxes();

  const [configResponse, cartResponse, taxResponse] = await Promise.all([
    configPromise,
    cartPromise,
    taxPromise,
  ]);

  if (!cartResponse.success) {
    if (cartResponse.error) {
      switch (cartResponse.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to get cart taxes');
      }
    }
  }

  if (!taxResponse.success) {
    if (taxResponse.error) {
      switch (taxResponse.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to get cart taxes');
      }
    }
  }

  if (!taxResponse.taxes || !cartResponse.cart) {
    return {
      subtotal: 0,
      tax: 0,
      discount: 0,
      total: 0,
      weight: 0,
      taxes: [],
    };
  }

  const subtotal = cartResponse.cart.items.reduce(
    (total: number, item: CartItem) => total + item.price * item.quantity,
    0,
  );
  const tax = taxResponse.taxes.reduce(
    (total: number, item: { taxAmount: number }) => total + item.taxAmount,
    0,
  );

  var discount = 0;

  if (configResponse.configuration?.flatDiscount) {
    discount = -(
      subtotal *
      (Math.ceil(configResponse.configuration?.flatDiscount) / 100)
    );
  }

  const weight = cartResponse.cart.items.reduce(
    (total: number, item: { weight: number; quantity: number; }) => total + (item.weight * item.quantity),
    0,
  );

  return {
    subtotal,
    tax,
    discount,
    total: subtotal + discount + tax,
    weight,
    taxes: taxResponse.taxes,
  };
}

/**
 * Add an item to the cart
 */
export async function addItemToCart(
  productId: number,
  manufacturerId: number,
  warehouseId: number,
  price: number,
  multiplier: number,
  quantity: number,
  shipTermId: number,
) {
  const response = await fetchAddCartItem(
    productId,
    manufacturerId,
    warehouseId,
    price,
    multiplier,
    quantity,
    shipTermId,
  );

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to add to cart');
      }
    }
  }

  return true;
}

/**
 * Update an item in the cart
 */
export async function updateItemInCart(
  cartItemId: number,
  cartId: number,
  productId: number,
  manufacturerId: number,
  warehouseId: number,
  price: number,
  multiplier: number,
  quantity: number,
  shipTermId: number,
) {
  const response = await fetchUpdateCartItem(
    cartItemId,
    cartId,
    quantity,
    price,
    multiplier,
    manufacturerId,
    warehouseId,
    productId,
    shipTermId,
  );

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to update in cart');
      }
    }
  }

  return true;
}

/**
 * Remove an item from the cart
 */
export async function removeItemFromCart(cartId: number, basketId: number) {
  const response = await fetchDeleteCartItem(cartId, basketId);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to delete Item');
      }
    }
  }

  return true;
}

/**
 * Clear the contents of a cart
 */
export async function emptyCart(basketId: number) {
  const response = await fetchDeleteAllCartItems(basketId);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to remove all items');
      }
    }
  }

  return true;
}

/**
 * Validate the Part Quantity
 */
export async function validateQuantity(
  productId: number,
  quantity: number = 1,
) {
  const response = await fetchValidateQuantity(productId, quantity);

  if (!response.success) {
    return {
      isValid: false,
    };
  }

  return {
    isValid: response.isValid,
    errors: response.errors,
  };
}

/**
 * Validate the Cart Line
 */
export async function validateThreshold(
  basketId: number,
  // basketItemId: number,
  partId: number,
  qty: number = 1,
  manufacturerTypeId: number,
  ecommerceWarehouseId: number,
  shipTermId: number,
) {
  const response = await fetchValidateThreshold(
    basketId,
    // basketItemId,
    partId,
    qty,
    manufacturerTypeId,
    ecommerceWarehouseId,
    shipTermId,
  );

  if (!response.success) {
    return false;
  }

  return response.isOverThreshold;
}

/**
 * Validate the Cart
 */
export async function validateCart(cartId: number) {
  const response = await fetchValidateCart(cartId);

  if (!response.success) {
    return {
      isValid: false,
    };
  }

  return {
    isValid: response.isValid || false,
    errors: response.errors,
  };
}

/**
 * Checkout Cart
 */
export async function checkoutCart(checkoutValues: any) {
  const response = await fetchCheckout(checkoutValues);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to checkout cart');
      }
    }
  }

  return response.orderId;
}

/**
 * Get All Orders
 */
export async function getAllOrders(statusId?: number, date?: string) {
  const response = await fetchOrders(statusId, date);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch orders');
      }
    }
  }

  return response.orders as Order[];
}

/**
 * Get Order Status List
 */
export async function getOrderStatusList() {
  const response = await fetchOrders();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch orders');
      }
    }
  }

  return response.statusList || [];
}

/**
 * Get Orders
 */
export async function getOrder(orderId: number) {
  const response = await fetchOrderById(orderId);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch order');
      }
    }
  }

  return response.order;
}

/**
 * Get All Saved Carts
 */
export async function getAllSavedCarts() {
  const response = await fetchSavedCarts();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch saved carts');
      }
    }
  }

  return response.savedCarts as SavedCart[];
}

/**
 * Get Saved Cart
 */
export async function getSavedCart(id: number) {
  const response = await fetchSavedCart(id);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch saved cart');
      }
    }
  }

  return response.savedCart;
}

/**
 * Save Cart
 */
export async function saveCart(basketId: number, notes?: string) {
  const response = await fetchSaveCart(basketId, notes);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to save cart');
      }
    }
  }

  return response;
}

/**
 * Replace Cart
 */
export async function replaceCart(basketId: number, notes?: string) {
  const response = await fetchReplaceCart(basketId, notes);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to replace cart');
      }
    }
  }

  return response;
}

/**
 * Delete Cart
 */
export async function deleteCart(basketId: number) {
  const response = await fetchDeleteCart(basketId);

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to delete cart');
      }
    }
  }

  return response;
}

/**
 * Get the Default Configuration
 */
export async function getConfiguration() {
  const response = await fetchConfiguration();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch configuration');
      }
    }
  }

  return response.configuration;
}

/**
 * Get a list of the countries
 */
export async function getCountries() {
  const response = await fetchCountries();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch countries');
      }
    }
  }

  return response.countries;
}

/**
 * Get a list of the states
 */
export async function getStates() {
  const response = await fetchStates();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch states');
      }
    }
  }

  return response.states;
}

/**
 * Get a list of cities
 */
export async function getCities() {
  const response = await fetchCities();

  if (!response.success) {
    if (response.error) {
      switch (response.error) {
        case 401:
          redirect('/logout');
          break;
        default:
          throw new Error('Unable to fetch cities');
      }
    }
  }

  return response.cities;
}

/**
 * Validate the user is authenitcated
 */
export async function validateAuth() {
  const response = await fetchConfiguration();

  if (!response.success) {
    return false;
  }

  return true;
}