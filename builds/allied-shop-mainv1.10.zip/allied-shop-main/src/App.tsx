import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginPage from './pages/login/page';
import HomePage from './pages/home/page';
import RootLayout from './pages/layout/page';
import RegisterPage from './pages/register/page';
import NotFound from './components/NotFound/NotFound';
import AccountPage from './pages/account/page';
import AddressesPage from './pages/addresses/page';
import SavedCartsPage from './pages/saved-carts/page';
import SavedCartsSinglePage from './pages/saved-carts-single/page';
import OrderHistoryPage from './pages/order-history/page';
import OrderHistorySinglePage from './pages/order-history-single/page';
import ProductsPage from './pages/products/page';
import ProductsCategoryPage from './pages/products-category/page';
import ProductsSubcategoryPage from './pages/products-subcategory/page';
import ProductPage from './pages/products-product/page';
import CartPage from './pages/cart/page';
import ChangePasswordPage from './pages/change-password/page';
import CheckoutPage from './pages/checkout/page';
import CheckoutConfirmationPage from './pages/checkout-confirmation/page';
import LogoutPage from './pages/logout/page';
import SearchPage from './pages/search/page';
import { Provider } from 'react-redux'
import store from './redux/store';
import { useEffect, useState } from 'react';
import { AUTH_STATUS_AUTHENTICATED } from './constants';
import ScrollToTop from "./components/ScrollToTop/ScrollToTop";


function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  useEffect(() => {
    const fetchIsAuthenticated = async () => {
      const { status } = store?.getState();
      setIsAuthenticated( AUTH_STATUS_AUTHENTICATED === status);
    }
    fetchIsAuthenticated();
  }, [])

  return (
    <Provider store={store}>
      <Router>
        <ScrollToTop />
        <RootLayout>
          <Routes>
            <Route path="/" element={isAuthenticated ? <HomePage /> :  <LoginPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/logout" element={<LogoutPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/account" element={<AccountPage />} />
            <Route path="/account/addresses" element={isAuthenticated ? <AddressesPage />: <LoginPage /> } />
            <Route path="/account/order-history" element={isAuthenticated ? <OrderHistoryPage /> : <LoginPage />} />
            <Route path="/account/order-history/:orderId" element={isAuthenticated ? <OrderHistorySinglePage /> : <LoginPage />} />
            <Route path="/account/saved-carts" element={isAuthenticated ? <SavedCartsPage /> : <LoginPage />} />
            <Route path="/account/saved-carts/:cartId" element={isAuthenticated ? <SavedCartsSinglePage /> : <LoginPage />} />
            <Route path="/products" element={isAuthenticated ? <ProductsPage /> : <LoginPage />} />
            <Route path="/products/:category" element={isAuthenticated ? <ProductsCategoryPage /> : <LoginPage />} />
            <Route path="/products/:category/:subcategory" element={isAuthenticated ? <ProductsSubcategoryPage /> : <LoginPage />} />
            <Route path="/products/:category/:subcategory/:productId" element={isAuthenticated ? <ProductPage /> : <LoginPage />} />
            <Route path="/products/:category/:subcategory/:productId/:product" element={isAuthenticated ? <ProductPage /> : <LoginPage />} />
            <Route path="/cart" element={isAuthenticated ? <CartPage /> : <LoginPage />} />
            <Route path="/change-password" element={isAuthenticated ? <ChangePasswordPage /> : <LoginPage />} />
            <Route path="/checkout" element={isAuthenticated ? <CheckoutPage /> : <LoginPage />} />
            <Route path="/checkout/confirmation/:orderId" element={isAuthenticated ? <CheckoutConfirmationPage /> : <LoginPage />} />
            <Route path="/search" element={isAuthenticated ? <SearchPage /> : <LoginPage />} />
            <Route path="*" element={isAuthenticated ? <NotFound /> : <LoginPage />} />
          </Routes>
        </RootLayout>
      </Router>
    </Provider>

  );
}

export default App;
