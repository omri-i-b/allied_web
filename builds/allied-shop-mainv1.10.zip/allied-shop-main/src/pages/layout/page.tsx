import { ReactNode, useEffect, useState } from 'react';
import AllProviders from '../../contexts/AllProviders';
import AlertBar from '../../components/AlertBar/AlertBar';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';
import '../../index.scss';
import { Helmet } from 'react-helmet';
import { getStore } from '../../utils/getStore';
import { AUTH_STATUS_AUTHENTICATED } from '../../constants';
import { useNavigate } from 'react-router-dom';


export default function RootLayout({
    children,
}: Readonly<{
    children: ReactNode;
}>) {
    const navigate = useNavigate();
    const [isAuthenticated, setIsAuthenticated] = useState(false);

    useEffect(() => {
        const checkIfAuthenticated = async () => {
            const store = await getStore();
            const { status, resetPassword } = store?.getState();
            setIsAuthenticated(AUTH_STATUS_AUTHENTICATED === status);

            if (resetPassword) {
                navigate('/change-password');
              }
        }
        checkIfAuthenticated();
    }, [navigate])


    return (
        <div lang="en" suppressHydrationWarning>
            <Helmet>
                <title>{'Allied Shop'}</title>
                <meta name="description" content={''} />
            </Helmet>
            <div
                className={`dx-viewport dx-device-desktop dx-device-generic dx-theme-generic dx-theme-generic-typography dx-color-scheme-carmine`}
                style={{ fontFamily: 'Inter, sans-serif' }}
            >
                <AllProviders isAuthenticated={isAuthenticated}>
                    {isAuthenticated && <AlertBar />}
                    <Header />
                    {children}
                    <Footer />
                </AllProviders>
            </div>
        </div>
    );
}
