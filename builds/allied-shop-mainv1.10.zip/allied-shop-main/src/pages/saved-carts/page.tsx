import { useEffect, useState } from 'react';
import { getAllSavedCarts } from '../../actions';
import AccountNav from '../../components/AccountNav/AccountNav';
import SavedCarts from '../../components/SavedCarts/SavedCarts';
import './Page.scss';
import ErrorComponent from '../../components/Error/Error';
import NotFound from '../../components/NotFound/NotFound';
import Loading from '../../components/Loading/Loading';
import { Helmet } from 'react-helmet';

export default function SavedCartsPage() {

  const [savedCarts, setSavedCarts] = useState<any>();
  const [hasError, setHasError] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAllSavedCarts = async () => {
      try {
        const savedCarts = await getAllSavedCarts();
        savedCarts && setSavedCarts(savedCarts);
      } catch (error) {
        setHasError(true);
        setError(error as Error);
      } finally {
        setLoading(false);
      }
    }
    fetchAllSavedCarts();
  }, [])

  const resetError = () => {
    setHasError(false);
    setError(null);
  };

  if (loading) {
    return <Loading />;
  }

  if (hasError && error) {
    return <ErrorComponent error={error} reset={resetError} />;
  }

  if (!savedCarts) {
    return <NotFound />
  }
  return (
    <main className="page page__saved-carts account">
      <Helmet>
        <title>{'Saved Carts - Allied'}</title>
        <meta name="description" content={''} />
      </Helmet>
      <div className="container">
        <AccountNav />

        <article>
          <h1 className="page__saved-carts_title">Saved Carts</h1>

          <SavedCarts serverSavedCarts={savedCarts} />
        </article>
      </div>
    </main>
  );
}
