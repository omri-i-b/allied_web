import './Page.scss';
import { getSearchResults } from '../../actions';
import Breadcrumb from '../../components/Breadcrumb/Breadcrumb';
import SearchFilters from '../../components/SearchFilters/SearchFilters';
import { SearchProvider } from '../../contexts/SearchProvider';
import SearchResults from '../../components/SearchResults/SearchResults';
import { useSearchParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import Loading from '../../components/Loading/Loading';
import ErrorComponent from '../../components/Error/Error';
import { Helmet } from 'react-helmet';
import GridCategory from '../../components/Grid/GridCategory';

export default function SearchPage() {
  const [results, setResults] = useState<any>(null);
  const [hasError, setHasError] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(false);
  const [searchParams] = useSearchParams();

  const searchQuery = searchParams.get('q') || '';

  
  useEffect(() => {
    if (!searchQuery) {
      return;
    }

    const fetchSearchResults = async () => {
      setLoading(true);

      try {
        const newResults = await getSearchResults(searchQuery);
        newResults && setResults(newResults);
      } catch (error) {
        setHasError(true);
        setError(error as Error);
      } finally {
        setLoading(false);
      }
    }
    fetchSearchResults();
  }, [searchQuery]);


  const resetError = () => {
    setHasError(false);
    setError(null);
  };

  if (loading) {
    return <Loading />;
  }

  if (hasError && error) {
    return <ErrorComponent error={error} reset={resetError} />;
  }

  const searchData = {
    serverQuery: searchParams.get('q') || '',
    serverResults: results,
  };

  const breadcrumb = [
    { title: 'All Products', path: '/products' },
    { title: 'Search Results' },
  ];

  return (
    <main className="page page__search">
      <Helmet>
        <title>{'Search Results - Allied'}</title>
        <meta name="description" content={''} />
      </Helmet>

      <Breadcrumb list={breadcrumb} />

      { (results && results.count > 0) ? (
        <SearchProvider {...searchData}>
          <div className="container">
            <SearchFilters />

            <article>
              <SearchResults />
            </article>
          </div>
        </SearchProvider>
      ) : (
        <div className="container">
          <article>
            <section className="page__search_search-empty">
              <h2 className="page__search_search-empty_title">
                We could not find anything for "{searchQuery}"
              </h2>
              <p className="page__search_search-empty_description">
                Try different search terms or check your spelling - or start shopping by category to find what you need.
              </p>

              <GridCategory />
            </section>
          </article>
        </div>
      )}
    </main>
  );
}
