import './Page.scss';
import { Product } from '../../types/products';
import Breadcrumb from '../../components/Breadcrumb/Breadcrumb';
import CardVertical from '../../components/Card/CardVertical';
import ProductCarousel from '../../components/ProductCarousel/ProductCarousel';
import { getBestSellersByCategoryId, getCategoryBySlug } from '../../actions';
import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { Subcategory } from '../../types/categories';
import ErrorComponent from '../../components/Error/Error';
import Loading from '../../components/Loading/Loading';
import { Helmet } from 'react-helmet';

export default function ProductsCategoryPage() {
  const { category: paramCategory } = useParams<string>();
  const [category, setCategory] = useState<any>();
  const [bestSellers, setBestSellers] = useState<any>();
  const [hasError, setHasError] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);

    const fetchData = async () => {
      try {
        const newCategory = await getCategoryBySlug(paramCategory ?? '');
        if(!newCategory) throw new Error('Unable to fetch category');

        const newBestSellers: Product[] = await getBestSellersByCategoryId(newCategory.id);

        setCategory(newCategory);
        setBestSellers(newBestSellers);

        setLoading(false);
      } catch (error) {
        setHasError(true);
        setError(error as Error);
        setLoading(false);
      }
    }
    fetchData();
  }, [paramCategory]);

  const resetError = () => {
    setHasError(false);
    setError(null);
  };

  if (loading) {
    return <Loading />;
  }

  if (hasError && error) {
    setLoading(false);
    return <ErrorComponent error={error} reset={resetError} />;
  }

  return (
    category &&
    <main className="page page__category">
      <Helmet>
        <title>{`${category.title} - Allied`}</title>
        <meta name="description" content={''} />
      </Helmet>
      <article>
        <Breadcrumb list={[{ title: 'All Products', path: '/products' }, { title: category.title }]} />

        <section className="category-grid">
          <div className="container">
            <h1 className="category-grid__title">{category.title}</h1>
            <p className="category-grid__product-total">
              {new Intl.NumberFormat().format(category.count)} products
            </p>

            <ul className="category-grid__grid">
              {category.subcategories.map((subcategory: Subcategory) => {
                return (
                  <li
                    key={`category-${category.slug}-subcategory-${subcategory.slug}`}
                    className="category-grid__grid_item"
                  >
                    <CardVertical
                      image={subcategory.image}
                      title={subcategory.title}
                      link={`/products/${category.slug}/${subcategory.slug}`}
                    />
                  </li>
                );
              })}
            </ul>
          </div>
        </section>
      </article>

      {bestSellers && (
        <section className="category__best-sellers">
          <div className="container">
            <h2 className="category__best-sellers_title">Best Sellers</h2>

            <ProductCarousel products={bestSellers} />
          </div>
        </section>
      )}
    </main>
  );
}
