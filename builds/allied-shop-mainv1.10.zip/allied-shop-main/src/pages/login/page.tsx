import './Page.scss';
import Login from '../../components/login/login';
import {ReactComponent as InfoIcon} from '../../assets/icons/info.svg';

export default function LoginPage() {
  return (
    <main className="page page__login">
      <div className="container">
        <Login />
        <div className="site_warning">
          <i className="icon icon-info">
            <InfoIcon/>
          </i>
          <p>
            This system is for authorized users only. System access is
            monitored. Unauthorized use will result in access removal.
            Authorized users are not allowed to share login credentials.
          </p>
        </div>
      </div>
    </main>
  );
}
