import { getBestSellers, getRecentProducts } from '../../actions';
import ProductCarousel from '../../components/ProductCarousel/ProductCarousel';
import CartContent from '../../components/CartContent/CartContent';
import './Page.scss';
import { useEffect, useState } from 'react';
import ErrorComponent from '../../components/Error/Error';
import Loading from '../../components/Loading/Loading';
import { Helmet } from 'react-helmet';

export default function CartPage() {

  const [recent, setRecent] = useState<any>();
  const [bestSellers, setBestSellers] = useState<any>();
  const [hasError, setHasError] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {

    const fetchData = async () => {
      try {
        const recentPromise = await getRecentProducts();
        recentPromise && setRecent(recentPromise)
  
        const bestSellerPromise = await getBestSellers();
        bestSellerPromise && setBestSellers(bestSellerPromise)
      } catch (error) {
        setHasError(true);
        setError(error as Error);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
    
  }, [])

  if (loading) {
    return <Loading />;
  }

  const resetError = () => {
    setHasError(false);
    setError(null);
  };

  if (hasError && error) {
    return <ErrorComponent error={error} reset={resetError} />;
  }

  return (
    <main className="page page__cart">
      <Helmet>
        <title>{'Cart - Allied'}</title>
        <meta name="description" content={''} />
      </Helmet>

      <CartContent />

      {recent && (
        <section className="cart__recently-viewed">
          <div className="container">
            <h2 className="cart__recently-viewed_title">Recently Viewed</h2>

            <ProductCarousel products={recent} />
          </div>
        </section>
      )}

      {bestSellers && (
        <section className="cart__best-sellers">
          <div className="container">
            <h2 className="cart__best-sellers_title">Best Sellers</h2>

            <ProductCarousel products={bestSellers} />
          </div>
        </section>
      )}
    </main>
  );
}
