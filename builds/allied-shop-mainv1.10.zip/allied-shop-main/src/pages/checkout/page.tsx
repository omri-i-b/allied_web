
import './Page.scss';
import OrderSummary from '../../components/OrderSummary/OrderSummary';
import {ReactComponent as IconLock} from '../../assets/icons/lock.svg';
import CheckoutStepShipping, {
  ShippingStepValues,
} from '../../components/CheckoutStep/CheckoutStepShipping';
import CheckoutStepOrderDetails, {
  ReviewStepValues,
} from '../../components/CheckoutStep/CheckoutStepOrderDetails';
import { useCallback, useMemo, useState } from 'react';
import { useCart } from '../../contexts/CartProvider';
import CheckoutStepWillCallDetails, {
  WillCallStepValues,
} from '../../components/CheckoutStep/CheckoutStepWillCallDetails';
import { checkoutCart } from '../../actions';
import { LineItem } from '../../types/cart';
import { useNavigate } from 'react-router-dom';

export default function CheckoutPage() {
  const navigate = useNavigate();
  const {
    id,
    cartAddress,
    billingAddress,
    items,
    totals,
    shippingTerm,
    willCallTerm,
    willCallCombination,
    configuration,
    resetCart,
  } = useCart();

  // Does cart have shipping items?
  const hasShipping = useMemo(() => {
    if (!shippingTerm) {
      return false;
    }

    var filteredItems = items.filter(
      (item) => item.shipTermId === shippingTerm.id,
    );

    return filteredItems.length > 0;
  }, [items, shippingTerm]);

  // Does cart have will call items?
  const hasWillCall = useMemo(() => {
    if (!willCallTerm) {
      return false;
    }

    var filteredItems = items.filter(
      (item) => item.shipTermId === willCallTerm.id,
    );

    return filteredItems.length > 0;
  }, [items, willCallTerm]);

  const getCheckoutSteps = () => {
    let steps: {
      name: string;
      Component: any;
      isDirty: boolean;
      values:
        | WillCallStepValues
        | ShippingStepValues
        | ReviewStepValues
        | undefined;
    }[] = [];

    if (hasWillCall) {
      steps.push({
        name: 'willcall',
        Component: CheckoutStepWillCallDetails,
        isDirty: false,
        values: undefined,
      });
    }

    if (hasShipping) {
      steps.push({
        name: 'shipping',
        Component: CheckoutStepShipping,
        isDirty: false,
        values: cartAddress
          ? ({
              selectedAddress: cartAddress,
            } as ShippingStepValues)
          : undefined,
      });
    }

    steps.push({
      name: 'review',
      Component: CheckoutStepOrderDetails,
      isDirty: false,
      values: undefined,
    });

    return steps;
  };

  const [isReady, setIsReady] = useState(false);
  const [buttonStatus, setButtonStatus] = useState<'pending' | 'complete' | ''>(
    '',
  );

  const [currentStep, setCurrentStep] = useState(0);
  const [checkoutSteps, setCheckoutSteps] = useState(() => {
    return getCheckoutSteps();
  });

  /**
   * Move to the next step
   */
  const handleNextStep = useCallback(() => {
    const updatedSteps = [...checkoutSteps];
    updatedSteps[currentStep].isDirty = true;
    setCheckoutSteps(updatedSteps);

    const nextStep = Math.min(currentStep + 1, checkoutSteps.length);
    setCurrentStep(nextStep);

    if (checkoutSteps.length === nextStep) {
      setIsReady(true);
    }
  }, [currentStep, checkoutSteps]);

  /**
   * Go back to a previous step
   */
  const handleEdit = useCallback((idx: number) => {
    setCurrentStep(idx);
  }, []);

  /**
   * Update Step Values
   */
  const handleUpdate = useCallback(
    (newValues: {}, idx: number) => {
      // Clone the existing steps
      const newCheckoutSteps: {
        name: string;
        Component: any;
        isDirty: boolean;
        values: any;
      }[] = [...checkoutSteps];

      // Update the values
      if (!newCheckoutSteps[idx]) {
        return;
      }

      newCheckoutSteps[idx].values = newValues;

      // Update the state with the new values
      setCheckoutSteps(newCheckoutSteps);
    },
    [checkoutSteps],
  );

  const prepareCheckout = useCallback(() => {
    if (!billingAddress) {
      return false;
    }

    const willCallStep = checkoutSteps.find((step) => 'willcall' === step.name)
      ?.values as WillCallStepValues;
    const shippingStep = checkoutSteps.find((step) => 'shipping' === step.name)
      ?.values as ShippingStepValues;
    const reviewStep = checkoutSteps.find((step) => 'review' === step.name)
      ?.values as ReviewStepValues;

    var checkoutValues: {
      basketId: number;
      billToAddressId?: number;
      shipToAddressId?: number;
      thirdPartyBillToAddressId?: number;
      ecommerceWarehouseId?: number;
      shipTermId?: number;
      carrierId?: number;
      shipViaId?: number;
      customerFreightCollectAccountNumber?: string;
      customerPurchaseOrderNumber?: string;
      referenceNumber?: string;
      requiredShipDate?: string;
      estimatedShipPickUpDate?: string;
      shipToCustomizedOrganizationName?: string;
      billToCustomizedOrganizationName?: string;
      thirdPartyBillToCustomizedOrganizationName?: string;
      notes?: string;
      discountPctge?: number;
      totalDiscountAmount?: number;
      lines?: {}[];

    } = {
      basketId: id,
      referenceNumber: `REF${id}`,
      billToAddressId: billingAddress.id,
      billToCustomizedOrganizationName: billingAddress.name,
      shipToAddressId: shippingStep
        ? shippingStep.selectedAddress?.id
        : cartAddress?.id,
      shipToCustomizedOrganizationName: shippingStep
        ? shippingStep.selectedAddress?.name
        : cartAddress?.name,
      customerPurchaseOrderNumber: reviewStep?.purchaseOrder,
      customerFreightCollectAccountNumber: shippingStep
        ? shippingStep.shipments[0]?.freightAccount
        : undefined,
      ecommerceWarehouseId: 0,
      requiredShipDate: shippingStep
        ? shippingStep.shipments[0]?.requiredShipDate
        : willCallStep.shipments[0]?.requiredShipDate,
      estimatedShipPickUpDate: shippingStep
        ? shippingStep.shipments[0]?.requiredShipDate
        : willCallStep.shipments[0]?.requiredShipDate,
      shipTermId: shippingStep ? shippingTerm?.id : willCallTerm?.id,
      carrierId: shippingStep
        ? shippingStep.shipments[0]?.combination?.carrierId
        : willCallCombination?.carrierId,
      shipViaId: shippingStep
        ? shippingStep.shipments[0]?.combination?.shipViaId
        : willCallCombination?.shipViaId,
    };

    if (configuration?.flatDiscount) {
      checkoutValues.discountPctge = configuration.flatDiscount;
      checkoutValues.totalDiscountAmount = totals.discount;
    }

    const lines = items.map((item) => {
      // First check if this is a will call item
      const isWillCallItem = item.shipTermId === willCallTerm?.id;

      // Next lets get the tax info for the cart item.
      const taxInfo = totals.taxes.find((t) => t.cartId === item.cartId);

      var line: LineItem = {
        basketLineId: item.cartId,
        shipTermId: item.shipTermId,
        customerPurchaseOrderNumber: reviewStep?.purchaseOrder,
      };

      if (taxInfo) {
        line.taxAmount = taxInfo.taxAmount || 0;
        line.taxCodeId = taxInfo.taxCodeId || 1;
      }

      // Update line item for WillCall
      if (isWillCallItem) {
        let shipment = willCallStep?.shipments?.find(
          (p: any) => p.warehouse.id === item.warehouseId,
        );

        line.carrierId = willCallCombination?.carrierId;
        line.shipViaId = willCallCombination?.shipViaId;
        line.requiredShipDate = shipment?.requiredShipDate;
        line.estimatedShipPickUpDate = shipment?.estimatedShipPickUpDate;

        // Will call for standard shipping
      } else {
        let shipment = shippingStep?.shipments?.find(
          (p: any) => p.warehouse.id === item.warehouseId,
        );

        line.shipToAddressId = shippingStep
          ? shippingStep?.selectedAddress?.id
          : cartAddress?.id;
        line.shipToCustomizedOrganizationName = shippingStep
          ? shippingStep?.selectedAddress?.name
          : cartAddress?.name;
        line.carrierId = shipment?.combination?.carrierId;
        line.shipViaId = shipment?.combination?.shipViaId;
        line.customerFreightCollectAccountNumber = shipment?.freightAccount;
        line.customerPurchaseOrderNumber = reviewStep?.purchaseOrder;
        line.requiredShipDate = shipment?.requiredShipDate;
        line.estimatedShipPickUpDate = shipment?.requiredShipDate;
      }

      return line;
    });

    checkoutValues.lines = lines;

    return checkoutValues;
  }, [
    id,
    items,
    totals,
    willCallCombination,
    checkoutSteps,
    shippingTerm,
    willCallTerm,
    billingAddress,
    cartAddress,
  ]);

  /**
   * Checkout
   */
  const handleCheckout = useCallback(async () => {
    setButtonStatus('pending');

    try {
      const checkoutValues = prepareCheckout();
      const orderId = await checkoutCart(checkoutValues);

      if (!orderId) {
        console.error('Unable to checkout');
        setButtonStatus('');
        return;
      }

      setButtonStatus('complete');

      setTimeout(async () => {
        await resetCart();

        // Redirect to the order confirmation
        navigate(`/checkout/confirmation/${orderId}`);
      }, 1000);
    } catch (e) {
      // Do Something
      setButtonStatus('');
    }
  }, [prepareCheckout, resetCart, navigate]);

  // If no items in cart then do not allow to checkout
  if (!items?.length && 'complete' !== buttonStatus) {
    navigate('/cart', { replace: true });
    return;
  }

  return (
    <main className="page page__checkout">
      <div className="container">
        <article>
          <div className="page__checkout_header">
            <h1 className="page__checkout_title">
              <i className="icon icon-lock">
                <IconLock />
              </i>{' '}
              Secure Checkout
            </h1>
          </div>

          <ol className="page__checkout_steps">
            {checkoutSteps.map(({ Component, isDirty, values }, idx) => {
              const isActive = currentStep === idx;
              return (
                <li key={`step-${idx}`}>
                  <Component
                    mixed={hasShipping && hasWillCall}
                    active={isActive}
                    dirty={isDirty}
                    values={values}
                    onNext={handleNextStep}
                    onEdit={() => {
                      handleEdit(idx);
                    }}
                    onUpdate={(newValues: any) => {
                      handleUpdate(newValues, idx);
                    }}
                  />
                </li>
              );
            })}
          </ol>
        </article>

        <aside>
          <OrderSummary
            isCheckout={true}
            isReady={isReady}
            buttonStatus={buttonStatus}
            onCheckout={handleCheckout}
          />
        </aside>
      </div>
    </main>
  );
}
