import './Page.scss';
import Register from '../../components/Register/Register';

export default function RegisterPage() {
  return (
    <main className="page page__register">
      <div className="container">
        <Register />
      </div>
    </main>
  );
}
