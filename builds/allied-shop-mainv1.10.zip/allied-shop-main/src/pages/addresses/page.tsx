import Addresses from '../../components/Addresses/Addresses';
import './Page.scss';
import AccountNav from '../../components/AccountNav/AccountNav';
import { getAllAddresses } from '../../actions';
import { useEffect, useState } from 'react';
import ErrorComponent from '../../components/Error/Error';
import Loading from '../../components/Loading/Loading';
import { Helmet } from 'react-helmet';

export default function AddressesPage() {
  const [addresses, setAddresses] = useState<any>();
  const [hasError, setHasError] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAllAddresses = async () => {
      try {
        const addresses = await getAllAddresses();
        addresses && setAddresses(addresses);
      } catch (error) {
        setHasError(true);
        setError(error as Error);
      } finally {
        setLoading(false);
      }
    }
    fetchAllAddresses();
  }, []);

  const resetError = () => {
    setHasError(false);
    setError(null);
  };

  if (loading) {
    return <Loading />;
  }

  if (hasError && error) {
    return <ErrorComponent error={error} reset={resetError} />;
  }

  return (
    <main className="page page__addresses account">
      <Helmet>
        <title>{'My Addresses - Allied'}</title>
        <meta name="description" content={''} />
      </Helmet>
      <div className="container">
        <AccountNav />

        <article>
          <h1 className="page__addresses_title">Addresses</h1>

          <Addresses serverAddresses={addresses ? addresses : undefined} />
        </article>
      </div>
    </main>
  );
}
