import './Page.scss';
import Breadcrumb from '../../components/Breadcrumb/Breadcrumb';
import { getAllCategories } from '../../actions';
import GridCategory from '../../components/Grid/GridCategory';
import { useEffect, useState } from 'react';
import ErrorComponent from '../../components/Error/Error';
import Loading from '../../components/Loading/Loading';
import { Helmet } from 'react-helmet';


export default function ProductsPage() {

  const [categories, setCategories] = useState<any>();
  const [hasError, setHasError] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);

    const fetchData = async () => {
      try {
        const newCategories = await getAllCategories();
        if(!newCategories) throw new Error('Unable to fetch categories')
        newCategories && setCategories(newCategories);
        setLoading(false);
      } catch (error) {
        setHasError(true);
        setError(error as Error);
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const resetError = () => {
    setHasError(false);
    setError(null);
  };

  if (loading) {
    return <Loading />;
  }

  if (hasError && error) {
    return <ErrorComponent error={error} reset={resetError} />;
  }

  const getTotalProducts = categories.reduce((a: any, b: any) => a + b.count, 0);
  const breadcrumb = [{ title: 'All Products' }];

  return (
    <main className="page page__products">
      <Helmet>
        <title>{'All Products - Allied'}</title>
        <meta name="description" content={''} />
      </Helmet>
      <Breadcrumb list={breadcrumb} />

      <article>
        <section className="category-grid">
          <div className="container">
            <h1 className="category-grid__title">All Products</h1>
            <p className="category-grid__product-total">
              {new Intl.NumberFormat().format(getTotalProducts)} products
            </p>

            <GridCategory />
          </div>
        </section>
      </article>
    </main>
  );
}
