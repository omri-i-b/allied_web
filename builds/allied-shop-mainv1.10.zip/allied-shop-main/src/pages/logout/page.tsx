import Logout from '../../components/Logout/Logout';

export default function LogoutPage() {
  return (
    <main className="page page__logout">
      <div className="container">
        <Logout />
      </div>
    </main>
  );
}
