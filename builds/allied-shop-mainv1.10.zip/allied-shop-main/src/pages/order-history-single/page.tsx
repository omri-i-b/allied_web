import { OrderItem } from '../../types/customer';
import { getOrder } from '../../actions';
import { SHIPPING_TERM_WILL_CALL } from '../../constants';
import AccountNav from '../../components/AccountNav/AccountNav';
import CardOrderItem from '../../components/Card/CardOrderItem';
import {ReactComponent as IconExternal} from '../../assets/icons/external.svg';
import './Page.scss';
import { Link, useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import ErrorComponent from '../../components/Error/Error';
import NotFound from '../../components/NotFound/NotFound';
import Loading from '../../components/Loading/Loading';
import { Helmet } from 'react-helmet';

const orderDateFormat = new Intl.DateTimeFormat('en-US', {
  month: 'numeric',
  day: 'numeric',
  year: 'numeric',
});

const deliveryDayFormat = new Intl.DateTimeFormat('en-US', {
  weekday: 'short',
  month: 'long',
  day: 'numeric',
});

const deliveryTimeFormat = new Intl.DateTimeFormat('en-US', {
  hour: 'numeric',
  minute: '2-digit',
  hour12: true,
});

let USDollar = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
});

export default  function OrderHistorySinglePage() {
  const {orderId} = useParams();
  const [order, setOrder] = useState<any>();
  const [hasError, setHasError] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);
  const pageTitle = `Order #${order} - Order History - Allied`;

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const newOrder = await getOrder(Number(orderId));
        newOrder && setOrder(newOrder);
      } catch (error) {
        setHasError(true);
        setError(error as Error);
      } finally {
        setLoading(false);
      }
    }
    fetchOrder();
  }, [orderId])

  if (loading) {
    return <Loading />;
  }

  const resetError = () => {
    setHasError(false);
    setError(null);
  };

  if (hasError && error) {
    return <ErrorComponent error={error} reset={resetError} />;
  }

  if (!order) {
    return <NotFound/>;
  }

  const {
    date,
    number,
    status,
    purchaseOrderNumber,
    salesOrderNumber,
    subtotal,
    taxes,
    total,
    weight,
    shipTo,
    billTo,
    itemCount,
    items,
    portalUrl,
  } = order;

  // Group the line items into shipping term groups
  const packages = (items || []).reduce(
    (group: { [key: string]: OrderItem[] }, item:any) => {
      const { shipTermCode } = item;
      const key = shipTermCode as any;

      group[key] = group[key] ?? [];

      group[key].push(item);

      return group;
    },
    {},
  );

  const notes = order.notes?.split('|');

  return (
    <main className="page page__order account">
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content="" />
      </Helmet>
      <div className="container">
        <AccountNav />

        <article className="order">
          <div className="order__header">
            <h1 className="order__title">Order #{number}</h1>

            {portalUrl && (
              <Link to={portalUrl} className="btn btn-primary">
                <span className="dx-button-content">
                  View Details on Portal
                  <i className="icon icon-external">
                    <IconExternal />
                  </i>
                </span>
              </Link>
            )}
          </div>

          <section className="order__meta">
            <dl className="order__meta_list">
              <div>
                <dt>Status</dt>
                <dd>
                  <span className="tag status" data-status={status}>
                    {status}
                  </span>
                </dd>
              </div>
              <div>
                <dt>Customer PO Number</dt>
                <dd>{purchaseOrderNumber}</dd>
              </div>
              <div>
                <dt>Sales Order Number</dt>
                <dd>{salesOrderNumber}</dd>
              </div>
              <div>
                <dt>Order Date</dt>
                <dd>{orderDateFormat.format(Date.parse(date))}</dd>
              </div>
              <div>
                <dt>Order Number</dt>
                <dd>{number}</dd>
              </div>
              <div>
                <dt>Total</dt>
                <dd>{USDollar.format(total)}</dd>
              </div>
            </dl>
          </section>

          <section className="order__addresses">
            {shipTo ? (
              <div className="order__addresses_delivery">
                <h2 className="order__addresses_title">Delivery Address</h2>
                {shipTo && (
                  <address>
                    <strong>{shipTo?.name}</strong>
                    <br />
                    {shipTo?.street1}
                    <br />
                    {shipTo?.street2 && (
                      <>
                        {shipTo?.street2}
                        <br />
                      </>
                    )}
                    {shipTo?.city}, {shipTo?.state} {shipTo?.postalCode}
                  </address>
                )}
              </div>
            ) : null}

            <div className="order__addresses_billing">
              <h2 className="order__addresses_title">Billing Address</h2>

              {billTo && (
                <address>
                  <strong>{billTo?.name}</strong>
                  <br />
                  {billTo?.street1}
                  <br />
                  {billTo?.street2 && (
                    <>
                      {billTo?.street2}
                      <br />
                    </>
                  )}
                  {billTo?.city}, {billTo?.state} {billTo?.postalCode}
                </address>
              )}
            </div>
          </section>

          <section className="order__products">
            <h2 className="order__products_title">
              Ordered products <span>({itemCount} items)</span>
            </h2>

            {Object.keys(packages).map((key, termIdx) => {
              const termPackage = packages[key];

              if (!termPackage) {
                return [];
              }

              const isWillCall = !!(SHIPPING_TERM_WILL_CALL === key);

              const warehousePackages = termPackage.reduce(
                (group: { [key: string]: OrderItem[] }, warehousePackage:any) => {
                  const { warehouse } = warehousePackage;
                  const key = warehouse as any;

                  group[key] = group[key] ?? [];

                  group[key].push(warehousePackage);

                  return group;
                },
                {},
              );

              return (
                <div key={`terms-${termIdx}`}>
                  {Object.keys(warehousePackages).map(
                    (warehouse, warehouseIdx) => {
                      const warehouseItems = warehousePackages[warehouse];
                      const number = termIdx + warehouseIdx + 1;

                      if (!warehouseItems) {
                        return [];
                      }

                      const shipDate = Date.parse(warehouseItems[0].shipDate);
                      const carrier = warehouseItems[0].carrier;
                      const freightNumber = warehouseItems[0].freightNumber;
                      const note = notes?.shift();

                      return (
                        <div
                          className="order__products_package"
                          key={`package-${number}`}
                        >
                          <h3 className="order__products_package_title">
                            Package {number}{' '}
                            {isWillCall ? 'Will Call at' : 'Shipping from'}{' '}
                            <em>{warehouse}</em>
                          </h3>

                          <dl className="order__products_package_pickup">
                            {isWillCall ? (
                              <>
                                {shipDate && (
                                  <div>
                                    <dt>Pick Up Date</dt>
                                    <dd>
                                      <strong>
                                        {deliveryDayFormat.format(shipDate)}
                                      </strong>{' '}
                                      after{' '}
                                      <strong>
                                        {deliveryTimeFormat.format(shipDate)}
                                      </strong>
                                    </dd>
                                  </div>
                                )}

                                {note && (
                                  <div>
                                    <dt>Note</dt>
                                    <dd>
                                      <strong>{note}</strong>
                                    </dd>
                                  </div>
                                )}
                              </>
                            ) : (
                              <>
                                {shipDate && (
                                  <div>
                                    <dt>Ships on</dt>
                                    <dd>
                                      <strong>
                                        {deliveryDayFormat.format(shipDate)}
                                      </strong>
                                    </dd>
                                  </div>
                                )}
                                {carrier && (
                                  <div>
                                    <dt>Carrier</dt>
                                    <dd>
                                      <strong>{carrier}</strong>
                                    </dd>
                                  </div>
                                )}
                                {freightNumber && (
                                  <div>
                                    <dt>Freight Account Number</dt>
                                    <dd>
                                      <strong>{freightNumber}</strong>
                                    </dd>
                                  </div>
                                )}
                                {note && (
                                  <div>
                                    <dt>Note</dt>
                                    <dd>
                                      <strong>{note}</strong>
                                    </dd>
                                  </div>
                                )}
                              </>
                            )}
                          </dl>

                          <ul className="order__products_list">
                            {warehouseItems?.map((item:any) => {
                              return (
                                <li key={`order-item-${number}-${item.id}`}>
                                  <CardOrderItem {...item} />
                                </li>
                              );
                            })}
                          </ul>
                        </div>
                      );
                    },
                  )}
                </div>
              );
            })}
          </section>

          <section className="order__totals">
            <dl>
              <div>
                <dt>Subtotal</dt>
                <dd>{USDollar.format(subtotal || 0)}</dd>
              </div>
              <div>
                <dt>Estimated Tax</dt>
                <dd>{USDollar.format(taxes || 0)}</dd>
              </div>
              {!!weight && (
                <div>
                  <dt>Estimated Weight</dt>
                  <dd>{(weight || 0).toFixed(1)} lbs</dd>
                </div>
              )}
              <div>
                <dt>Total</dt>
                <dd>{USDollar.format(total)}</dd>
              </div>
            </dl>
          </section>
        </article>
      </div>
    </main>
  );
}
