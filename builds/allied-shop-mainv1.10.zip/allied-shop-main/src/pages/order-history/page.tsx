import { useEffect, useState } from 'react';
import { getAllOrders, getOrderStatusList } from '../../actions';
import AccountNav from '../../components/AccountNav/AccountNav';
import Orders from '../../components/Orders/Orders';
import './Page.scss';
import ErrorComponent from '../../components/Error/Error';
import Loading from '../../components/Loading/Loading';
import { Helmet } from 'react-helmet';

export default function OrderHistoryPage() {
  const [orders, setOrders] = useState<any>();
  const [statusList, setStatusList] = useState<any>();
  const [hasError, setHasError] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const newOrders = await getAllOrders();
        newOrders && setOrders(newOrders);
      } catch (error) {
        setHasError(true);
        setError(error as Error);
      } finally {
        setLoading(false);
      }
    }
    fetchOrders();

    const fetchOrderStatusList = async () => {
      try {
        const newStatusList = await getOrderStatusList();
        newStatusList && setStatusList(newStatusList);
      } catch (error) {
        setHasError(true);
        setError(error as Error);
      } finally {
        setLoading(false);
      }
    }
    fetchOrderStatusList();
  }, []);

  if (loading) {
    return <Loading />;
  }

  const resetError = () => {
    setHasError(false);
    setError(null);
  };

  if (hasError && error) {
    return <ErrorComponent error={error} reset={resetError} />;
  }

  return (
    <main className="page page__order-history account">
      <Helmet>
        <title>{'Order History - Allied'}</title>
        <meta name="description" content={''} />
      </Helmet>
      <div className="container">
        <AccountNav />

        <article>
          <h1 className="page__order-history_title">Order History</h1>

          <Orders serverOrders={orders} serverOrderStatusList={statusList} />
        </article>
      </div>
    </main>
  );
}
