import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import CardVertical from '../../components/Card/CardVertical';
import CardHorizontal from '../../components/Card/CardHorizontal';
import { useEffect, useState } from 'react';
import { Category } from '../../types/categories';
import { getAllCategories } from '../../actions/index';
import SearchHome from '../../components/Search/SearchHome';
import ErrorComponent from '../../components/Error/Error';
import Loading from '../../components/Loading/Loading';

export default function HomePage() {

    const [categories, setCategories] = useState<Category[]>();
    const [hasError, setHasError] = useState<boolean>(false);
    const [error, setError] = useState<Error | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchCategories = async () => {
            try {
                const newCategories = await getAllCategories();

                setCategories(newCategories)
                setLoading(false);

            } catch (error) {
                setHasError(true);
                setError(error as Error);
            }
        }
        fetchCategories();
    }, []);

    if (loading) {
        return <Loading />;
    }

    const resetError = () => {
        setHasError(false);
        setError(null);
    };

    if (hasError && error) {
        return <ErrorComponent error={error} reset={resetError} />;
    }

    return (
        <main className="page page__home">
            <Helmet>
                <title>{'Allied Shop'}</title>
                <meta name="description" content={'Allied Shop Description'} />
            </Helmet>
            <section className="home__hero">
                <div className="container">
                    <h1 className="home__hero_title">
                        Seamless eCommerce, from <em>Search</em> through <em>Delivery</em>.
                    </h1>

                    <SearchHome />

                    {categories && (
                        <div className="home__hero_categories">
                            <h2 className="home__hero_categories_title">
                                Search by category
                            </h2>

                            <ul className="home__hero_categories_list">
                                {categories.map(({ title, slug, image }) => {
                                    return (
                                        <li key={slug} className="home__hero_categories_list_item">
                                            <CardVertical
                                                image={image}
                                                title={title}
                                                link={`/products/${slug}`}
                                                isHomePage={true}
                                            />
                                        </li>
                                    );
                                })}
                            </ul>
                        </div>
                    )}
                </div>
            </section>
            {categories && (
                <section className="home__subcategories">
                    <div className="container">
                        <h2 className="home__subcategories_title">Search by subcategory</h2>

                        {categories.map((category) => {
                            const { subcategories } = category;
                            return (
                                <dl
                                    key={`category-section-${category.slug}`}
                                    className="home__subcategories_category"
                                >
                                    <dt>{category.title}</dt>
                                    <dd>
                                        {subcategories && (
                                            <ul className="home__subcategories_list">
                                                {subcategories.map((subcategory) => {
                                                    return (
                                                        <li key={`subcategory-section-${subcategory.slug}`}>
                                                            <CardHorizontal
                                                                image={subcategory.image}
                                                                title={subcategory.title}
                                                                link={`/products/${category.slug}/${subcategory.slug}`}
                                                            />
                                                        </li>
                                                    );
                                                })}
                                            </ul>
                                        )}
                                    </dd>
                                </dl>
                            );
                        })}
                    </div>
                </section>
            )}

            <section className="home__spotlight">
                <div className="container">
                    <h2 className="home__spotlight_title">Spotlight</h2>

                    <div className="card-spotlight">
                        <figure className="card-spotlight_image">
                            <img
                                src="/images/home_spotlight.png"
                                alt="150lb SS Cast Fittings MSS114"
                                width="324"
                                height="320"
                            />
                        </figure>
                        <div className="card-spotlight_content">
                            <h2 className="card-spotlight_title">
                                150lb SS Cast Fittings MSS114
                            </h2>

                            <div className="md:w-2/3 space-y-6">
                                <p>
                                    We&apos;ve expanded our inventory with robust 150lb flanges,
                                    enhancing connection strength and reliability for diverse
                                    piping applications. Perfect for ensuring tighter seals in
                                    various industrial&nbsp;environments.
                                </p>

                                <p>
                                    <Link
                                        to="/products/cast-fittings/"
                                        className="btn btn-primary-outline"
                                    >
                                        <span className="dx-button-content">Shop now</span>
                                    </Link>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section className="home__allied-group">
                <div className="container">
                    <figure className="home__allied-group_image">
                        <img
                            src="/images/allied-group-aerial.jpg"
                            alt="Allied Group Aerial View"
                            width="575"
                            height="380"
                        />
                    </figure>
                    <div className="home__allied-group_content">
                        <h2 className="home__allied-group_title">
                            Pioneering Safe and Superior Industrial&nbsp;Solutions
                        </h2>

                        <div className="md:w-4/5 space-y-6">
                            <p>
                                Allied Group leads in manufacturing and distributing essential
                                industrial components, with a steadfast commitment to safety and
                                quality that supports critical industries&nbsp;worldwide.
                            </p>

                            <Link
                                to="https://www.allied-grp.com/"
                                target="_blank"
                                className="btn btn-primary"
                            >
                                <p>
                                    <span className="dx-button-content">
                                        Go to Allied Group Site
                                    </span>
                                </p>
                            </Link>
                        </div>
                    </div>
                </div>
            </section>
        </main>


    );
}
