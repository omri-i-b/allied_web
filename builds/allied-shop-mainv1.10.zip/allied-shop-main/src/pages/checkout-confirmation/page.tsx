import { Fragment, useEffect, useState } from 'react';
import { getOrder } from '../../actions';
import { SHIPPING_TERM_WILL_CALL } from '../../constants';
import { OrderItem } from '../../types/customer';
import { ReactComponent as IconInfo } from '../../assets/icons/info-fill.svg';
import { ReactComponent as IconTruck } from '../../assets/icons/truck.svg';
import { ReactComponent as IconWillCall } from '../../assets/icons/willcall.svg';
import './Page.scss';
import { useParams } from 'react-router-dom';
import ErrorComponent from '../../components/Error/Error';
import NotFound from '../../components/NotFound/NotFound';
import Loading from '../../components/Loading/Loading';
import { Helmet } from 'react-helmet';
import { useSelector } from 'react-redux';
import { RootState } from '@/redux/store';

const USDollar = new Intl.NumberFormat('en-US', {
  style: 'currency',
  currency: 'USD',
});

const orderDateFormat = new Intl.DateTimeFormat('en-US', {
  month: 'numeric',
  day: 'numeric',
});

const deliveryDayFormat = new Intl.DateTimeFormat('en-US', {
  month: 'long',
  day: 'numeric',
});


export default function CheckoutConfirmationPage() {
  const email = useSelector((state: RootState) => state.email);

  const [order, setOrder] = useState<any>();
  const { orderId } = useParams();
  const [hasError, setHasError] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const newOrder = await getOrder(Number(orderId));
        newOrder && setOrder(newOrder);
      } catch (error) {
        setHasError(true);
        setError(error as Error);
      } finally {
        setLoading(false);
      }
    }
    fetchOrder();
  }, [orderId]);

  const resetError = () => {
    setHasError(false);
    setError(null);
  };

  if (loading) {
    return <Loading />;
  }

  if (hasError && error) {
    return <ErrorComponent error={error} reset={resetError} />;
  }

  if (!order) {
    return <NotFound />;
  }

  const {
    number,
    date,
    purchaseOrderNumber,
    shipTo,
    billTo,
    items,
    subtotal,
    taxes,
    total,
  } = order;

  const notes = order.notes?.split('|');

  const packages = (items || []).reduce(
    (group: { [key: string]: OrderItem[] }, item: any) => {
      const { shipTermCode } = item;
      const key = shipTermCode as any;

      group[key] = group[key] ?? [];

      group[key].push(item);

      return group;
    },
    {},
  );

  return (
    <main className="page page__confirmation">
      <Helmet>
        <title>{`Order Confirmation #${number} - Allied`}</title>
        <meta name="description" content={''} />
      </Helmet>
      <div className="container">
        <article>
          <div className="page__confirmation_header">
            <h1 className="page__confirmation_title">Order Confirmation</h1>

            <p className="page__confirmation_order-date">
              Date Ordered{' '}
              <strong>{orderDateFormat.format(Date.parse(date))}</strong>
            </p>
          </div>

          <div className="notice notice-success">
            <i className="icon icon-info">
              <IconInfo />
            </i>
            <p>
              Order <strong>#{number}</strong> has sucessfully been submitted
            </p>
          </div>

          <p className="page__confirmation_email">
            Confirmation email sent to <strong>{email}</strong>.
            For questions or assistance, contact your Allied representative.
            We&apos;ll notify you of any order issues.
          </p>

          {Object.keys(packages).map((key, termIdx) => {
            const termPackage = packages[key];

            if (!termPackage) {
              return false;
            }

            const isWillCall = !!(SHIPPING_TERM_WILL_CALL === key);

            const warehousePackages = termPackage.reduce(
              (group: { [key: string]: OrderItem[] }, warehousePackage: any) => {
                const { warehouse } = warehousePackage;
                const key = warehouse as any;

                group[key] = group[key] ?? [];

                group[key].push(warehousePackage);

                return group;
              },
              {},
            );

            return (
              <Fragment key={`terms-${termIdx}`}>
                {isWillCall ? (
                  <section className="packages packages_willcall">
                    <div className="packages_delivery_options">
                      <h2 className="packages_title">Will Call Details</h2>

                      <div className="packages_content">
                        <div className="packages_content_header">
                          <h2 className="packages_content_title">
                            <i className="icon icon-truck">
                              <IconWillCall />
                            </i>{' '}
                            Will Call
                          </h2>
                          <p className="packages_content_count">
                            out of {Object.keys(warehousePackages).length}{' '}
                            warehouses
                          </p>
                        </div>

                        {Object.keys(warehousePackages).map(
                          (warehouse, warehouseIdx) => {
                            const warehouseItems = warehousePackages[warehouse];
                            const number = termIdx + warehouseIdx + 1;

                            if (!warehouseItems) {
                              return [];
                            }

                            const note = notes?.shift();

                            return (
                              <div
                                className="packages__package"
                                key={`package-${number}`}
                              >
                                <h3 className="packages__package_title">
                                  Package {number} from <em>{warehouse}</em>
                                </h3>

                                <p className="packages__package_description">
                                  Order available for pickup in Will Call window
                                  on <strong>Mon. May 12</strong> after{' '}
                                  <strong>8:00 am</strong>
                                </p>

                                {note && (
                                  <div className="packages__package_note">
                                    <h3>Note</h3>
                                    <p>{note}</p>
                                  </div>
                                )}
                              </div>
                            );
                          },
                        )}
                      </div>
                    </div>
                  </section>
                ) : (
                  <section className="packages packages_shipping">
                    <div className="packages_delivery_address">
                      <h2 className="packages_title">Delivery Address</h2>

                      {shipTo && (
                        <address>
                          <strong>{shipTo.name}</strong>
                          <br />
                          {shipTo.street1}
                          <br />
                          {shipTo.street2 && (
                            <>
                              {shipTo.street2}
                              <br />
                            </>
                          )}
                          {shipTo.city}, {shipTo.state} {shipTo.postalCode}
                        </address>
                      )}
                    </div>
                    <div className="packages_delivery_options">
                      <h2 className="packages_title">Delivery Options</h2>

                      <div className="packages_content">
                        <div className="packages_content_header">
                          <h2 className="packages_content_title">
                            <i className="icon icon-truck">
                              <IconTruck />
                            </i>{' '}
                            Shipping
                          </h2>
                          <p className="packages_content_count">
                            out of {Object.keys(warehousePackages).length}{' '}
                            warehouses
                          </p>
                        </div>

                        {Object.keys(warehousePackages).map(
                          (warehouse, warehouseIdx) => {
                            const warehouseItems = warehousePackages[warehouse];
                            const number = termIdx + warehouseIdx + 1;

                            if (!warehouseItems) {
                              return [];
                            }

                            const shipDate = Date.parse(
                              warehouseItems[0].shipDate,
                            );
                            const carrier = warehouseItems[0].carrier;
                            const freightNumber =
                              warehouseItems[0].freightNumber;
                            const note = notes?.shift();

                            return (
                              <div
                                className="packages__package"
                                key={`package-${number}`}
                              >
                                <h3 className="packages__package_title">
                                  Package {number} from <em>{warehouse}</em>
                                </h3>

                                <dl className="packages__package_pickup">
                                  {shipDate && (
                                    <div>
                                      <dt>Ships on</dt>
                                      <dd>
                                        <strong>
                                          {deliveryDayFormat.format(shipDate)}
                                        </strong>
                                      </dd>
                                    </div>
                                  )}
                                  {carrier && (
                                    <div>
                                      <dt>Carrier</dt>
                                      <dd>
                                        <strong>{carrier}</strong>
                                      </dd>
                                    </div>
                                  )}
                                  {freightNumber && (
                                    <div>
                                      <dt>Freight Account Collect Number</dt>
                                      <dd>
                                        <strong>{freightNumber}</strong>
                                      </dd>
                                    </div>
                                  )}
                                  {note && (
                                    <div>
                                      <dt>Note</dt>
                                      <dd>
                                        <strong>{note}</strong>
                                      </dd>
                                    </div>
                                  )}
                                </dl>
                              </div>
                            );
                          },
                        )}
                      </div>
                    </div>
                  </section>
                )}
              </Fragment>
            );
          })}

          <section className="order-details">
            <h2 className="order-details_title">Order Details</h2>

            <dl className="order-details_review">
              <div>
                <dt>PO Number</dt>
                <dd>{purchaseOrderNumber}</dd>
              </div>
              <div>
                <dt>Billing Address</dt>
                <dd>
                  {billTo && (
                    <address>
                      {billTo.name}
                      <br />
                      {billTo.street1}
                      <br />
                      {billTo.street2 && (
                        <>
                          {billTo.street2}
                          <br />
                        </>
                      )}
                      {billTo.city}, {billTo.state} {billTo.postalCode}
                    </address>
                  )}
                </dd>
              </div>
            </dl>
          </section>
        </article>

        <aside>
          <div className="order-summary">
            <h2 className="order-summary_title">Order Summary</h2>

            <dl className="order-summary_totals">
              <div>
                <dt>Subtotal</dt>
                <dd>{USDollar.format(subtotal || 0)}</dd>
              </div>
              <div>
                <dt>Estimated Tax</dt>
                <dd>{USDollar.format(taxes || 0)}</dd>
              </div>
              <div>
                <dt>Total</dt>
                <dd>{USDollar.format(total)}</dd>
              </div>
            </dl>
          </div>
        </aside>
      </div>
    </main>
  );
}
