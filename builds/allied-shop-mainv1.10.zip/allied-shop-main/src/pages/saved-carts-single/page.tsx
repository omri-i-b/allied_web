import { useEffect, useState } from 'react';
import { getSavedCart } from '../../actions';
import AccountNav from '../../components/AccountNav/AccountNav';
import CardCartItem from '../../components/Card/CardCartItem';
import SavedCartHeader from '../../components/SavedCartHeader/SavedCartHeader';
import './Page.scss';
import { useParams } from 'react-router-dom';
import ErrorComponent from '../../components/Error/Error';
import NotFound from '../../components/NotFound/NotFound';
import Loading from '../../components/Loading/Loading';
import { Helmet } from 'react-helmet';

export default function SavedCartsSinglePage() {
  const { cartId } = useParams();
  const [cart, setCart] = useState<any>();
  const [hasError, setHasError] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSavedCart = async () => {
      try {
        const newCart = await getSavedCart(Number(cartId));
        newCart && setCart(newCart);
      } catch (error) {
        setHasError(true);
        setError(error as Error);
      } finally {
        setLoading(false);
      }
    }
    fetchSavedCart();
  }, [cartId]);

  const resetError = () => {
    setHasError(false);
    setError(null);
  };

  if (loading) {
    return <Loading />;
  }

  if (hasError && error) {
    return <ErrorComponent error={error} reset={resetError} />;
  }

  if (!cart) {
    return <NotFound />;
  }

  return (
    <div className="page page__saved-cart account">
      <Helmet>
        <title>{`Order #${cartId} - Saved Carts - Allied`}</title>
        <meta name="description" content={''} />
      </Helmet>
      <div className="container">
        <AccountNav />

        <article className="saved-cart__details">
          <SavedCartHeader cart={cart} />

          <ul className="saved-cart__item-list">
            {cart.items.map((item: any) => {
              return (
                <li key={`item-${item.cartId}`}>
                  <CardCartItem item={item} />
                </li>
              );
            })}
          </ul>
        </article>
      </div>
    </div>
  );
}
