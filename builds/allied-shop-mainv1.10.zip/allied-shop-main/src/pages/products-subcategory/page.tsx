import './Page.scss';
import Breadcrumb from '../../components/Breadcrumb/Breadcrumb';
import { fetchFilterGroups } from '../../lib/categories';
import { FilterGroupType } from '../../types/categories';
import Filters from '../../components/Filters/Filters';
import { SubcategoryGroups } from '../../components/SubcategoryGroups/SubcategoryGroups';
import { getCategoryBySlug, getFilteredProducts } from '../../actions';
import { Suspense, useEffect, useState } from 'react';
import { useParams, useSearchParams } from 'react-router-dom';
import ErrorComponent from '../../components/Error/Error';
import NotFound from '../../components/NotFound/NotFound';
import Loading from '../../components/Loading/Loading';
import { Helmet } from 'react-helmet';
import { Product } from '../../types/products';

export const initialFilters = {
  categories: [] as number[],
  sizes: [] as number[],
  schedules: [] as number[],
  grades: [] as number[],
  pressures: [] as number[],
  shapes: [] as number[],
};

export type FiltersType = {
  categories: number[];
  sizes?: number[];
  schedules?: number[];
  grades?: number[];
  pressures?: number[];
  shapes: number[];
};

const initialResults = {
  total: 0,
  products: [],
};

export type FiltersResults = {
  total: number;
  products: Product[];
};

export default function ProductsSubcategoryPage() {
  const { category: paramCategory, subcategory: paramSubcategory } = useParams();
  const [searchParams] = useSearchParams();

  const [category, setCategory] = useState();
  const [subcategory, setSubcategory] = useState();

  const [filterGroups, setFilterGroups] = useState<FilterGroupType[]>();
  const [groupBy, setGroupBy] = useState<string>('grade');
  const [filters, setFilters] = useState<FiltersType>(initialFilters);
  const [results, setResults] = useState<FiltersResults>(initialResults);


  const [hasError, setHasError] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);

  // Update the Data
  useEffect( () => {
    setLoading(true);
    
    (async () => {
      const data = await getFilteredProducts(filters);
      setResults(data);
      setLoading(false);
    })();
  }, [filters]);

  // Load initial page data from URL
  useEffect(() => {
    const fetchData = async () => {
      const categoryData = await getCategoryBySlug(paramCategory ?? '');

      if (!categoryData) {
        return;
      }

      const subcategoryData = categoryData.subcategories.find(
        (subcategory: any) => subcategory.slug === paramSubcategory,
      );

      if (!subcategoryData) {
        return;
      }

      setCategory(categoryData);
      setSubcategory(subcategoryData)

      const filterGroupData: FilterGroupType[] = await fetchFilterGroups(categoryData.id, subcategoryData.id) ?? [];
      setFilterGroups(filterGroupData);

      const paramFilters = JSON.parse(searchParams.get('filters') || '{}');
      const filterData = {
        ...initialFilters,
        ...paramFilters,
        categories: [categoryData.id],
        shapes: [subcategoryData.id],
      };
      setFilters(filterData);
    }

    fetchData();
  }, [paramCategory, paramSubcategory, searchParams])

  const resetError = () => {
    setHasError(false);
    setError(null);
  };

  if (loading) {
    return <Loading />;
  }

  if (hasError && error) {
    return <ErrorComponent error={error} reset={resetError} />;
  }

  if (!category || !subcategory || !filterGroups) {
    return <NotFound />
  }

  const { title } = subcategory;
  const breadcrumb = [
    { title: 'All Products', path: '/products' },
    { title: category.title, path: `/products/${category.slug}` },
    { title },
  ];


  return (
    <main className="page page__subcategory">
      <Helmet>
        <title>{`${subcategory.title} - ${category.title} - Allied`}</title>
        <meta name="description" content={'Allied Shop Description'} />
      </Helmet>

      <Breadcrumb list={breadcrumb} />

      <div className="container">
        <Suspense fallback={<p>Loading filters...</p>}>
          <Filters filterGroups={filterGroups ?? []} filters={filters} setFilters={setFilters} />
        </Suspense>

        <article>
          <Suspense fallback={<p>Loading products...</p>}>
            <SubcategoryGroups
              subcategory={subcategory}
              filterGroups={filterGroups ?? []}
              groupBy={groupBy}
              filters={filters}
              results={results}
              setGroupBy={setGroupBy}
              setFilters={setFilters}
            />
          </Suspense>
        </article>
      </div>
    </main>
  );
}
