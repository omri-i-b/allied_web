import './Page.scss';
import ChangePassword from '../../components/ChangePassword/ChangePassword';

export default function ChangePasswordPage() {
  return (
    <main className="page page__change-password">
      <div className="container">
        <ChangePassword />
      </div>
    </main>
  );
}
