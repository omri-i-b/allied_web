import { getCategoryById, getProductById, setRecentProduct } from '../../actions';
import Breadcrumb from '../../components/Breadcrumb/Breadcrumb';
import ProductAddToCart from '../../components/ProductAddToCart/ProductAddToCart';
import ProductRelated from '../../components/ProductRelated/ProductRelated';
import RecentProduct from '../../components/RecentProduct/RecentProduct';
import Image from '../../components/Image/Image';
import { ReactComponent as IconInfo } from '../../assets/icons/info-fill.svg';
import './Page.scss';
import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import ErrorComponent from '../../components/Error/Error';
import NotFound from '../../components/NotFound/NotFound';
import Loading from '../../components/Loading/Loading';
import { Helmet } from 'react-helmet';


export default function ProductPage() {
  const { productId: paramProductId } = useParams();
  const [product, setProduct] = useState<any>();
  const [category, setCategory] = useState<any>();
  const [hasError, setHasError] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
     setRecentProduct(Number(paramProductId));
  }, [paramProductId]);

  useEffect(() => {
    
    const fetchData = async () => {
      try {
        const newProduct = await getProductById(Number(paramProductId));
        
        if(!newProduct) throw new Error('Unable to fetch product')
        newProduct && setProduct(newProduct);

        const newCategory = await getCategoryById(newProduct.categoryId);
        
        newCategory && setCategory(newCategory);

      } catch (error) {
        setHasError(true);
        setError(error as Error);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, [paramProductId])


  const resetError = () => {
    setHasError(false);
    setError(null);
  };

  if (loading) {
    return <Loading />;
  }

  if (hasError && error) {
    return <ErrorComponent error={error} reset={resetError} />;
  }
  
  const {
    title,
    image,
    sku,
    weight,
    grade,
    pressure,
    schedule,
    material,
    shape,
    size,
    endConnection,
  } = product;

  if (!category) {
    return <NotFound />;
  }

  const subcategory = category.subcategories.find(
    (subcategory: any) => subcategory.id === product.subcategoryId,
  );

  if (!subcategory) {
    return <NotFound />;
  }

  const breadcrumb = [
    { title: 'Products', path: '/products' },
    {
      title: category.title,
      path: `/products/${category.slug}`,
    },
    {
      title: subcategory.title,
      path: `/products/${category.slug}/${subcategory.slug}`,
    },
    { title },
  ];


  return (
    <main className="page page__product">
      <Helmet>
        <title>{`${product.title} - Allied`}</title>
        <meta name="description" content={''} />
      </Helmet>

      <Breadcrumb list={breadcrumb} />

      <div className="container">
        <section className="product__content">
          <div className="product__media">
            <figure className="product__media_image">
              {image && (
                <Image
                  src={image}
                  alt={title}
                  width={640}
                  height={640}
                  loading="lazy"
                />
              )}
            </figure>
          </div>
          <div className="product__details">
            <h1 className="product__title">{title}</h1>
            <p className="product__price">
              <span>See price in cart</span>{' '}
              <i
                className="icon icon-info"
                data-tooltip="Prices will be displayed in your cart to provide the most accurate information."
                data-tooltip-position="right"
              >
                <IconInfo />
              </i>
            </p>

            <ProductAddToCart product={product} />
          </div>
        </section>

        <section className="product__specifications">
          <h2 className="product__specifications_title">Specifications</h2>

          <dl className="product__specifications_list">
            {sku && (
              <div>
                <dt>Part #</dt>
                <dd>{sku}</dd>
              </div>
            )}
            {weight && (
              <div>
                <dt>Weight</dt>
                <dd>{(weight || 0).toFixed(1)} lbs</dd>
              </div>
            )}
            {category && (
              <div>
                <dt>Part Category</dt>
                <dd>{category.title}</dd>
              </div>
            )}
            {grade && (
              <div>
                <dt>Part Grade</dt>
                <dd>{grade}</dd>
              </div>
            )}
            {pressure && (
              <div>
                <dt>Pressure</dt>
                <dd>{pressure}</dd>
              </div>
            )}
            {schedule && (
              <div>
                <dt>Schedule</dt>
                <dd>{schedule}</dd>
              </div>
            )}
            {shape && (
              <div>
                <dt>Shape</dt>
                <dd>{shape}</dd>
              </div>
            )}
            {size && (
              <div>
                <dt>Size</dt>
                <dd>{size}</dd>
              </div>
            )}
            {material && (
              <div>
                <dt>Material</dt>
                <dd>{material}</dd>
              </div>
            )}
            {endConnection && (
              <div>
                <dt>End Connection</dt>
                <dd>{endConnection}</dd>
              </div>
            )}
          </dl>
        </section>
      </div>

      <ProductRelated productId={product.id} />

      <RecentProduct productId={product.id} />
    </main>
  );
}
