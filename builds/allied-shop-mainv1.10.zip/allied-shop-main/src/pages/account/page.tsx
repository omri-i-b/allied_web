import { getBillingAddress } from '../../actions';
import { TextBox } from 'devextreme-react/text-box';
import AccountNav from '../../components/AccountNav/AccountNav';
import AccountChangePassword from '../../components/ChangePassword/AccountChangePassword';
import './Page.scss';
import { useEffect, useState } from 'react';
import ErrorComponent from '../../components/Error/Error';
import Loading from '../../components/Loading/Loading';
import { Helmet } from 'react-helmet';
import { useSelector } from 'react-redux';
import { RootState } from '../../redux/store';

export default function AccountPage() {

  const firstName = useSelector((state: RootState) => state.firstName);
  const lastName = useSelector((state: RootState) => state.lastName);
  const email = useSelector((state: RootState) => state.email);

  
  const [billingAddress, setBillingAddress] = useState<any>();
  const [hasError, setHasError] = useState<boolean>(false);
  const [error, setError] = useState<Error | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBillingAddress = async () => {
      try {
        const address = await getBillingAddress();
        address && setBillingAddress(address)
      } catch (error) {
        setHasError(true);
        setError(error as Error);
      } finally {
        setLoading(false);
      }
    }
    fetchBillingAddress();
  }, []);

  const resetError = () => {
    setHasError(false);
    setError(null);
  };

  if (loading) {
    return <Loading />;
  }

  if (hasError && error) {
    return <ErrorComponent error={error} reset={resetError} />;
  }

  return (
    <main className="page page__account account">
      <Helmet>
        <title>{'My Account - Allied'}</title>
        <meta name="description" content={''} />
      </Helmet>
      <div className="container">
        <AccountNav />

        <article>
          <h1 className="page__account_title">My Account</h1>

          <section className="account_details">
            <h2 className="account_details_title">Details</h2>

            <div className="account_details_fields">
              <TextBox
                name="name"
                label="Full Name*"
                labelMode="outside"
                defaultValue={`${firstName} ${lastName}`}
                disabled={true}
              />
              <TextBox
                name="email"
                label="Email*"
                labelMode="outside"
                defaultValue={email}
                disabled={true}
              />
            </div>
          </section>

          {billingAddress && (
            <>
              <hr className="account_divider" />

              <section className="account_billing">
                <h2 className="account_billing_title">
                  Billing Address <small>(contact Allied for changes)</small>
                </h2>

                <address className="account_billing_address">
                  <strong>{billingAddress.name}</strong>
                  <br />
                  {billingAddress.street1}
                  <br />
                  {billingAddress.street2 && (
                    <>
                      {billingAddress.street2}
                      <br />
                    </>
                  )}
                  {billingAddress.city}, {billingAddress.state}{' '}
                  {billingAddress.postalCode}
                </address>
              </section>
            </>
          )}

          <hr className="account_divider" />

          <AccountChangePassword />
        </article>
      </div>
    </main>
  );
}
